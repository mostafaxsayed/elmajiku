<?php
require_once __DIR__ . '/../admin/includes/config.php';
require_once __DIR__ . '/../admin/includes/db.php';
require_once __DIR__ . '/../admin/includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

$db = getDB();

// إحصائيات عامة
$total_cards   = $db->query("SELECT COUNT(*) FROM cards")->fetchColumn();
$active_cards  = $db->query("SELECT COUNT(*) FROM cards WHERE status='active'")->fetchColumn();
$expired_cards = $db->query("SELECT COUNT(*) FROM cards WHERE status='expired' OR (expire_date IS NOT NULL AND expire_date < datetime('now'))")->fetchColumn();
$disabled_cards= $db->query("SELECT COUNT(*) FROM cards WHERE status='disabled'")->fetchColumn();
$online_count  = $db->query("SELECT COUNT(*) FROM online_users")->fetchColumn();

// بيانات آخر 7 أيام
$days_data = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = date('m/d', strtotime("-$i days"));
    $logins = $db->prepare("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%login%' AND date(created_at) = ?");
    $logins->execute([$date]);
    $days_data[] = [
        'date'   => $label,
        'logins' => (int)$logins->fetchColumn()
    ];
}

// إجمالي الداتا المستهلكة اليوم (MB)
$today_data = $db->query("SELECT COALESCE(SUM(used_mb),0) FROM cards")->fetchColumn();

// أكثر 5 كروت استخداماً
$top_cards = $db->query("SELECT card_code, used_mb, used_minutes FROM cards WHERE used_mb > 0 ORDER BY used_mb DESC LIMIT 5")->fetchAll();

// وقت تشغيل الراوتر
$uptime = trim(@shell_exec("cat /proc/uptime | awk '{print $1}'"));
$uptime_sec = (int)$uptime;
$uptime_str = sprintf('%02d:%02d:%02d', $uptime_sec/3600, ($uptime_sec%3600)/60, $uptime_sec%60);

// CPU load
$load = trim(@shell_exec("cat /proc/loadavg | awk '{print $1}'"));

// Memory
$mem_total = trim(@shell_exec("grep MemTotal /proc/meminfo | awk '{print $2}'"));
$mem_free  = trim(@shell_exec("grep MemAvailable /proc/meminfo | awk '{print $2}'"));
$mem_used  = ($mem_total && $mem_free) ? ($mem_total - $mem_free) : 0;
$mem_pct   = $mem_total ? round($mem_used / $mem_total * 100) : 0;

echo json_encode([
    'stats' => [
        'total_cards'   => (int)$total_cards,
        'active_cards'  => (int)$active_cards,
        'expired_cards' => (int)$expired_cards,
        'disabled_cards'=> (int)$disabled_cards,
        'online_count'  => (int)$online_count,
        'today_data_mb' => round($today_data, 2),
    ],
    'chart_days' => $days_data,
    'top_cards'  => $top_cards,
    'system' => [
        'uptime'   => $uptime_str,
        'load'     => $load,
        'mem_pct'  => $mem_pct,
        'mem_used_mb' => round($mem_used / 1024),
        'mem_total_mb'=> round($mem_total / 1024),
    ],
    'timestamp' => time()
]);
