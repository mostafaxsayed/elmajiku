<?php
require_once __DIR__ . '/../admin/includes/config.php';
require_once __DIR__ . '/../admin/includes/db.php';
require_once __DIR__ . '/../admin/includes/auth.php';
requireAdmin();

header('Content-Type: application/json');

$db = getDB();

// جلب المتصلين مع تفاصيل الكارت
$users = $db->query("
    SELECT 
        ou.ip_address, ou.mac_address, ou.device_name, ou.login_time, ou.last_seen,
        ou.card_code,
        c.total_mb, c.used_mb, c.total_minutes, c.used_minutes,
        c.download_speed, c.upload_speed, c.status as card_status,
        CAST((strftime('%s','now') - strftime('%s', ou.login_time)) / 60 AS INTEGER) as session_minutes
    FROM online_users ou
    LEFT JOIN cards c ON c.card_code = ou.card_code
    ORDER BY ou.login_time DESC
")->fetchAll();

// إجراء قطع الاتصال
if (isset($_GET['kick']) && !empty($_GET['ip'])) {
    $ip = $_GET['ip'];
    require_once __DIR__ . '/../admin/includes/iptables.php';
    blockIP($ip);
    removeOnlineUser($ip);
    echo json_encode(['success' => true, 'msg' => 'تم قطع الاتصال']);
    exit;
}

echo json_encode([
    'users' => $users,
    'count' => count($users),
    'timestamp' => time()
]);
