<?php
require_once __DIR__ . '/admin/includes/config.php';
require_once __DIR__ . '/admin/includes/db.php';

$db = getDB();
$settings = getSettings();

// جلب الإعلانات والعروض النشطة فقط
$ads = $db->query('SELECT * FROM ads WHERE status = 1 ORDER BY sort_order ASC, created_at DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>العروض والإعلانات - <?= htmlspecialchars($settings['site_name']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --primary: <?= $settings['primary_color'] ?? '#00d4ff' ?>;
  --secondary: <?= $settings['secondary_color'] ?? '#7c3aed' ?>;
  --accent: <?= $settings['accent_color'] ?? '#22c55e' ?>;
  --bg-dark: #070913;
  --card-bg: rgba(22, 27, 39, 0.45);
  --card-bg-hover: rgba(22, 27, 39, 0.65);
  --border: rgba(255, 255, 255, 0.05);
  --text: #f3f4f6;
  --text-muted: #64748b;
}

* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: 'Cairo', system-ui, -apple-system, sans-serif;
  background-color: var(--bg-dark);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 30px 20px;
}

.container {
  width: 100%;
  max-width: 800px;
}

.header {
  text-align: center;
  margin-bottom: 40px;
}
.header h1 {
  font-size: 2rem;
  font-weight: 800;
  background: linear-gradient(90deg, #fff, var(--primary));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.header p {
  color: var(--text-muted);
  margin-top: 8px;
  font-size: 0.95rem;
}

/* شبكة العروض */
.offers-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
  margin-bottom: 40px;
}

.offer-card {
  background: var(--card-bg);
  backdrop-filter: blur(15px);
  -webkit-backdrop-filter: blur(15px);
  border: 1px solid var(--border);
  border-radius: 20px;
  overflow: hidden;
  transition: transform 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
  display: flex;
  flex-direction: column;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}
.offer-card:hover {
  transform: translateY(-5px);
  border-color: rgba(0, 212, 255, 0.2);
  box-shadow: 0 15px 35px rgba(0, 212, 255, 0.1);
}

.offer-img {
  width: 100%;
  height: 180px;
  background-size: cover;
  background-position: center;
  border-bottom: 1px solid var(--border);
}

.offer-body {
  padding: 20px;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
  text-align: right;
}
.offer-title {
  font-size: 1.1rem;
  font-weight: 700;
  color: #fff;
  line-height: 1.4;
}

.offer-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 10px 16px;
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  color: #fff;
  text-decoration: none;
  border-radius: 12px;
  font-weight: 700;
  font-size: 0.85rem;
  margin-top: auto;
  transition: opacity 0.2s;
}
.offer-btn:hover {
  opacity: 0.9;
}

.back-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 12px 24px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--border);
  color: #fff;
  text-decoration: none;
  border-radius: 14px;
  font-weight: 700;
  font-size: 0.9rem;
  transition: background 0.2s;
  margin-top: 20px;
}
.back-btn:hover {
  background: rgba(255, 255, 255, 0.1);
}

.no-offers {
  text-align: center;
  padding: 60px 20px;
  background: var(--card-bg);
  border: 1px solid var(--border);
  border-radius: 20px;
  color: var(--text-muted);
}

.footer {
  text-align: center;
  margin-top: auto;
  padding-top: 40px;
  font-size: 0.8rem;
  color: var(--text-muted);
}
</style>
</head>
<body>

<div class="container">
  
  <div class="header">
    <h1>📢 عروض وإعلانات الشبكة</h1>
    <p>تابع آخر العروض والخصومات والخدمات المتاحة لدينا في شبكة <?= htmlspecialchars($settings['site_name']) ?></p>
  </div>

  <?php if (empty($ads)): ?>
    <div class="no-offers">
      <span style="font-size: 4rem; display: block; margin-bottom: 15px;">📢</span>
      <p style="font-size: 1.1rem; font-weight: 600;">لا توجد عروض أو إعلانات متاحة حالياً.</p>
      <p style="font-size: 0.85rem; margin-top: 5px;">تابعنا لاحقاً لمعرفة كل جديد!</p>
    </div>
  <?php else: ?>
    <div class="offers-grid">
      <?php foreach ($ads as $ad): ?>
        <div class="offer-card">
          <div class="offer-img" style="background-image: url('<?= BASE_URL ?>/<?= htmlspecialchars($ad['image_path']) ?>');"></div>
          <div class="offer-body">
            <h3 class="offer-title"><?= htmlspecialchars($ad['title'] ?: 'عرض مميز') ?></h3>
            
            <?php if ($ad['link_url']): ?>
              <a href="<?= htmlspecialchars($ad['link_url']) ?>" target="_blank" class="offer-btn">
                🔗 الانتقال لرابط العرض
              </a>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div style="text-align: center;">
    <a href="<?= BASE_URL ?>/index.php" class="back-btn">
      🔙 العودة لصفحة الدخول
    </a>
  </div>

  <div class="footer">
    <?= htmlspecialchars(!empty($settings['brand_name']) ? $settings['brand_name'] : $settings['site_name']) ?> &copy; <?= date('Y') ?>
  </div>

</div>

</body>
</html>
