<?php
require '/www/elmajiku/admin/includes/db.php';
$s = getSettings();
echo $s['site_name'] . "\n";
echo "DB OK\n";
