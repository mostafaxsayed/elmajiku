<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$settings = getSettings();

// دالة جلب البيانات من رابط خارجي بأمان
function fetchRemoteUrl($url) {
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        curl_close($ch);
        if ($response !== false) return $response;
    }
    $ctx = stream_context_create([
        'http' => ['timeout' => 15],
        'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false]
    ]);
    return @file_get_contents($url, false, $ctx);
}

// دالة تحميل وحفظ ملف
function downloadRemoteFile($url, $filepath) {
    $data = fetchRemoteUrl($url);
    if ($data === false || empty($data)) return false;
    return @file_put_contents($filepath, $data) !== false;
}

// معالجة طلبات AJAX
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json; charset=utf-8');
    
    // 1. فحص التحديث
    if ($_GET['ajax'] === 'check') {
        $update_url = 'https://elmajiku.gt.tc/ELMAJIKU_OS_Store/update';
        $response_data = fetchRemoteUrl($update_url);
        
        if (!$response_data) {
            echo json_encode(['status' => 'error', 'message' => 'تعذر الاتصال بخادم التحديثات. يرجى التحقق من اتصال الإنترنت بالراوتر.']);
            exit;
        }
        
        $update_info = json_decode($response_data, true);
        if (!$update_info || !isset($update_info['version'])) {
            echo json_encode(['status' => 'error', 'message' => 'صيغة ملف التحديث على السيرفر غير صالحة.']);
            exit;
        }
        
        $has_update = version_compare($update_info['version'], SYSTEM_VERSION, '>');
        
        echo json_encode([
            'status' => 'success',
            'has_update' => $has_update,
            'current_version' => SYSTEM_VERSION,
            'new_version' => $update_info['version'],
            'name' => $update_info['name'] ?? 'تحديث نظام جديد',
            'details' => $update_info['details'] ?? 'لا تتوفر تفاصيل إضافية.',
            'url' => $update_info['url'] ?? '',
            'type' => $update_info['type'] ?? 'code'
        ]);
        exit;
    }
    
    // 2. تطبيق التحديث
    if ($_GET['ajax'] === 'upgrade') {
        $url = $_POST['url'] ?? '';
        $type = $_POST['type'] ?? 'code';
        
        if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            echo json_encode(['status' => 'error', 'message' => 'رابط تحميل التحديث غير صالح.']);
            exit;
        }
        
        // مسار الحفظ المؤقت
        $tmp_file = '/tmp/elmajiku_update_' . time() . ($type === 'code' ? '.tar.gz' : '.bin');
        
        // خطوة 1: التحميل
        if (!downloadRemoteFile($url, $tmp_file)) {
            echo json_encode(['status' => 'error', 'message' => 'فشل تحميل حزمة التحديث من السيرفر.']);
            exit;
        }
        
        // خطوة 2: التثبيت
        if ($type === 'code') {
            // تحديث برمجيات الويب - فك الضغط في /www/elmajiku مع استثناء قاعدة البيانات
            $cmd = "tar -xzf $tmp_file -C " . SITE_ROOT . " --exclude='database/hotspot.db' 2>&1";
            $output = [];
            $retval = 0;
            exec($cmd, $output, $retval);
            @unlink($tmp_file);
            
            if ($retval === 0) {
                // تصفير الكاش
                if (function_exists('opcache_reset')) {
                    @opcache_reset();
                }
                echo json_encode(['status' => 'success', 'message' => 'تم تطبيق التحديث البرمجي وتحديث ملفات النظام بنجاح!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'فشل استخراج ملفات التحديث: ' . implode("\n", $output)]);
            }
            exit;
        } elseif ($type === 'firmware') {
            // تحديث فيرموير كامل بالراوتر
            // نتحقق من وجود أداة sysupgrade
            $has_sysupgrade = trim(shell_exec("which sysupgrade"));
            if (empty($has_sysupgrade)) {
                @unlink($tmp_file);
                echo json_encode(['status' => 'error', 'message' => 'أداة sysupgrade غير متوفرة في هذا الراوتر.']);
                exit;
            }
            
            // تشغيل الترقية في الخلفية لإتاحة إرجاع الرد قبل انقطاع الاتصال
            $log_file = '/tmp/sysupgrade.log';
            $cmd = "sysupgrade -v $tmp_file > $log_file 2>&1 &";
            exec($cmd);
            
            echo json_encode([
                'status' => 'success', 
                'message' => 'بدأت عملية ترقية نظام الراوتر (Firmware). سيقوم الجهاز بإعادة التشغيل وتطبيق السوفت الجديد. يرجى الانتظار دقيقتين ثم إعادة الاتصال بالشبكة.'
            ]);
            exit;
        }
        
        echo json_encode(['status' => 'error', 'message' => 'نوع التحديث غير معروف.']);
        exit;
    }
}

$page_title = 'تحديث النظام (OTA Update)';
$active_page = 'update';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="main">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
    <div>
      <h1 style="font-size:1.6rem; font-weight:800; background:linear-gradient(90deg, #fff, var(--primary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">🔄 تحديث النظام (OTA Update)</h1>
      <p style="color:var(--text-muted); font-size:0.85rem; margin-top:4px;">افحص ووفر أحدث الترقيات والتحديثات لنظام التشغيل ولوحة التحكم بضغطة زر واحدة.</p>
    </div>
  </div>

  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: start;">
    
    <!-- كارت حالة النظام والفحص -->
    <div class="box" style="text-align: center; padding: 40px 24px;">
      <div style="font-size: 4rem; margin-bottom: 20px;">🛡️</div>
      <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 8px;">حالة الإصدار الحالي</h3>
      <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 20px;">إصدار النظام الحالي المثبت بالراوتر: <strong style="color:var(--primary); font-family:monospace; font-size:1.1rem;"><?= SYSTEM_VERSION ?></strong></p>
      
      <button type="button" id="check-btn" onclick="checkUpdate()" class="btn btn-primary" style="margin: 0 auto; min-width: 200px; justify-content: center; height: 45px; font-size:0.95rem;">
        🔍 فحص التحديثات المتوفرة
      </button>
      
      <div id="check-loader" style="display:none; margin-top:15px; color:var(--text-muted); font-size:0.85rem;">
        🔄 جاري الاتصال بسيرفر التحديثات وفحص الملفات...
      </div>
    </div>

    <!-- كارت تفاصيل التحديث الجديد (يظهر فقط إذا كان متوفر) -->
    <div class="box" id="update-box" style="display: none;">
      <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px; border-bottom: 1px solid var(--border); padding-bottom: 12px;">
        <span style="font-size: 1.5rem;">🆕</span>
        <h3 style="font-size: 1.1rem; font-weight: 700; color: var(--primary);" id="update-name">تحديث جديد متوفر</h3>
      </div>
      
      <div style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 0.88rem;">
          <span style="color:var(--text-muted);">رقم الإصدار المتاح:</span>
          <strong id="update-version" style="font-family:monospace; color:#fff;">1.1.0</strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 0.88rem;">
          <span style="color:var(--text-muted);">نوع الترقية:</span>
          <span id="update-type" style="color:#fff;">ملفات النظام البرمجية</span>
        </div>
        <div style="margin-top: 15px;">
          <span style="color:var(--text-muted); display:block; margin-bottom:6px; font-size: 0.88rem;">تفاصيل وميزات التحديث:</span>
          <div id="update-details" style="background:rgba(255,255,255,0.02); border:1px solid var(--border); border-radius:10px; padding:12px 15px; font-size:0.82rem; line-height:1.6; color:#e2e8f0; max-height: 150px; overflow-y: auto;">
            تفاصيل...
          </div>
        </div>
      </div>
      
      <!-- شريط التقدم وزر بدء الترقية -->
      <div id="progress-wrapper" style="display: none; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 0.8rem;">
          <span id="progress-status" style="color: var(--primary);">جاري البدء...</span>
          <span id="progress-percent" style="font-family: monospace;">0%</span>
        </div>
        <div style="width: 100%; height: 8px; background: rgba(255,255,255,0.05); border-radius: 4px; overflow: hidden; border:1px solid var(--border);">
          <div id="progress-bar" style="width: 0%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--secondary)); transition: width 0.3s ease;"></div>
        </div>
      </div>

      <button type="button" id="upgrade-btn" onclick="startUpgrade()" class="btn btn-success" style="width: 100%; justify-content: center; height: 45px; font-size:0.95rem;">
        🚀 تثبيت وتطبيق التحديث الآن
      </button>
    </div>

    <!-- كارت لا توجد تحديثات -->
    <div class="box" id="no-update-box" style="display: none; text-align: center; padding: 40px 24px;">
      <div style="font-size: 3.5rem; margin-bottom: 15px; color: var(--accent);">✅</div>
      <h3 style="font-size: 1.15rem; font-weight: 700; margin-bottom: 8px;">النظام محدث بالكامل</h3>
      <p style="font-size: 0.85rem; color: var(--text-muted);">أنت تستخدم بالفعل آخر إصدار متاح لنظام ELMAJIKU OS.</p>
    </div>

  </div>
</div>

<script>
let updateData = null;

function checkUpdate() {
  const btn = document.getElementById('check-btn');
  const loader = document.getElementById('check-loader');
  const updateBox = document.getElementById('update-box');
  const noUpdateBox = document.getElementById('no-update-box');
  
  if (btn) btn.disabled = true;
  if (loader) loader.style.display = 'block';
  if (updateBox) updateBox.style.display = 'none';
  if (noUpdateBox) noUpdateBox.style.display = 'none';
  
  fetch('update.php?ajax=check')
    .then(response => response.json())
    .then(data => {
      if (btn) btn.disabled = false;
      if (loader) loader.style.display = 'none';
      
      if (data.status === 'success') {
        if (data.has_update) {
          updateData = data;
          document.getElementById('update-version').textContent = data.new_version;
          document.getElementById('update-name').textContent = data.name;
          document.getElementById('update-details').innerHTML = data.details.replace(/\n/g, '<br>');
          document.getElementById('update-type').textContent = data.type === 'code' ? 'ملفات الويب واللوحة فقط (تحديث سريع)' : 'فيرموير كامل للجهاز (يتطلب إعادة تشغيل)';
          if (updateBox) updateBox.style.display = 'block';
        } else {
          if (noUpdateBox) noUpdateBox.style.display = 'block';
        }
      } else {
        alert(data.message || 'حدث خطأ غير معروف أثناء الفحص');
      }
    })
    .catch(err => {
      if (btn) btn.disabled = false;
      if (loader) loader.style.display = 'none';
      alert('خطأ في الاتصال بالشبكة: ' + err.message);
    });
}

function startUpgrade() {
  if (!updateData) return;
  if (!confirm('تنبيه: سيتم البدء في ترقية وتعديل ملفات النظام الآن. يرجى عدم إطفاء الراوتر أو قطع التيار الكهربائي أثناء التثبيت. هل تريد الاستمرار؟')) return;
  
  const upgradeBtn = document.getElementById('upgrade-btn');
  const checkBtn = document.getElementById('check-btn');
  const progressWrapper = document.getElementById('progress-wrapper');
  const progressStatus = document.getElementById('progress-status');
  const progressPercent = document.getElementById('progress-percent');
  const progressBar = document.getElementById('progress-bar');
  
  if (upgradeBtn) upgradeBtn.disabled = true;
  if (checkBtn) checkBtn.disabled = true;
  if (progressWrapper) progressWrapper.style.display = 'block';
  
  // محاكاة خطوات شريط التقدم للتحميل والتثبيت (حيث لا يتوفر تقدم تحميل مباشر في PHP للملفات الخارجية بسهولة)
  let percent = 0;
  progressStatus.textContent = '1. جاري تحميل ملف التحديث من السيرفر...';
  progressBar.style.width = '0%';
  progressPercent.textContent = '0%';
  
  let downloadTimer = setInterval(() => {
    percent += 5;
    if (percent > 65) {
      clearInterval(downloadTimer);
    } else {
      progressBar.style.width = percent + '%';
      progressPercent.textContent = percent + '%';
    }
  }, 300);
  
  // إرسال الطلب الفعلي
  const formData = new FormData();
  formData.append('url', updateData.url);
  formData.append('type', updateData.type);
  
  fetch('update.php?ajax=upgrade', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    clearInterval(downloadTimer);
    if (data.status === 'success') {
      progressBar.style.width = '85%';
      progressPercent.textContent = '85%';
      progressStatus.textContent = '2. جاري فك حزم الملفات وتطبيق الترقية...';
      
      setTimeout(() => {
        progressBar.style.width = '100%';
        progressPercent.textContent = '100%';
        progressStatus.textContent = 'Done!';
        
        alert(data.message);
        window.location.reload();
      }, 1500);
    } else {
      if (upgradeBtn) upgradeBtn.disabled = false;
      if (checkBtn) checkBtn.disabled = false;
      if (progressWrapper) progressWrapper.style.display = 'none';
      alert(data.message || 'فشلت عملية الترقية');
    }
  })
  .catch(err => {
    clearInterval(downloadTimer);
    if (upgradeBtn) upgradeBtn.disabled = false;
    if (checkBtn) checkBtn.disabled = false;
    if (progressWrapper) progressWrapper.style.display = 'none';
    alert('خطأ أثناء الترقية: ' + err.message);
  });
}
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
