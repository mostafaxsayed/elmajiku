<?php
$active_page = $active_page ?? 'dashboard';
$path_prefix = $path_prefix ?? '';
?>
</div> <!-- إغلاق الـ main div -->

<!-- شريط التنقل السفلي للهواتف الذكية (Mobile Bottom Nav) -->
<div class="mobile-nav">
  <a href="<?= $path_prefix ?>dashboard.php" class="mobile-nav-item <?= $active_page === 'dashboard' ? 'active' : '' ?>">
    <span class="icon">📊</span>
    <span>الرئيسية</span>
  </a>
  <a href="<?= $path_prefix ?>cards/index.php" class="mobile-nav-item <?= $active_page === 'cards' || $active_page === 'packages' ? 'active' : '' ?>">
    <span class="icon">🎫</span>
    <span>الكروت</span>
  </a>
  <a href="<?= $path_prefix ?>network/index.php" class="mobile-nav-item <?= $active_page === 'network' ? 'active' : '' ?>">
    <span class="icon">🌐</span>
    <span>الشبكة</span>
  </a>
  <a href="<?= $path_prefix ?>users/index.php" class="mobile-nav-item <?= $active_page === 'users' ? 'active' : '' ?>">
    <span class="icon">👥</span>
    <span>المستخدمين</span>
  </a>
  <a href="<?= $path_prefix ?>settings.php" class="mobile-nav-item <?= $active_page === 'settings' ? 'active' : '' ?>">
    <span class="icon">⚙️</span>
    <span>الإعدادات</span>
  </a>
  <a href="#" id="mobile-menu-toggle" class="mobile-nav-item">
    <span class="icon">☰</span>
    <span>القائمة</span>
  </a>
</div>

<!-- تأثيرات CSS إضافية للمكونات والـ Sidebar للـ Hover -->
<script>
// تحديد شريط الجوال السفلي وإضافة حركة خفيفة عند النقر
document.querySelectorAll('.mobile-nav-item').forEach(item => {
  item.addEventListener('click', () => {
    item.style.transform = 'scale(0.95)';
    setTimeout(() => item.style.transform = 'scale(1)', 150);
  });
});

// فتح وإغلاق القائمة الجانبية من زر الجوال السفلي
const menuToggle = document.getElementById('mobile-menu-toggle');
if (menuToggle) {
  menuToggle.addEventListener('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
      sidebar.classList.toggle('open');
    }
  });
}

// إغلاق القائمة الجانبية عند النقر خارجها في الموبايل
document.addEventListener('click', function(e) {
  const sidebar = document.querySelector('.sidebar');
  const menuToggle = document.getElementById('mobile-menu-toggle');
  if (sidebar && sidebar.classList.contains('open')) {
    if (!sidebar.contains(e.target) && (!menuToggle || !menuToggle.contains(e.target))) {
      sidebar.classList.remove('open');
    }
  }
});
</script>
</body>
</html>
