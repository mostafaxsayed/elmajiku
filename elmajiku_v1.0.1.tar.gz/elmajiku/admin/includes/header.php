<?php
if (!isset($settings)) {
    require_once __DIR__ . '/config.php';
    require_once __DIR__ . '/db.php';
    $settings = getSettings();
}
$path_prefix = $path_prefix ?? '';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($page_title ?? 'لوحة التحكم') ?> - <?= htmlspecialchars($settings['site_name']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --primary: <?= $settings['primary_color'] ?? '#00d4ff' ?>;
  --secondary: <?= $settings['secondary_color'] ?? '#7c3aed' ?>;
  --accent: <?= $settings['accent_color'] ?? '#22c55e' ?>;
  --bg-dark: #070913;
  --card-bg: rgba(22, 27, 39, 0.45);
  --card-bg-hover: rgba(22, 27, 39, 0.65);
  --border: rgba(255, 255, 255, 0.05);
  --text: #f3f4f6;
  --text-muted: #64748b;
  --sidebar-width: 260px;
  /* ===== Aliases for backward compat ===== */
  --muted:  #64748b;
  --card:   rgba(22, 27, 39, 0.45);
  --cyan:   <?= $settings['primary_color'] ?? '#00d4ff' ?>;
  --green:  <?= $settings['accent_color'] ?? '#22c55e' ?>;
  --purple: <?= $settings['secondary_color'] ?? '#7c3aed' ?>;
  --red:    #ef4444;
  --yellow: #f59e0b;
}

* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: 'Cairo', system-ui, -apple-system, sans-serif;
  background-color: var(--bg-dark);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  overflow-x: hidden;
}

/* ===== روابط التنقل الجانبي ===== */
.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 11px 20px;
  margin: 2px 12px;
  color: #94a3b8;
  text-decoration: none;
  font-size: 0.88rem;
  font-weight: 600;
  border-radius: 10px;
  transition: all 0.2s;
}
.nav-item:hover {
  background: rgba(0, 212, 255, 0.07);
  color: var(--primary);
}
.nav-item.active {
  background: linear-gradient(90deg, rgba(0, 212, 255, 0.12), rgba(124, 58, 237, 0.12));
  color: var(--primary);
  border: 1px solid rgba(0, 212, 255, 0.1);
}
.nav-item .icon { font-size: 1.1rem; width: 22px; text-align: center; }

/* ===== التخطيط العام ===== */
.sidebar {
  width: var(--sidebar-width);
  background: rgba(13, 17, 31, 0.8);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  height: 100vh;
  position: fixed;
  top: 0;
  right: 0;
  border-left: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  z-index: 100;
  transition: transform 0.3s ease;
  overflow-y: auto;
}

.main {
  margin-right: var(--sidebar-width);
  padding: 30px;
  flex: 1;
  min-width: 0;
  position: relative;
  z-index: 10;
  transition: all 0.3s ease;
}

/* المربعات والبطاقات الزجاجية */
.box {
  background: var(--card-bg);
  backdrop-filter: blur(15px);
  -webkit-backdrop-filter: blur(15px);
  border-radius: 16px;
  padding: 24px;
  border: 1px solid var(--border);
  transition: transform 0.2s, background 0.2s, box-shadow 0.2s;
  box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
}
.box:hover {
  background: var(--card-bg-hover);
  border-color: rgba(255, 255, 255, 0.08);
  box-shadow: 0 12px 40px 0 rgba(0, 0, 0, 0.3);
}

/* الأزرار والعناصر التفاعلية */
.btn {
  padding: 10px 20px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  font-size: 0.85rem;
  font-weight: 700;
  font-family: inherit;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s;
}
.btn:hover { transform: translateY(-1px); opacity: 0.95; }
.btn-primary { background: linear-gradient(90deg, var(--primary), var(--secondary)); color: #fff; }
.btn-secondary { background: rgba(255, 255, 255, 0.08); color: #e2e8f0; border: 1px solid rgba(255, 255, 255, 0.05); }
.btn-secondary:hover { background: rgba(255, 255, 255, 0.12); }
.btn-danger { background: rgba(239, 68, 68, 0.15); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); }
.btn-danger:hover { background: rgba(239, 68, 68, 0.25); }
.btn-success { background: rgba(34, 197, 94, 0.15); color: #22c55e; border: 1px solid rgba(34, 197, 94, 0.2); }
.btn-success:hover { background: rgba(34, 197, 94, 0.25); }

/* مدخلات النصوص والقوائم */
input[type=text], input[type=password], input[type=number], input[type=datetime-local], select, textarea {
  width: 100%;
  padding: 11px 15px;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 10px;
  color: #fff;
  font-size: 0.88rem;
  outline: none;
  font-family: inherit;
  transition: all 0.2s;
}
input:focus, select:focus, textarea:focus {
  border-color: var(--primary);
  background: rgba(255, 255, 255, 0.06);
  box-shadow: 0 0 10px rgba(0, 212, 255, 0.15);
}

/* شريط التنبيهات */
.alert {
  padding: 14px 18px;
  border-radius: 12px;
  margin-bottom: 20px;
  font-size: 0.88rem;
  text-align: right;
  backdrop-filter: blur(10px);
}
.alert.success { background: rgba(34, 197, 94, 0.08); border: 1px solid rgba(34, 197, 94, 0.15); color: #22c55e; }
.alert.error, .alert.danger { background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.15); color: #ef4444; }

/* شريط الموبايل السفلي */
.mobile-nav {
  display: none;
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 68px;
  background: rgba(13, 17, 31, 0.9);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-top: 1px solid var(--border);
  z-index: 999;
  justify-content: space-around;
  align-items: center;
}
.mobile-nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  color: var(--text-muted);
  text-decoration: none;
  font-size: 0.65rem;
  font-weight: 700;
  transition: all 0.2s;
}
.mobile-nav-item .icon {
  font-size: 1.4rem;
}
.mobile-nav-item.active {
  color: var(--primary);
}

/* شريط التحكم العلوي */
.topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 1px solid var(--border);
}
.topbar h1 {
  font-size: 1.4rem;
  font-weight: 800;
  background: linear-gradient(135deg, #fff, rgba(255,255,255,0.7));
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* الهالات المضيئة للخلفية */
.bg-blob {
  position: fixed;
  width: 450px;
  height: 450px;
  border-radius: 50%;
  filter: blur(130px);
  opacity: 0.07;
  pointer-events: none;
  z-index: 1;
  animation: float-blob 22s infinite alternate;
}
.bg-blob-1 { background: var(--primary); top: -100px; left: -100px; }
.bg-blob-2 { background: var(--secondary); bottom: -150px; right: -100px; animation-delay: -5s; }
@keyframes float-blob {
  0% { transform: translate(0, 0) scale(1); }
  100% { transform: translate(120px, 60px) scale(1.15); }
}

/* أنيميشن النبض */
@keyframes pulse {
  0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(34,197,94,0.4); }
  50% { opacity: 0.7; box-shadow: 0 0 0 5px rgba(34,197,94,0); }
}

/* أقسام السايدبار */
.nav-section {
  padding: 15px 20px 5px;
  color: var(--text-muted);
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 1px;
  text-transform: uppercase;
}

/* التجاوب (Responsive) */
@media (max-width: 1000px) {
  .sidebar {
    transform: translateX(100%); /* إخفاء السايدبار على الموبايل */
  }
  .sidebar.open {
    transform: translateX(0) !important; /* إظهار السايدبار عند الضغط على الزر */
  }
  .main {
    margin-right: 0;
    padding: 20px 15px 90px; /* مسافة أمان للشريط السفلي */
  }
  .mobile-nav {
    display: flex; /* إظهار شريط الجوال السفلي */
  }
}
</style>
</head>
<body>
<!-- الهالات الضوئية العائمة -->
<div class="bg-blob bg-blob-1"></div>
<div class="bg-blob bg-blob-2"></div>
