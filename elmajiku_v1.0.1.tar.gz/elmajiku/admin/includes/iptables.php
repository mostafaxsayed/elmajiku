<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// دالة للتحقق من صحة عنوان IP يدوياً لعدم توفر filter_var في بعض أنظمة OpenWrt
function isValidIpAddress($ip) {
    if (!is_string($ip) || empty($ip) || $ip === '0.0.0.0' || $ip === 'unknown') {
        return false;
    }
    $parts = explode('.', $ip);
    if (count($parts) !== 4) {
        return false;
    }
    foreach ($parts as $part) {
        if ($part === '') {
            return false;
        }
        $val = intval($part);
        if ($val < 0 || $val > 255 || (string)$val !== $part) {
            return false;
        }
    }
    return true;
}

// تهيئة الـ chain والتحكم في السرعات عند بدء التشغيل
function initHotspotChain() {
    $chain = IPTABLES_CHAIN;
    $acnt  = IPTABLES_ACNT_CHAIN;
    $lan   = LAN_INTERFACE;
    $portal_ip = '192.168.77.1';

    // تمكين فحص حزم الجسر المدمجة عبر iptables
    shell_exec("modprobe br_netfilter 2>/dev/null");
    shell_exec("sysctl -w net.bridge.bridge-nf-call-iptables=1 2>/dev/null");
    shell_exec("sysctl -w net.bridge.bridge-nf-filter-vlan-routed=1 2>/dev/null");

    // 1. إنشاء الـ chains إذا لم تكن موجودة وتفريغها لمسح أي قواعد قديمة أو تالفة
    shell_exec("iptables -t nat -N $chain 2>/dev/null");
    shell_exec("iptables -t nat -F $chain 2>/dev/null");
    shell_exec("iptables -N $chain 2>/dev/null");
    shell_exec("iptables -F $chain 2>/dev/null");
    shell_exec("iptables -N $acnt 2>/dev/null");
    shell_exec("iptables -F $acnt 2>/dev/null");
    
    // سلسلة الأجهزة المحظورة (Blacklist)
    shell_exec("iptables -N HOTSPOT_BLOCKED 2>/dev/null");
    shell_exec("iptables -F HOTSPOT_BLOCKED 2>/dev/null");

    // 2. ربط الـ chains بالأنظمة الافتراضية للراوتر
    shell_exec("iptables -C FORWARD -j HOTSPOT_BLOCKED 2>/dev/null || iptables -I FORWARD 1 -j HOTSPOT_BLOCKED");
    shell_exec("iptables -C INPUT -j HOTSPOT_BLOCKED 2>/dev/null || iptables -I INPUT 1 -j HOTSPOT_BLOCKED");
    shell_exec("iptables -C FORWARD -j $acnt 2>/dev/null || iptables -I FORWARD 2 -j $acnt");
    shell_exec("iptables -C FORWARD -i $lan -j $chain 2>/dev/null || iptables -I FORWARD 3 -i $lan -j $chain");
    shell_exec("iptables -t nat -C PREROUTING -i $lan -p tcp --dport 80 -j $chain 2>/dev/null || iptables -t nat -I PREROUTING -i $lan -p tcp --dport 80 -j $chain");

    // 3. قواعد افتراضية لسلسلة الفلترة (HOTSPOT filter)
    // السماح بالاتصالات القائمة والمستمرة
    shell_exec("iptables -C $chain -m state --state ESTABLISHED,RELATED -j ACCEPT 2>/dev/null || iptables -A $chain -m state --state ESTABLISHED,RELATED -j ACCEPT");
    // السماح بطلبات DNS للجميع
    shell_exec("iptables -C $chain -p udp --dport 53 -j ACCEPT 2>/dev/null || iptables -A $chain -p udp --dport 53 -j ACCEPT");
    shell_exec("iptables -C $chain -p tcp --dport 53 -j ACCEPT 2>/dev/null || iptables -A $chain -p tcp --dport 53 -j ACCEPT");
    // السماح بالوصول لصفحة تسجيل الدخول (الويب للراوتر)
    shell_exec("iptables -C $chain -d $portal_ip -p tcp --dport 80 -j ACCEPT 2>/dev/null || iptables -A $chain -d $portal_ip -p tcp --dport 80 -j ACCEPT");
    shell_exec("iptables -C $chain -d $portal_ip -p tcp --dport 443 -j ACCEPT 2>/dev/null || iptables -A $chain -d $portal_ip -p tcp --dport 443 -j ACCEPT");

    // Walled Garden – السماح بـ laksa19.github.io (GitHub Pages IPs)
    // GitHub Pages تستخدم هذه النطاقات الثابتة: 185.199.108.0/22
    $github_pages_ips = ['185.199.108.0/22'];
    foreach ($github_pages_ips as $gip) {
        shell_exec("iptables -C $chain -d $gip -j ACCEPT 2>/dev/null || iptables -I $chain 1 -d $gip -j ACCEPT");
        shell_exec("iptables -t nat -C $chain -d $gip -j RETURN 2>/dev/null || iptables -t nat -I $chain 1 -d $gip -j RETURN");
    }

    // تطبيق قواعد فلترة الشبكة وحظر التطبيقات عند التهيئة (DNS Intercept)
    $db_settings = getSettings();
    $dns_mode = intval($db_settings['dns_filter_mode'] ?? 0);
    $block_tiktok = intval($db_settings['block_tiktok'] ?? 0);
    $block_youtube = intval($db_settings['block_youtube'] ?? 0);
    $block_facebook = intval($db_settings['block_facebook'] ?? 0);
    
    $needs_dns_redirect = ($dns_mode > 0 || $block_tiktok || $block_youtube || $block_facebook);
    if ($needs_dns_redirect) {
        shell_exec("iptables -t nat -C PREROUTING -i $lan -p udp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null || iptables -t nat -I PREROUTING 1 -i $lan -p udp --dport 53 -j DNAT --to-destination $portal_ip:53");
        shell_exec("iptables -t nat -C PREROUTING -i $lan -p tcp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null || iptables -t nat -I PREROUTING 1 -i $lan -p tcp --dport 53 -j DNAT --to-destination $portal_ip:53");
    } else {
        shell_exec("iptables -t nat -D PREROUTING -i $lan -p udp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null");
        shell_exec("iptables -t nat -D PREROUTING -i $lan -p tcp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null");
    }

    // إضافة قاعدة منع افتراضية في نهاية السلسلة لحظر غير المسجلين
    $has_drop = shell_exec("iptables -S $chain | grep -E '\-A $chain \-j DROP'");
    if (!$has_drop) {
        shell_exec("iptables -A $chain -j DROP");
    }

    // 4. قواعد افتراضية لسلسلة التوجيه (HOTSPOT NAT)
    // تجنب إعادة توجيه الطلبات الموجهة للراوتر نفسه
    shell_exec("iptables -t nat -C $chain -d $portal_ip -j RETURN 2>/dev/null || iptables -t nat -I $chain 1 -d $portal_ip -j RETURN");
    
    // توجيه المنافذ 80 غير المصرح لها لصفحة الهوتسبوت
    $has_dnat = shell_exec("iptables -t nat -S $chain | grep -E '\-j DNAT'");
    if (!$has_dnat) {
        shell_exec("iptables -t nat -A $chain -p tcp --dport 80 -j DNAT --to-destination $portal_ip:80");
    }

    // 4.5. تطبيق قواعد التحكم بالواجهات والمنافذ المادية من قاعدة البيانات
    try {
        $db_rules = getDB();
        $iface_rules = $db_rules->query("SELECT * FROM interface_rules")->fetchAll();
        foreach ($iface_rules as $r) {
            $iface = $r['interface_name'];
            $mode = $r['mode'];
            
            // تنظيف القواعد السابقة للواجهة لتجنب التكرار
            shell_exec("iptables -D $chain -m physdev --physdev-in $iface -j ACCEPT 2>/dev/null");
            shell_exec("iptables -D $chain -i $iface -j ACCEPT 2>/dev/null");
            shell_exec("iptables -D $chain -m physdev --physdev-in $iface -j DROP 2>/dev/null");
            shell_exec("iptables -D $chain -i $iface -j DROP 2>/dev/null");
            shell_exec("iptables -t nat -D $chain -m physdev --physdev-in $iface -j RETURN 2>/dev/null");
            shell_exec("iptables -t nat -D $chain -i $iface -j RETURN 2>/dev/null");

            if ($mode === 'bypass') {
                // نت مباشر - السماح بالعبور في الفلتر وتخطي الـ NAT
                shell_exec("iptables -I $chain 1 -m physdev --physdev-in $iface -j ACCEPT 2>/dev/null");
                shell_exec("iptables -I $chain 1 -i $iface -j ACCEPT 2>/dev/null");
                shell_exec("iptables -t nat -I $chain 1 -m physdev --physdev-in $iface -j RETURN 2>/dev/null");
                shell_exec("iptables -t nat -I $chain 1 -i $iface -j RETURN 2>/dev/null");
            } elseif ($mode === 'blocked') {
                // مقطوع - حظر كامل في الفلتر
                shell_exec("iptables -I $chain 1 -m physdev --physdev-in $iface -j DROP 2>/dev/null");
                shell_exec("iptables -I $chain 1 -i $iface -j DROP 2>/dev/null");
            }
        }
    } catch (Exception $e) {
        // فشل صامت
    }

    // 5. تهيئة أدوات تحديد السرعة (Traffic Control)
    shell_exec("tc qdisc del dev $lan root 2>/dev/null");
    shell_exec("tc qdisc del dev $lan ingress 2>/dev/null");
    
    shell_exec("tc qdisc add dev $lan root handle 1: htb default 10");
    shell_exec("tc class add dev $lan parent 1: classid 1:10 htb rate 1gbit ceil 1gbit");
    shell_exec("tc qdisc add dev $lan handle ffff: ingress");

    // 6. استرجاع وتطبيق قواعد المستخدمين المتصلين حالياً من قاعدة البيانات (في حال إعادة تشغيل الجدار الناري)
    try {
        $db = getDB();
        $online_users = $db->query('
            SELECT o.ip_address, c.download_speed, c.upload_speed 
            FROM online_users o
            LEFT JOIN cards c ON o.card_code = c.card_code
        ')->fetchAll();

        foreach ($online_users as $u) {
            $ip = $u['ip_address'];
            if (empty($ip) || $ip === 'unknown' || !isValidIpAddress($ip)) {
                continue;
            }
            
            // السماح بعبور الـ IP في جدار الحماية
            shell_exec("iptables -D $chain -s $ip -j ACCEPT 2>/dev/null");
            shell_exec("iptables -I $chain 1 -s $ip -j ACCEPT");
            shell_exec("iptables -D $chain -d $ip -j ACCEPT 2>/dev/null");
            shell_exec("iptables -I $chain 1 -d $ip -j ACCEPT");

            // تخطي إعادة توجيه الـ NAT للمشتركين النشطين
            shell_exec("iptables -t nat -D $chain -s $ip -j RETURN 2>/dev/null");
            shell_exec("iptables -t nat -I $chain 1 -s $ip -j RETURN");

            // إضافة قواعد عداد البيانات
            shell_exec("iptables -D $acnt -s $ip -j RETURN 2>/dev/null");
            shell_exec("iptables -D $acnt -d $ip -j RETURN 2>/dev/null");
            shell_exec("iptables -I $acnt 1 -s $ip -j RETURN");
            shell_exec("iptables -I $acnt 1 -d $ip -j RETURN");

            // إعادة تطبيق حدود السرعة
            $dl = intval($u['download_speed']);
            $ul = intval($u['upload_speed']);
            if ($dl > 0 || $ul > 0) {
                applyClientSpeedLimit($ip, $dl, $ul);
            }
        }
    } catch (Exception $e) {
        // فشل صامت في حال عدم تهيئة قاعدة البيانات بعد
    }
    // تطبيق تصفية الماك المحظور
    applyMacFilterRules();
    // تطبيق وإعادة بناء قواعد المنافذ
    applyPortRules();
}

// تطبيق حدود السرعة للمشترك (Download / Upload)
function applyClientSpeedLimit($ip, $dl_speed, $ul_speed) {
    if (empty($ip) || $ip === 'unknown' || !isValidIpAddress($ip)) {
        return;
    }
    $lan = LAN_INTERFACE;
    $parts = explode('.', $ip);
    if (count($parts) !== 4) return;
    $id = intval($parts[3]); // استخدام المقطع الأخير من الأي بي كمعرف فريد

    // تنظيف القواعد القديمة لتجنب التكرار
    removeClientSpeedLimit($ip);

    // 1. تحديد سرعة التحميل (Download)
    if ($dl_speed > 0) {
        shell_exec("tc class add dev $lan parent 1: classid 1:$id htb rate {$dl_speed}kbit ceil {$dl_speed}kbit");
        shell_exec("tc filter add dev $lan protocol ip parent 1: prio 1 u32 match ip dst $ip flowid 1:$id");
    }

    // 2. تحديد سرعة الرفع (Upload)
    if ($ul_speed > 0) {
        shell_exec("tc filter add dev $lan parent ffff: protocol ip prio $id u32 match ip src $ip police rate {$ul_speed}kbit burst 20k drop flowid :1");
    }
}

// إزالة حدود السرعة للمشترك
function removeClientSpeedLimit($ip) {
    if (empty($ip) || $ip === 'unknown' || !isValidIpAddress($ip)) {
        return;
    }
    $lan = LAN_INTERFACE;
    $parts = explode('.', $ip);
    if (count($parts) !== 4) return;
    $id = intval($parts[3]);

    shell_exec("tc filter del dev $lan protocol ip parent 1: prio 1 u32 match ip dst $ip 2>/dev/null");
    shell_exec("tc class del dev $lan parent 1: classid 1:$id 2>/dev/null");
    shell_exec("tc filter del dev $lan parent ffff: protocol ip prio $id 2>/dev/null");
}

// سماح لـ IP بالإنترنت وتحديد سرعته
function allowIP($ip) {
    if (empty($ip) || $ip === 'unknown' || !isValidIpAddress($ip)) {
        return false;
    }
    $chain = IPTABLES_CHAIN;
    $acnt  = IPTABLES_ACNT_CHAIN;
    
    // 1. تفعيل العبور في جدار الحماية
    shell_exec("iptables -D $chain -s $ip -j ACCEPT 2>/dev/null");
    shell_exec("iptables -I $chain 1 -s $ip -j ACCEPT");
    shell_exec("iptables -D $chain -d $ip -j ACCEPT 2>/dev/null");
    shell_exec("iptables -I $chain 1 -d $ip -j ACCEPT");

    // 2. تخطي الـ NAT Redirect
    shell_exec("iptables -t nat -D $chain -s $ip -j RETURN 2>/dev/null");
    shell_exec("iptables -t nat -I $chain 1 -s $ip -j RETURN");

    // 3. إضافة قواعد عداد البيانات لـ IP
    shell_exec("iptables -D $acnt -s $ip -j RETURN 2>/dev/null");
    shell_exec("iptables -D $acnt -d $ip -j RETURN 2>/dev/null");
    shell_exec("iptables -I $acnt 1 -s $ip -j RETURN"); // قياس الرفع
    shell_exec("iptables -I $acnt 1 -d $ip -j RETURN"); // قياس التحميل

    // 3.5. قطع أي اتصالات نشطة متعقبة لتفادي استمرار توجيه الـ NAT القديم للعميل
    shell_exec("conntrack -D -s $ip 2>/dev/null");
    shell_exec("conntrack -D -d $ip 2>/dev/null");

    // 4. جلب السرعة المخصصة وتطبيقها
    try {
        $db = getDB();
        $stmt = $db->prepare('
            SELECT c.download_speed, c.upload_speed 
            FROM online_users o 
            JOIN cards c ON o.card_code = c.card_code 
            WHERE o.ip_address = ?
        ');
        $stmt->execute([$ip]);
        $speeds = $stmt->fetch();
        
        if ($speeds) {
            $dl = intval($speeds['download_speed']);
            $ul = intval($speeds['upload_speed']);
            if ($dl > 0 || $ul > 0) {
                applyClientSpeedLimit($ip, $dl, $ul);
            }
        }
    } catch (Exception $e) {
        // فشل صامت
    }

    return true;
}

// منع IP من الإنترنت وإلغاء تحديد سرعته
function blockIP($ip) {
    if (empty($ip) || $ip === 'unknown' || !isValidIpAddress($ip)) {
        return false;
    }
    $chain = IPTABLES_CHAIN;
    $acnt  = IPTABLES_ACNT_CHAIN;
    
    // 1. إزالة قواعد العبور من جدار الحماية
    shell_exec("iptables -D $chain -s $ip -j ACCEPT 2>/dev/null");
    shell_exec("iptables -D $chain -d $ip -j ACCEPT 2>/dev/null");

    // 2. إزالة استثناء الـ NAT وتفعيل إعادة التوجيه للعميل
    shell_exec("iptables -t nat -D $chain -s $ip -j RETURN 2>/dev/null");

    // 3. إزالة قواعد عداد البيانات
    shell_exec("iptables -D $acnt -s $ip -j RETURN 2>/dev/null");
    shell_exec("iptables -D $acnt -d $ip -j RETURN 2>/dev/null");

    // 4. إلغاء تحديد السرعات
    removeClientSpeedLimit($ip);

    // 5. قطع الاتصالات النشطة فوراً من جدول التتبع (conntrack) لمنع تسرب البيانات عبر قاعدة ESTABLISHED
    shell_exec("conntrack -D -s $ip 2>/dev/null");
    shell_exec("conntrack -D -d $ip 2>/dev/null");

    return true;
}

// تحقق هل IP مسموح ليه
function isIPAllowed($ip) {
    $chain  = IPTABLES_CHAIN;
    $result = shell_exec("iptables -L $chain -n 2>/dev/null | grep '$ip'");
    return strpos($result, 'ACCEPT') !== false;
}

// تطبيق إعدادات فلترة الشبكة وحظر التطبيقات (DNS + App Blocking)
function applyNetworkFiltering($dns_mode, $app_vals = []) {
    // دعم الاستدعاء القديم بمعاملات منفصلة
    if (!is_array($app_vals)) {
        // applyNetworkFiltering($dns_mode, $block_tiktok, $block_youtube, $block_facebook)
        $args = func_get_args();
        $app_vals = [
            'block_tiktok'   => isset($args[1]) ? (int)$args[1] : 0,
            'block_youtube'  => isset($args[2]) ? (int)$args[2] : 0,
            'block_facebook' => isset($args[3]) ? (int)$args[3] : 0,
        ];
    }

    $portal_ip = '192.168.77.1';
    $lan = LAN_INTERFACE;
    
    // 1. إعداد خوادم DNS في dnsmasq بناءً على الوضع المختار
    shell_exec("uci del dhcp.@dnsmasq[0].server 2>/dev/null");
    if ($dns_mode == 1) {
        // AdGuard Default (إعلانات ومواقع ضارة)
        shell_exec("uci set dhcp.@dnsmasq[0].noresolv='1' 2>/dev/null");
        shell_exec("uci add_list dhcp.@dnsmasq[0].server='94.140.14.14' 2>/dev/null");
        shell_exec("uci add_list dhcp.@dnsmasq[0].server='94.140.15.15' 2>/dev/null");
    } elseif ($dns_mode == 2) {
        // AdGuard Family (إعلانات + إباحي + بحث آمن)
        shell_exec("uci set dhcp.@dnsmasq[0].noresolv='1' 2>/dev/null");
        shell_exec("uci add_list dhcp.@dnsmasq[0].server='94.140.14.15' 2>/dev/null");
        shell_exec("uci add_list dhcp.@dnsmasq[0].server='94.140.15.15' 2>/dev/null");
    } else {
        // تعطيل الفلترة - السماح بالعودة لملف المضيفين التلقائي للراوتر
        shell_exec("uci del dhcp.@dnsmasq[0].noresolv 2>/dev/null");
    }
    
    // 2. كتابة ملف الكتل الإضافي لأسماء النطاقات (App Blocking + DoH Block)
    $hosts_content = "# ELMAJIKU Blocked Hosts\n";
    
    // منع الـ DNS over HTTPS (DoH) لإجبار المتصفحات على استخدام DNS الشبكة المفلتر
    $any_app_blocked = !empty(array_filter($app_vals));
    if ($dns_mode > 0 || $any_app_blocked) {
        $hosts_content .= "\n# DoH Block\n";
        $hosts_content .= "0.0.0.0 dns.google\n";
        $hosts_content .= "0.0.0.0 cloudflare-dns.com\n";
        $hosts_content .= "0.0.0.0 dns.cloudflare.com\n";
        $hosts_content .= "0.0.0.0 dns.adguard.com\n";
        $hosts_content .= "0.0.0.0 dns.quad9.net\n";
        $hosts_content .= "0.0.0.0 doh.cleanbrowsing.org\n";
        $hosts_content .= "0.0.0.0 doh.pub\n";
    }

    // --- TikTok ---
    if (!empty($app_vals['block_tiktok'])) {
        $hosts_content .= "\n# TikTok Block\n";
        $hosts_content .= "0.0.0.0 tiktok.com\n";
        $hosts_content .= "0.0.0.0 www.tiktok.com\n";
        $hosts_content .= "0.0.0.0 tiktokv.com\n";
        $hosts_content .= "0.0.0.0 www.tiktokv.com\n";
        $hosts_content .= "0.0.0.0 byteoversea.com\n";
        $hosts_content .= "0.0.0.0 ibyteimg.com\n";
        $hosts_content .= "0.0.0.0 ibytedtos.com\n";
        $hosts_content .= "0.0.0.0 muscdn.com\n";
        $hosts_content .= "0.0.0.0 musical.ly\n";
        $hosts_content .= "0.0.0.0 sgsnssdk.com\n";
        $hosts_content .= "0.0.0.0 tiktokcdn.com\n";
    }

    // --- YouTube ---
    if (!empty($app_vals['block_youtube'])) {
        $hosts_content .= "\n# YouTube Block\n";
        $hosts_content .= "0.0.0.0 youtube.com\n";
        $hosts_content .= "0.0.0.0 www.youtube.com\n";
        $hosts_content .= "0.0.0.0 m.youtube.com\n";
        $hosts_content .= "0.0.0.0 youtu.be\n";
        $hosts_content .= "0.0.0.0 ytimg.com\n";
        $hosts_content .= "0.0.0.0 ggpht.com\n";
        $hosts_content .= "0.0.0.0 googlevideo.com\n";
        $hosts_content .= "0.0.0.0 youtubei.googleapis.com\n";
    }

    // --- Facebook & Instagram ---
    if (!empty($app_vals['block_facebook'])) {
        $hosts_content .= "\n# Facebook & Instagram Block\n";
        $hosts_content .= "0.0.0.0 facebook.com\n";
        $hosts_content .= "0.0.0.0 www.facebook.com\n";
        $hosts_content .= "0.0.0.0 m.facebook.com\n";
        $hosts_content .= "0.0.0.0 fbcdn.net\n";
        $hosts_content .= "0.0.0.0 fbsbx.com\n";
        $hosts_content .= "0.0.0.0 instagram.com\n";
        $hosts_content .= "0.0.0.0 www.instagram.com\n";
        $hosts_content .= "0.0.0.0 cdninstagram.com\n";
        $hosts_content .= "0.0.0.0 graph.facebook.com\n";
        $hosts_content .= "0.0.0.0 threads.net\n";
    }

    // --- WhatsApp ---
    if (!empty($app_vals['block_whatsapp'])) {
        $hosts_content .= "\n# WhatsApp Block\n";
        $hosts_content .= "0.0.0.0 whatsapp.com\n";
        $hosts_content .= "0.0.0.0 www.whatsapp.com\n";
        $hosts_content .= "0.0.0.0 whatsapp.net\n";
        $hosts_content .= "0.0.0.0 wa.me\n";
        $hosts_content .= "0.0.0.0 static.whatsapp.net\n";
        $hosts_content .= "0.0.0.0 media.whatsapp.net\n";
    }

    // --- Twitter / X ---
    if (!empty($app_vals['block_twitter'])) {
        $hosts_content .= "\n# Twitter / X Block\n";
        $hosts_content .= "0.0.0.0 twitter.com\n";
        $hosts_content .= "0.0.0.0 www.twitter.com\n";
        $hosts_content .= "0.0.0.0 x.com\n";
        $hosts_content .= "0.0.0.0 www.x.com\n";
        $hosts_content .= "0.0.0.0 t.co\n";
        $hosts_content .= "0.0.0.0 twimg.com\n";
        $hosts_content .= "0.0.0.0 abs.twimg.com\n";
        $hosts_content .= "0.0.0.0 api.twitter.com\n";
        $hosts_content .= "0.0.0.0 api.x.com\n";
    }

    // --- Snapchat ---
    if (!empty($app_vals['block_snapchat'])) {
        $hosts_content .= "\n# Snapchat Block\n";
        $hosts_content .= "0.0.0.0 snapchat.com\n";
        $hosts_content .= "0.0.0.0 www.snapchat.com\n";
        $hosts_content .= "0.0.0.0 snap.com\n";
        $hosts_content .= "0.0.0.0 app.snapchat.com\n";
        $hosts_content .= "0.0.0.0 feelinsonice-hrd.appspot.com\n";
        $hosts_content .= "0.0.0.0 sc-cdn.net\n";
    }

    // --- Telegram ---
    if (!empty($app_vals['block_telegram'])) {
        $hosts_content .= "\n# Telegram Block\n";
        $hosts_content .= "0.0.0.0 telegram.org\n";
        $hosts_content .= "0.0.0.0 www.telegram.org\n";
        $hosts_content .= "0.0.0.0 t.me\n";
        $hosts_content .= "0.0.0.0 web.telegram.org\n";
        $hosts_content .= "0.0.0.0 telegram.me\n";
        $hosts_content .= "0.0.0.0 core.telegram.org\n";
    }

    // --- Online Games ---
    if (!empty($app_vals['block_games'])) {
        $hosts_content .= "\n# Online Games Block\n";
        // PUBG Mobile
        $hosts_content .= "0.0.0.0 pubg.com\n";
        $hosts_content .= "0.0.0.0 pubgmobile.com\n";
        // Fortnite / Epic Games
        $hosts_content .= "0.0.0.0 epicgames.com\n";
        $hosts_content .= "0.0.0.0 fortnite.com\n";
        // Free Fire
        $hosts_content .= "0.0.0.0 freefiregame.com\n";
        // Roblox
        $hosts_content .= "0.0.0.0 roblox.com\n";
        $hosts_content .= "0.0.0.0 www.roblox.com\n";
        // Steam / Valve
        $hosts_content .= "0.0.0.0 steampowered.com\n";
        $hosts_content .= "0.0.0.0 steamcommunity.com\n";
        // Clash of Clans / Supercell
        $hosts_content .= "0.0.0.0 supercell.com\n";
        // FIFA / EA
        $hosts_content .= "0.0.0.0 ea.com\n";
        $hosts_content .= "0.0.0.0 origin.com\n";
        // Minecraft
        $hosts_content .= "0.0.0.0 minecraft.net\n";
    }
    
    @file_put_contents('/etc/elmajiku_blocked_hosts', $hosts_content);
    
    // ربط ملف الكتل الإضافي بـ dnsmasq
    shell_exec("uci del_list dhcp.@dnsmasq[0].addnhosts='/etc/elmajiku_blocked_hosts' 2>/dev/null");
    shell_exec("uci add_list dhcp.@dnsmasq[0].addnhosts='/etc/elmajiku_blocked_hosts' 2>/dev/null");
    
    shell_exec("uci commit dhcp 2>/dev/null");
    shell_exec("/etc/init.d/dnsmasq reload 2>/dev/null");
    
    // 3. تفعيل أو إزالة قواعد توجيه الـ DNS الإجبارية في الجدار الناري
    $needs_dns_redirect = ($dns_mode > 0 || $any_app_blocked);
    if ($needs_dns_redirect) {
        shell_exec("iptables -t nat -C PREROUTING -i $lan -p udp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null || iptables -t nat -I PREROUTING 1 -i $lan -p udp --dport 53 -j DNAT --to-destination $portal_ip:53");
        shell_exec("iptables -t nat -C PREROUTING -i $lan -p tcp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null || iptables -t nat -I PREROUTING 1 -i $lan -p tcp --dport 53 -j DNAT --to-destination $portal_ip:53");
    } else {
        shell_exec("iptables -t nat -D PREROUTING -i $lan -p udp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null");
        shell_exec("iptables -t nat -D PREROUTING -i $lan -p tcp --dport 53 -j DNAT --to-destination $portal_ip:53 2>/dev/null");
    }
}

// تطبيق قواعد تصفية الـ MAC المحظورة
function applyMacFilterRules() {
    shell_exec("iptables -F HOTSPOT_BLOCKED 2>/dev/null");
    try {
        $db = getDB();
        $blocked = $db->query("SELECT mac_address FROM blocked_macs")->fetchAll();
        foreach ($blocked as $b) {
            $mac = strtoupper(trim($b['mac_address']));
            if (!empty($mac)) {
                shell_exec("iptables -A HOTSPOT_BLOCKED -m mac --mac-source $mac -j DROP");
            }
        }
    } catch (Exception $e) {
        // صامت
    }
}

// تطبيق وإعادة بناء قواعد المنافذ (فتح / توجيه)
function applyPortRules() {
    // 1. جلب كل إعدادات الفايروال الحالية التي تخص المجيكو وحذفها من uci
    $output = shell_exec("uci show firewall 2>/dev/null");
    if ($output) {
        $lines = explode("\n", $output);
        $sections_to_delete = [];
        foreach ($lines as $line) {
            if (preg_match('/^firewall\.(elmajiku_[a-zA-Z0-9_]+)=/', $line, $matches)) {
                $sections_to_delete[$matches[1]] = true;
            }
        }
        foreach ($sections_to_delete as $sec => $val) {
            shell_exec("uci delete firewall.$sec 2>/dev/null");
        }
    }
    
    // 2. قراءة القواعد النشطة من قاعدة البيانات وإضافتها
    try {
        $db = getDB();
        $rules = $db->query("SELECT * FROM port_rules WHERE status = 1")->fetchAll();
        foreach ($rules as $r) {
            $id = $r['id'];
            $name = preg_replace('/[^a-zA-Z0-9_]/', '', $r['name']);
            $type = $r['type']; // open أو forward
            $proto = $r['proto'] === 'both' ? 'tcp udp' : $r['proto'];
            $ext_port = intval($r['ext_port']);
            
            if ($type === 'open') {
                $sec_name = "elmajiku_rule_$id";
                shell_exec("uci set firewall.$sec_name=rule");
                shell_exec("uci set firewall.$sec_name.name='elmajiku_$name'");
                shell_exec("uci set firewall.$sec_name.src='wan'");
                shell_exec("uci set firewall.$sec_name.dest_port='$ext_port'");
                shell_exec("uci set firewall.$sec_name.proto='$proto'");
                shell_exec("uci set firewall.$sec_name.target='ACCEPT'");
            } elseif ($type === 'forward') {
                $sec_name = "elmajiku_forward_$id";
                $int_ip = $r['int_ip'];
                $int_port = intval($r['int_port']);
                if (!empty($int_ip)) {
                    shell_exec("uci set firewall.$sec_name=redirect");
                    shell_exec("uci set firewall.$sec_name.name='elmajiku_$name'");
                    shell_exec("uci set firewall.$sec_name.src='wan'");
                    shell_exec("uci set firewall.$sec_name.src_dport='$ext_port'");
                    shell_exec("uci set firewall.$sec_name.dest='lan'");
                    shell_exec("uci set firewall.$sec_name.dest_ip='$int_ip'");
                    shell_exec("uci set firewall.$sec_name.dest_port='$int_port'");
                    shell_exec("uci set firewall.$sec_name.proto='$proto'");
                }
            }
        }
    } catch (Exception $e) {
        // صامت
    }
    
    // 3. حفظ وتطبيق الإعدادات
    shell_exec("uci commit firewall 2>/dev/null");
    shell_exec("/etc/init.d/firewall reload 2>/dev/null");
}

