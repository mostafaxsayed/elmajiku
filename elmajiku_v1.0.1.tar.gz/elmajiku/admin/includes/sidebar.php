<?php
$active_page = $active_page ?? 'dashboard';
$path_prefix = $path_prefix ?? '';
?>
<div class="sidebar">
  <div class="brand" style="text-align:center; padding:24px 20px; border-bottom:1px solid var(--border);">
    <h2 style="font-size:1.2rem; font-weight:800; background:linear-gradient(90deg, var(--primary), var(--secondary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">
      <?= htmlspecialchars($settings['site_name']) ?>
    </h2>
    <span style="font-size:0.68rem; color:var(--text-muted); letter-spacing:1px; margin-top:4px; display:block;">لوحة التحكم بالإدارة</span>
  </div>
  
  <div class="nav-section" style="padding:15px 20px 5px; color:var(--text-muted); font-size:0.7rem; font-weight:700; letter-spacing:1px; text-transform:uppercase;">القائمة الرئيسية</div>
  
  <a href="<?= $path_prefix ?>dashboard.php" class="nav-item <?= $active_page === 'dashboard' ? 'active' : '' ?>">
    <span class="icon">📊</span> الرئيسية
  </a>
  <a href="<?= $path_prefix ?>analytics.php" class="nav-item <?= $active_page === 'analytics' ? 'active' : '' ?>">
    <span class="icon">📉</span> التحليلات
  </a>
  
  <div class="nav-section" style="padding:15px 20px 5px; color:var(--text-muted); font-size:0.7rem; font-weight:700; letter-spacing:1px; text-transform:uppercase;">الإدارة</div>
  
  <a href="<?= $path_prefix ?>cards/index.php" class="nav-item <?= $active_page === 'cards' ? 'active' : '' ?>">
    <span class="icon">🎫</span> الكروت
  </a>
  <a href="<?= $path_prefix ?>cards/groups.php" class="nav-item <?= $active_page === 'groups' ? 'active' : '' ?>">
    <span class="icon">📁</span> مجموعات الكروت
  </a>
  <a href="<?= $path_prefix ?>cards/packages.php" class="nav-item <?= $active_page === 'packages' ? 'active' : '' ?>">
    <span class="icon">💰</span> الباقات والأسعار
  </a>
  <a href="<?= $path_prefix ?>users/index.php" class="nav-item <?= $active_page === 'users' ? 'active' : '' ?>">
    <span class="icon">👥</span> المستخدمون الأونلاين
  </a>
  <a href="<?= $path_prefix ?>network/index.php" class="nav-item <?= $active_page === 'network' ? 'active' : '' ?>">
    <span class="icon">🌐</span> الشبكة
  </a>
  <a href="<?= $path_prefix ?>ads.php" class="nav-item <?= $active_page === 'ads' ? 'active' : '' ?>">
    <span class="icon">📢</span> إعلانات وعروض
  </a>
  
  <div class="nav-section" style="padding:15px 20px 5px; color:var(--text-muted); font-size:0.7rem; font-weight:700; letter-spacing:1px; text-transform:uppercase;">النظام</div>
  
  <a href="<?= $path_prefix ?>reports/index.php" class="nav-item <?= $active_page === 'reports' ? 'active' : '' ?>">
    <span class="icon">📈</span> التقارير
  </a>
  <a href="<?= $path_prefix ?>filtering.php" class="nav-item <?= $active_page === 'filtering' ? 'active' : '' ?>">
    <span class="icon">🛡️</span> الفلترة والحظر
  </a>
  <a href="<?= $path_prefix ?>mac_filter.php" class="nav-item <?= $active_page === 'mac_filter' ? 'active' : '' ?>">
    <span class="icon">💻</span> فلترة الـ MAC
  </a>
  <a href="<?= $path_prefix ?>ports.php" class="nav-item <?= $active_page === 'ports' ? 'active' : '' ?>">
    <span class="icon">🔌</span> إدارة المنافذ (Ports)
  </a>
  <a href="<?= $path_prefix ?>update.php" class="nav-item <?= $active_page === 'update' ? 'active' : '' ?>">
    <span class="icon">🔄</span> تحديث النظام
  </a>
  <a href="<?= $path_prefix ?>settings.php" class="nav-item <?= $active_page === 'settings' ? 'active' : '' ?>">
    <span class="icon">⚙️</span> الإعدادات
  </a>
  
  <div class="nav-section" style="padding:15px 20px 5px; color:var(--text-muted); font-size:0.7rem; font-weight:700; letter-spacing:1px; text-transform:uppercase;">الراوتر</div>
  
  <a href="http://192.168.77.1/cgi-bin/luci" target="_blank" class="nav-item" style="color:#f59e0b;">
    <span class="icon">🔧</span> OpenWrt (LuCI)
    <span style="font-size:0.6rem; background:rgba(245,158,11,0.12); color:#f59e0b; border:1px solid rgba(245,158,11,0.3); border-radius:4px; padding:1px 5px; margin-right:auto;">خارجي</span>
  </a>
  
  <a href="<?= $path_prefix ?>logout.php" class="nav-item" style="color:#ef4444; margin-top:auto; border-top:1px solid var(--border); padding-top:15px; border-radius:0;">
    <span class="icon">🚪</span> تسجيل الخروج
  </a>
</div>
