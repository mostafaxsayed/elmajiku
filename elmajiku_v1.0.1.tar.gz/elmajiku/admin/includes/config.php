<?php
date_default_timezone_set('Africa/Cairo');
define('DB_PATH', '/www/elmajiku/database/hotspot.db');
define('SITE_ROOT', '/www/elmajiku');
define('BASE_URL', 'http://192.168.77.1/elmajiku');
define('ADMIN_URL', BASE_URL . '/admin');
define('SESSION_TIMEOUT', 3600); // ساعة

// إعدادات الـ iptables
define('LAN_INTERFACE', 'br-lan');
define('WAN_INTERFACE', 'wan');
define('IPTABLES_CHAIN', 'HOTSPOT');
define('IPTABLES_ACNT_CHAIN', 'HOTSPOT_ACNT');

// رقم إصدار النظام الحالي
define('SYSTEM_VERSION', '1.0.0');
