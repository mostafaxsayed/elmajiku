<?php
require_once __DIR__ . '/config.php';

function getDB() {
    static $db = null;
    if ($db === null) {
        try {
            $db = new PDO('sqlite:' . DB_PATH);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $db->exec('PRAGMA journal_mode=WAL');
            $db->exec('PRAGMA foreign_keys=ON');
            // ===== ترقية تلقائية للجداول =====
            _autoMigrateDB($db);
        } catch (PDOException $e) {
            die('DB Error: ' . $e->getMessage());
        }
    }
    return $db;
}

/**
 * إصلاح وترقية تلقائية لهيكل قاعدة البيانات
 * يعمل عند كل اتصال بدون أخطاء إذا كانت الأعمدة موجودة مسبقاً
 */
function _autoMigrateDB($db) {
    try {
        // --- جدول card_logs ---
        $cols = $db->query("PRAGMA table_info(card_logs)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('created_at', $cols)) {
            $db->exec("ALTER TABLE card_logs ADD COLUMN created_at DATETIME");
            $db->exec("UPDATE card_logs SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL");
        }

        // --- جدول settings ---
        $cols2 = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
        $settings_cols = [
            'portal_title'   => "TEXT NOT NULL DEFAULT 'أهلاً بك'",
            'portal_welcome' => "TEXT NOT NULL DEFAULT 'أدخل كود الكارت للدخول'",
            'primary_color'  => "TEXT NOT NULL DEFAULT '#00d4ff'",
            'secondary_color'=> "TEXT NOT NULL DEFAULT '#7c3aed'",
            'accent_color'   => "TEXT NOT NULL DEFAULT '#22c55e'",
            'login_title'    => "TEXT NOT NULL DEFAULT 'تسجيل الدخول'",
            'session_timeout'=> "INTEGER NOT NULL DEFAULT 3600",
            'auto_refresh'   => "INTEGER NOT NULL DEFAULT 0",
            'trial_enabled'  => "INTEGER NOT NULL DEFAULT 1",
            'trial_mb'       => "INTEGER NOT NULL DEFAULT 50",
            'trial_min'      => "INTEGER NOT NULL DEFAULT 10",
            'brute_force_enabled' => "INTEGER NOT NULL DEFAULT 1",
            'brute_force_duration'=> "INTEGER NOT NULL DEFAULT 15",
            'brute_force_max_attempts' => "INTEGER NOT NULL DEFAULT 5",
            'dns_filter_mode' => "INTEGER NOT NULL DEFAULT 0",
            'block_tiktok'    => "INTEGER NOT NULL DEFAULT 0",
            'block_youtube'   => "INTEGER NOT NULL DEFAULT 0",
            'block_facebook'  => "INTEGER NOT NULL DEFAULT 0",
            'block_whatsapp'  => "INTEGER NOT NULL DEFAULT 0",
            'block_twitter'   => "INTEGER NOT NULL DEFAULT 0",
            'block_snapchat'  => "INTEGER NOT NULL DEFAULT 0",
            'block_telegram'  => "INTEGER NOT NULL DEFAULT 0",
            'block_games'     => "INTEGER NOT NULL DEFAULT 0",
        ];
        foreach ($settings_cols as $col => $def) {
            if (!in_array($col, $cols2)) {
                $db->exec("ALTER TABLE settings ADD COLUMN $col $def");
            }
        }

        // --- جدول محاولات التخمين للحظر المؤقت ---
        $db->exec("CREATE TABLE IF NOT EXISTS login_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip_address TEXT UNIQUE NOT NULL,
            attempts INTEGER DEFAULT 1,
            last_attempt DATETIME DEFAULT CURRENT_TIMESTAMP,
            locked_until DATETIME
        )");

        // --- جدول cards ---
        $cols3 = $db->query("PRAGMA table_info(cards)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('created_at', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN created_at DATETIME");
            $db->exec("UPDATE cards SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL");
        }
        if (!in_array('price', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN price REAL DEFAULT 0.0");
        }
        if (!in_array('download_speed', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN download_speed INTEGER DEFAULT 0");
        }
        if (!in_array('upload_speed', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN upload_speed INTEGER DEFAULT 0");
        }
        if (!in_array('max_devices', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN max_devices INTEGER DEFAULT 1");
        }
        if (!in_array('first_login', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN first_login DATETIME");
        }
        if (!in_array('expire_days', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN expire_days INTEGER DEFAULT 0");
        }
        if (!in_array('group_id', $cols3)) {
            $db->exec("ALTER TABLE cards ADD COLUMN group_id INTEGER");
        }

        // --- جدول card_groups ---
        $db->exec("CREATE TABLE IF NOT EXISTS card_groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // --- جدول bypassed_macs ---
        $db->exec("CREATE TABLE IF NOT EXISTS bypassed_macs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mac_address TEXT UNIQUE NOT NULL,
            description TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // --- جدول interface_rules ---
        $db->exec("CREATE TABLE IF NOT EXISTS interface_rules (
            interface_name TEXT PRIMARY KEY,
            mode TEXT NOT NULL,
            description TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // --- جدول packages ---
        $db->exec("CREATE TABLE IF NOT EXISTS packages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price REAL NOT NULL,
            total_mb INTEGER,
            total_minutes INTEGER,
            download_speed INTEGER,
            upload_speed INTEGER,
            max_devices INTEGER DEFAULT 1,
            expire_days INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        $count = $db->query("SELECT COUNT(*) FROM packages")->fetchColumn();
        if ($count == 0) {
            $db->exec("INSERT INTO packages (name, price, total_mb, total_minutes, download_speed, upload_speed, max_devices, expire_days) VALUES
                ('باقة 500 ميجا', 2.0, 500, 1440, 0, 0, 1, 1),
                ('باقة 1.5 جيجا', 5.0, 1536, 4320, 0, 0, 1, 3),
                ('باقة 3 جيجا', 10.0, 3072, 10080, 0, 0, 1, 7),
                ('باقة 6 جيجا', 18.0, 6144, 21600, 0, 0, 1, 15),
                ('باقة 12 جيجا', 30.0, 12288, 43200, 0, 0, 1, 30)");
        }

        // --- جدول الإعلانات ads ---
        $db->exec("CREATE TABLE IF NOT EXISTS ads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            image_path TEXT NOT NULL,
            link_url TEXT,
            status INTEGER DEFAULT 1,
            sort_order INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // --- جدول الأجهزة المحظورة blocked_macs ---
        $db->exec("CREATE TABLE IF NOT EXISTS blocked_macs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mac_address TEXT UNIQUE NOT NULL,
            description TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // --- جدول قواعد المنافذ port_rules ---
        $db->exec("CREATE TABLE IF NOT EXISTS port_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            proto TEXT NOT NULL,
            ext_port INTEGER NOT NULL,
            int_ip TEXT,
            int_port INTEGER,
            status INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        // إنشاء مجلد الإعلانات المرفوعة
        $ads_upload_dir = '/www/elmajiku/uploads/ads';
        if (!file_exists($ads_upload_dir)) {
            @mkdir($ads_upload_dir, 0777, true);
        }

    } catch (Exception $e) {
        // تجاهل أخطاء الترقية الصامتة لمنع تعطل الموقع
        error_log('AutoMigrate warning: ' . $e->getMessage());
    }
}

// =================== CARDS ===================

function getCard($code) {
    if ($code === 'BYPASS') {
        return [
            'card_code' => 'BYPASS',
            'total_mb' => 0,
            'used_mb' => 0,
            'total_minutes' => 0,
            'used_minutes' => 0,
            'download_speed' => 0,
            'upload_speed' => 0,
            'max_devices' => 9999,
            'status' => 'active',
            'expire_date' => null,
            'expire_days' => 0,
            'bind_mac' => 0
        ];
    }
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM cards WHERE card_code = ?');
    $stmt->execute([$code]);
    return $stmt->fetch();
}

function updateCardUsage($code, $mb_used, $minutes_used) {
    $db = getDB();
    $stmt = $db->prepare('
        UPDATE cards 
        SET used_mb = used_mb + ?, used_minutes = used_minutes + ?
        WHERE card_code = ?
    ');
    return $stmt->execute([$mb_used, $minutes_used, $code]);
}

function setCardFirstLogin($code) {
    $db = getDB();
    $stmt = $db->prepare('
        UPDATE cards SET first_login = CURRENT_TIMESTAMP
        WHERE card_code = ? AND first_login IS NULL
    ');
    return $stmt->execute([$code]);
}

function isCardValid($card) {
    if (!$card) return false;
    if ($card['card_code'] === 'BYPASS') return true; // كود تخطي الماك دائماً صالح
    if ($card['status'] !== 'active') return false;

    // فحص الداتا
    if ($card['total_mb'] > 0 && $card['used_mb'] >= $card['total_mb']) return false;

    // فحص الوقت
    if ($card['total_minutes'] > 0 && $card['used_minutes'] >= $card['total_minutes']) return false;

    // فحص تاريخ الانتهاء الثابت
    if ($card['expire_date'] && strtotime($card['expire_date']) < time()) return false;

    // فحص تاريخ الانتهاء النسبي (منذ أول دخول)
    if (!empty($card['expire_days']) && $card['expire_days'] > 0 && $card['first_login']) {
        $expire_time = strtotime($card['first_login']) + ($card['expire_days'] * 86400);
        if (time() > $expire_time) return false;
    }

    return true;
}

// =================== ONLINE USERS ===================

function addOnlineUser($card_code, $ip, $mac, $device) {
    $db = getDB();
    // امسح لو موجود قبل كده
    $db->prepare('DELETE FROM online_users WHERE ip_address = ?')->execute([$ip]);
    
    $stmt = $db->prepare('
        INSERT INTO online_users (card_code, ip_address, mac_address, device_name, login_time, last_seen)
        VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
    ');
    return $stmt->execute([$card_code, $ip, $mac, $device]);
}

function removeOnlineUser($ip) {
    $db = getDB();
    $stmt = $db->prepare('DELETE FROM online_users WHERE ip_address = ?');
    return $stmt->execute([$ip]);
}

function getOnlineUser($ip) {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM online_users WHERE ip_address = ?');
    $stmt->execute([$ip]);
    return $stmt->fetch();
}

function updateLastSeen($ip) {
    $db = getDB();
    $stmt = $db->prepare('UPDATE online_users SET last_seen = CURRENT_TIMESTAMP WHERE ip_address = ?');
    return $stmt->execute([$ip]);
}

// =================== LOGS ===================

function addLog($card_code, $action) {
    $db = getDB();
    $stmt = $db->prepare('INSERT INTO card_logs (card_code, action, created_at) VALUES (?, ?, CURRENT_TIMESTAMP)');
    return $stmt->execute([$card_code, $action]);
}

// =================== SETTINGS ===================

/**
 * إرجاع إعدادات الموقع مع قيم افتراضية محمية في حال كان الجدول فارغاً
 */
function getSettings($force_reload = false) {
    static $_settings_cache = null;
    if ($force_reload) {
        $_settings_cache = null;
    }
    if ($_settings_cache !== null) return $_settings_cache;

    $defaults = [
        'id'              => 1,
        'site_name'       => 'ELMAJIKU Hotspot',
        'login_title'     => 'بوابة تسجيل الدخول للإنترنت',
        'portal_title'    => 'أهلاً بك في شبكتنا',
        'portal_welcome'  => 'أدخل كود الكارت للدخول',
        'primary_color'   => '#00d4ff',
        'secondary_color' => '#7c3aed',
        'accent_color'    => '#22c55e',
        'session_timeout' => 3600,
        'auto_refresh'    => 0,
        'trial_enabled'   => 1,
        'trial_mb'        => 50,
        'trial_min'       => 10,
        'device_model'    => '',
        'firmware_version'=> '',
        'brand_name'      => '',
        'brute_force_enabled'   => 1,
        'brute_force_duration'  => 15,
        'brute_force_max_attempts' => 5,
    ];
    try {
        $db  = getDB();
        $row = $db->query('SELECT * FROM settings LIMIT 1')->fetch();
        if (!$row) {
            // إنشاء صف إعدادات افتراضي إذا كان الجدول فارغاً
            $db->exec("INSERT OR IGNORE INTO settings (id, site_name, login_title, primary_color, secondary_color)
                       VALUES (1, 'ELMAJIKU Hotspot', 'بوابة تسجيل الدخول للإنترنت', '#00d4ff', '#7c3aed')");
            $row = $db->query('SELECT * FROM settings LIMIT 1')->fetch();
        }
        $_settings_cache = array_merge($defaults, $row ?: []);
    } catch (Exception $e) {
        $_settings_cache = $defaults;
    }
    return $_settings_cache;
}

/**
 * إعادة تحميل الإعدادات (مثلاً بعد الحفظ)
 */
function reloadSettings() {
    getSettings(true);
}

/**
 * تطبيع عنوان الماك لصيغة موحدة AA:BB:CC:DD:EE:FF
 */
function normalizeMac($mac) {
    $mac = strtoupper(trim($mac));
    // إزالة الفواصل المختلفة وإعادة بناء بصيغة موحدة
    $hex = preg_replace('/[^0-9A-F]/', '', $mac);
    if (strlen($hex) !== 12) return strtoupper($mac); // إرجاع كما هو لو الصيغة غريبة
    return implode(':', str_split($hex, 2));
}

// =================== DEVICES ===================

function getDevicesByCard($card_code) {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM devices WHERE card_code = ?');
    $stmt->execute([$card_code]);
    return $stmt->fetchAll();
}

function addDevice($card_code, $mac, $device_name) {
    $db = getDB();
    $stmt = $db->prepare('
        INSERT OR IGNORE INTO devices (card_code, mac_address, device_name)
        VALUES (?, ?, ?)
    ');
    return $stmt->execute([$card_code, $mac, $device_name]);
}

// =================== MAC BYPASS HELPERS ===================

function isMacBypassed($mac) {
    if (empty($mac) || $mac === 'unknown') return false;
    $mac = normalizeMac($mac);
    $db  = getDB();
    // نفحص بالصيغة المطبّعة وبـ UPPER للأمان
    $stmt = $db->prepare('SELECT COUNT(*) FROM bypassed_macs WHERE UPPER(REPLACE(REPLACE(mac_address,"-",":")," ","")) = UPPER(REPLACE(REPLACE(?,"-",":")," ",""))');
    $stmt->execute([$mac]);
    return $stmt->fetchColumn() > 0;
}

function addBypassedMac($mac, $desc) {
    $mac = normalizeMac($mac);
    $db  = getDB();
    $stmt = $db->prepare('INSERT OR IGNORE INTO bypassed_macs (mac_address, description) VALUES (?, ?)');
    return $stmt->execute([$mac, $desc]);
}

function removeBypassedMac($id) {
    $db = getDB();
    $stmt = $db->prepare('DELETE FROM bypassed_macs WHERE id = ?');
    return $stmt->execute([$id]);
}

// =================== BLOCKED MAC HELPERS ===================

function isMacBlocked($mac) {
    if (empty($mac) || $mac === 'unknown') return false;
    $mac = normalizeMac($mac);
    $db  = getDB();
    $stmt = $db->prepare('SELECT COUNT(*) FROM blocked_macs WHERE UPPER(REPLACE(REPLACE(mac_address,"-",":")," ","")) = UPPER(REPLACE(REPLACE(?,"-",":")," ",""))');
    $stmt->execute([$mac]);
    return $stmt->fetchColumn() > 0;
}

function addBlockedMac($mac, $desc) {
    $mac = normalizeMac($mac);
    $db  = getDB();
    $stmt = $db->prepare('INSERT OR IGNORE INTO blocked_macs (mac_address, description) VALUES (?, ?)');
    return $stmt->execute([$mac, $desc]);
}

function removeBlockedMac($id) {
    $db = getDB();
    $stmt = $db->prepare('DELETE FROM blocked_macs WHERE id = ?');
    return $stmt->execute([$id]);
}

function getBlockedMacs() {
    $db = getDB();
    return $db->query('SELECT * FROM blocked_macs ORDER BY created_at DESC')->fetchAll();
}

function getBypassedMacs() {
    $db = getDB();
    return $db->query('SELECT * FROM bypassed_macs ORDER BY created_at DESC')->fetchAll();
}

// =================== PACKAGES HELPERS ===================

function getPackages() {
    $db = getDB();
    return $db->query('SELECT * FROM packages ORDER BY created_at DESC')->fetchAll();
}

function getPackage($id) {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM packages WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->fetch();
}

// =================== BRUTE FORCE PROTECTION ===================

function isIpBlocked($ip) {
    $settings = getSettings();
    if (empty($settings['brute_force_enabled'])) return 0;
    
    $db = getDB();
    $stmt = $db->prepare('SELECT locked_until FROM login_attempts WHERE ip_address = ?');
    $stmt->execute([$ip]);
    $locked_until = $stmt->fetchColumn();
    
    if ($locked_until) {
        $lock_time = strtotime($locked_until);
        $diff = $lock_time - time();
        if ($diff > 0) {
            return $diff; // Return remaining seconds
        } else {
            // Lock expired, remove the lock
            $db->prepare('UPDATE login_attempts SET attempts = 0, locked_until = NULL WHERE ip_address = ?')->execute([$ip]);
        }
    }
    return 0;
}

function registerFailedAttempt($ip, $max_attempts = 5, $duration_minutes = 15) {
    $db = getDB();
    // Check if entry exists
    $stmt = $db->prepare('SELECT * FROM login_attempts WHERE ip_address = ?');
    $stmt->execute([$ip]);
    $row = $stmt->fetch();
    
    if (!$row) {
        $stmt = $db->prepare('INSERT INTO login_attempts (ip_address, attempts, last_attempt) VALUES (?, 1, CURRENT_TIMESTAMP)');
        $stmt->execute([$ip]);
        $attempts = 1;
    } else {
        $attempts = $row['attempts'] + 1;
        $stmt = $db->prepare('UPDATE login_attempts SET attempts = ?, last_attempt = CURRENT_TIMESTAMP WHERE ip_address = ?');
        $stmt->execute([$attempts, $ip]);
    }
    
    if ($attempts >= $max_attempts) {
        // Lock the IP
        $locked_until = date('Y-m-d H:i:s', time() + ($duration_minutes * 60));
        $stmt = $db->prepare('UPDATE login_attempts SET locked_until = ? WHERE ip_address = ?');
        $stmt->execute([$locked_until, $ip]);
        return true; // Locked
    }
    return false; // Not locked yet
}

function clearFailedAttempts($ip) {
    $db = getDB();
    $stmt = $db->prepare('DELETE FROM login_attempts WHERE ip_address = ?');
    return $stmt->execute([$ip]);
}
