<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isAdminLoggedIn() {
    if (!isset($_SESSION['admin_id'])) return false;
    if (!isset($_SESSION['last_active'])) return false;
    if (time() - $_SESSION['last_active'] > SESSION_TIMEOUT) {
        session_destroy();
        return false;
    }
    $_SESSION['last_active'] = time();
    return true;
}

function requireAdmin() {
    if (!isAdminLoggedIn()) {
        header('Location: ' . ADMIN_URL . '/index.php');
        exit;
    }
}

function adminLogin($username, $password) {
    $db = getDB();
    $stmt = $db->prepare('SELECT * FROM admins WHERE username = ?');
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id']   = $admin['id'];
        $_SESSION['admin_user'] = $admin['username'];
        $_SESSION['last_active'] = time();
        return true;
    }
    return false;
}

function adminLogout() {
    session_destroy();
    header('Location: ' . ADMIN_URL . '/index.php');
    exit;
}
