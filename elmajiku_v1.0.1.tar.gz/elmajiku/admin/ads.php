<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

$success = '';
$error = '';

// مجلد الرفع
$upload_dir = SITE_ROOT . '/uploads/ads/';
if (!file_exists($upload_dir)) {
    @mkdir($upload_dir, 0777, true);
}

// معالجة طلبات POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. إضافة إعلان جديد
    if (isset($_POST['action']) && $_POST['action'] === 'add_ad') {
        $title = trim($_POST['title'] ?? '');
        $link_url = trim($_POST['link_url'] ?? '');
        $sort_order = intval($_POST['sort_order'] ?? 0);
        
        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $error = 'يرجى تحديد صورة للإعلان';
        } else {
            $file = $_FILES['image'];
            $allowed_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $file_info = pathinfo($file['name']);
            $ext = strtolower($file_info['extension'] ?? '');
            
            if (!in_array($ext, $allowed_exts)) {
                $error = 'صيغة الصورة غير مدعومة. الصيغ المسموحة: JPG, PNG, GIF, WEBP';
            } else {
                $filename = 'ad_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
                $dest_path = $upload_dir . $filename;
                
                if (move_uploaded_file($file['tmp_name'], $dest_path)) {
                    $image_path = 'uploads/ads/' . $filename;
                    $stmt = $db->prepare('INSERT INTO ads (title, image_path, link_url, sort_order, status) VALUES (?, ?, ?, ?, 1)');
                    if ($stmt->execute([$title, $image_path, $link_url, $sort_order])) {
                        $success = 'تم رفع وإضافة الإعلان بنجاح';
                    } else {
                        @unlink($dest_path);
                        $error = 'حدث خطأ أثناء حفظ الإعلان في قاعدة البيانات';
                    }
                } else {
                    $error = 'فشل رفع الصورة، يرجى التحقق من صلاحيات المجلد بالراوتر';
                }
            }
        }
    }
    
    // 2. تغيير الحالة (تفعيل / تعطيل)
    if (isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
        $ad_id = intval($_POST['id'] ?? 0);
        $stmt = $db->prepare('SELECT status FROM ads WHERE id = ?');
        $stmt->execute([$ad_id]);
        $current_status = $stmt->fetchColumn();
        
        if ($current_status !== false) {
            $new_status = $current_status ? 0 : 1;
            $stmt = $db->prepare('UPDATE ads SET status = ? WHERE id = ?');
            $stmt->execute([$new_status, $ad_id]);
            $success = 'تم تحديث حالة الإعلان بنجاح';
        }
    }

    // 3. حذف إعلان
    if (isset($_POST['action']) && $_POST['action'] === 'delete_ad') {
        $ad_id = intval($_POST['id'] ?? 0);
        $stmt = $db->prepare('SELECT image_path FROM ads WHERE id = ?');
        $stmt->execute([$ad_id]);
        $image_path = $stmt->fetchColumn();
        
        if ($image_path) {
            $full_path = SITE_ROOT . '/' . $image_path;
            if (file_exists($full_path)) {
                @unlink($full_path);
            }
            $stmt = $db->prepare('DELETE FROM ads WHERE id = ?');
            $stmt->execute([$ad_id]);
            $success = 'تم حذف الإعلان بالكامل';
        }
    }
    
    // 4. تحديث الترتيب
    if (isset($_POST['action']) && $_POST['action'] === 'update_order') {
        $ad_id = intval($_POST['id'] ?? 0);
        $sort_order = intval($_POST['sort_order'] ?? 0);
        $stmt = $db->prepare('UPDATE ads SET sort_order = ? WHERE id = ?');
        $stmt->execute([$sort_order, $ad_id]);
        $success = 'تم تحديث ترتيب العرض بنجاح';
    }
}

// جلب جميع الإعلانات
$ads = $db->query('SELECT * FROM ads ORDER BY sort_order ASC, created_at DESC')->fetchAll();

$page_title = 'إدارة الإعلانات والعروض';
$active_page = 'ads';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="main">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
    <div>
      <h1 style="font-size:1.6rem; font-weight:800; background:linear-gradient(90deg, #fff, var(--primary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">📢 إدارة الإعلانات والعروض</h1>
      <p style="color:var(--text-muted); font-size:0.85rem; margin-top:4px;">ارفع صور إعلانات وعروض الشبكة لتظهر للعملاء في أعلى صفحة تسجيل الدخول وصفحة العروض المخصصة.</p>
    </div>
  </div>

  <?php if ($success): ?>
    <div class="alert success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="alert danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; align-items: start;">
    
    <!-- كارت رفع إعلان جديد -->
    <div class="box">
      <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:20px; border-bottom:1px solid var(--border); padding-bottom:10px; color:var(--primary);">➕ إضافة إعلان أو عرض جديد</h3>
      <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add_ad">
        
        <div style="margin-bottom:15px;">
          <label style="display:block; margin-bottom:8px; font-size:0.82rem; font-weight:600;">عنوان الإعلان (اختياري)</label>
          <input type="text" name="title" placeholder="مثال: خصم 50% على الباقة الأسبوعية">
        </div>
        
        <div style="margin-bottom:15px;">
          <label style="display:block; margin-bottom:8px; font-size:0.82rem; font-weight:600;">رابط العرض (اختياري)</label>
          <input type="text" name="link_url" placeholder="مثال: http://facebook.com/myshop">
        </div>
        
        <div style="margin-bottom:15px; display: grid; grid-template-columns: 1fr; gap: 10px;">
          <div>
            <label style="display:block; margin-bottom:8px; font-size:0.82rem; font-weight:600;">صورة الإعلان <span style="color:var(--red);">*</span></label>
            <input type="file" name="image" required style="width:100%; padding:10px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:#fff;">
            <span style="font-size:0.7rem; color:var(--text-muted); display:block; margin-top:4px;">يفضل أبعاد عريضة (مثلاً 800x400 بكسل) وبصيغة JPG أو PNG.</span>
          </div>
        </div>

        <div style="margin-bottom:20px;">
          <label style="display:block; margin-bottom:8px; font-size:0.82rem; font-weight:600;">ترتيب العرض</label>
          <input type="number" name="sort_order" value="0" min="0" style="width:100%;">
        </div>
        
        <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center;">📤 رفع ونشر الإعلان</button>
      </form>
    </div>

    <!-- قائمة الإعلانات الحالية -->
    <div class="box">
      <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:20px; border-bottom:1px solid var(--border); padding-bottom:10px;">📋 الإعلانات والعروض الحالية (<?= count($ads) ?>)</h3>
      
      <?php if (empty($ads)): ?>
        <div style="text-align:center; padding:40px; color:var(--text-muted);">
          <span style="font-size:3rem; display:block; margin-bottom:10px;">📢</span>
          لا توجد إعلانات مرفوعة حالياً. ابدأ برفع أول إعلان لعرضه للعملاء.
        </div>
      <?php else: ?>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 20px;">
          <?php foreach ($ads as $ad): ?>
            <div style="background:rgba(255,255,255,0.02); border:1px solid var(--border); border-radius:16px; overflow:hidden; display:flex; flex-direction:column; transition:all 0.2s;">
              
              <!-- صورة الإعلان -->
              <div style="width:100%; height:130px; background-image:url('<?= BASE_URL ?>/<?= htmlspecialchars($ad['image_path']) ?>'); background-size:cover; background-position:center; position:relative; border-bottom:1px solid var(--border);">
                <!-- شارة الحالة -->
                <span style="position:absolute; top:10px; right:10px; font-size:0.7rem; font-weight:700; padding:4px 8px; border-radius:8px; backdrop-filter:blur(8px); background:<?= $ad['status'] ? 'rgba(34,197,94,0.2)' : 'rgba(239,68,68,0.2)' ?>; color:<?= $ad['status'] ? '#22c55e' : '#ef4444' ?>; border:1px solid <?= $ad['status'] ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)' ?>;">
                  <?= $ad['status'] ? 'نشط' : 'معطل' ?>
                </span>
              </div>
              
              <!-- تفاصيل الإعلان -->
              <div style="padding:15px; flex:1; display:flex; flex-direction:column; gap:8px;">
                <h4 style="font-size:0.9rem; font-weight:700; color:#fff; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;"><?= htmlspecialchars($ad['title'] ?: 'بدون عنوان') ?></h4>
                <?php if ($ad['link_url']): ?>
                  <a href="<?= htmlspecialchars($ad['link_url']) ?>" target="_blank" style="font-size:0.72rem; color:var(--primary); text-decoration:none; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;">🔗 <?= htmlspecialchars($ad['link_url']) ?></a>
                <?php else: ?>
                  <span style="font-size:0.72rem; color:var(--text-muted);">لا يوجد رابط توجيه</span>
                <?php endif; ?>
                
                <!-- تغيير الترتيب -->
                <form method="POST" style="display:flex; align-items:center; gap:8px; margin-top:5px;">
                  <input type="hidden" name="action" value="update_order">
                  <input type="hidden" name="id" value="<?= $ad['id'] ?>">
                  <span style="font-size:0.75rem; color:var(--text-muted);">الترتيب:</span>
                  <input type="number" name="sort_order" value="<?= $ad['sort_order'] ?>" min="0" onchange="this.form.submit()" style="padding:4px 8px; font-size:0.78rem; text-align:center; width:60px; height:28px;">
                </form>
              </div>
              
              <!-- أزرار الإجراءات -->
              <div style="padding:10px 15px; border-top:1px solid var(--border); background:rgba(0,0,0,0.1); display:flex; justify-content:space-between; gap:10px;">
                <form method="POST" style="flex:1;">
                  <input type="hidden" name="action" value="toggle_status">
                  <input type="hidden" name="id" value="<?= $ad['id'] ?>">
                  <button type="submit" class="btn <?= $ad['status'] ? 'btn-secondary' : 'btn-success' ?>" style="width:100%; font-size:0.75rem; height:32px; padding:0; justify-content:center;">
                    <?= $ad['status'] ? '⏸️ تعطيل' : '▶️ تفعيل' ?>
                  </button>
                </form>
                
                <form method="POST" style="flex:1;" onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذا الإعلان نهائياً؟');">
                  <input type="hidden" name="action" value="delete_ad">
                  <input type="hidden" name="id" value="<?= $ad['id'] ?>">
                  <button type="submit" class="btn btn-danger" style="width:100%; font-size:0.75rem; height:32px; padding:0; justify-content:center;">
                    🗑️ حذف
                  </button>
                </form>
              </div>

            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
