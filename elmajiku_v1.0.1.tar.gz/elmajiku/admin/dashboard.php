<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// إحصائيات
$total_cards   = $db->query("SELECT COUNT(*) FROM cards")->fetchColumn();
$active_cards  = $db->query("SELECT COUNT(*) FROM cards WHERE status='active'")->fetchColumn();
$online_count  = $db->query("SELECT COUNT(*) FROM online_users")->fetchColumn();
$expired_cards = $db->query("SELECT COUNT(*) FROM cards WHERE status='expired' OR (expire_date IS NOT NULL AND expire_date < datetime('now'))")->fetchColumn();
$disabled_cards= $db->query("SELECT COUNT(*) FROM cards WHERE status='disabled'")->fetchColumn();

// إجمالي الداتا المستهلكة (MB)
$total_data_mb = $db->query("SELECT COALESCE(SUM(used_mb),0) FROM cards")->fetchColumn();

// آخر 7 أيام - بيانات الرسم البياني
$chart_labels = [];
$chart_data   = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chart_labels[] = date('D', strtotime("-$i days"));
    $stmt = $db->prepare("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%login%' AND date(created_at) = ?");
    $stmt->execute([$date]);
    $chart_data[] = (int)$stmt->fetchColumn();
}

// توزيع الكروت للرسم الدائري
$donut_data = [(int)$active_cards, (int)$expired_cards, (int)$disabled_cards];

// المتصلين الآن
$online_users = $db->query("
    SELECT ou.*, c.total_mb, c.used_mb, c.total_minutes, c.used_minutes,
           CAST((strftime('%s','now') - strftime('%s', ou.login_time)) / 60 AS INTEGER) as session_min
    FROM online_users ou
    LEFT JOIN cards c ON c.card_code = ou.card_code
    ORDER BY ou.login_time DESC
")->fetchAll();

// آخر 8 عمليات
$recent_logs = $db->query("SELECT * FROM card_logs ORDER BY created_at DESC LIMIT 8")->fetchAll();

// أكثر الكروت استخداماً
$top_cards = $db->query("SELECT card_code, used_mb, used_minutes, status FROM cards WHERE used_mb > 0 ORDER BY used_mb DESC LIMIT 5")->fetchAll();

// معلومات النظام
$uptime    = trim(@shell_exec("uptime | awk -F'up ' '{print $2}' | awk -F',' '{print $1}'"));
$load      = trim(@shell_exec("cat /proc/loadavg | awk '{print $1}'"));
$mem_total = (int)trim(@shell_exec("grep MemTotal /proc/meminfo | awk '{print $2}'"));
$mem_free  = (int)trim(@shell_exec("grep MemAvailable /proc/meminfo | awk '{print $2}'"));
$mem_pct   = $mem_total ? round(($mem_total - $mem_free) / $mem_total * 100) : 0;
?>
<?php
$page_title  = 'الرئيسية';
$active_page = 'dashboard';
$path_prefix = '';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<style>
/* ===== DASHBOARD SPECIFIC ===== */
.stats-grid {
  display:grid; grid-template-columns:repeat(auto-fit, minmax(210px, 1fr)); gap:18px;
  margin-bottom:24px;
}
.stat-card {
  background:var(--card-bg); border-radius:16px; padding:22px;
  border:1px solid var(--border); position:relative; overflow:hidden;
  cursor:default; transition:transform 0.2s, border-color 0.2s, box-shadow 0.2s;
  backdrop-filter:blur(10px);
}
.stat-card:hover { transform:translateY(-3px); background:var(--card-bg-hover); border-color:rgba(255,255,255,0.1); box-shadow:0 12px 32px rgba(0,0,0,0.3); }
.stat-card::before { content:''; position:absolute; top:0; left:0; right:0; height:3px; }
.stat-card.cyan::before   { background:linear-gradient(90deg,var(--primary),#0070ff); }
.stat-card.green::before  { background:linear-gradient(90deg,var(--accent),#34d399); }
.stat-card.purple::before { background:linear-gradient(90deg,var(--secondary),#a855f7); }
.stat-card.red::before    { background:linear-gradient(90deg,#ef4444,#f97316); }
.stat-card.yellow::before { background:linear-gradient(90deg,#f59e0b,#fbbf24); }

.stat-icon {
  width:44px; height:44px; border-radius:12px;
  display:flex; align-items:center; justify-content:center;
  font-size:1.3rem; margin-bottom:14px;
}
.cyan .stat-icon   { background:rgba(0,212,255,0.1); }
.green .stat-icon  { background:rgba(34,197,94,0.1); }
.purple .stat-icon { background:rgba(124,58,237,0.1); }
.red .stat-icon    { background:rgba(239,68,68,0.1); }
.yellow .stat-icon { background:rgba(245,158,11,0.1); }

.stat-num {
  font-size:2.2rem; font-weight:800; line-height:1; margin-bottom:6px;
  animation:countUp 0.6s ease forwards;
}
.cyan .stat-num   { color:var(--primary); }
.green .stat-num  { color:var(--accent); }
.purple .stat-num { color:var(--secondary); }
.red .stat-num    { color:#ef4444; }
.yellow .stat-num { color:#f59e0b; }
.stat-label { color:var(--text-muted); font-size:0.8rem; }
.stat-sub { font-size:0.72rem; color:var(--text-muted); margin-top:8px; padding-top:8px; border-top:1px solid var(--border); }

/* الشريط العلوي */
.live-badge {
  display:flex; align-items:center; gap:6px;
  background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.2);
  border-radius:20px; padding:6px 14px; font-size:0.78rem; color:var(--accent);
}
.live-dot { width:7px; height:7px; border-radius:50%; background:var(--accent); animation:pulse 1.5s infinite; }
.refresh-btn {
  background:rgba(255,255,255,0.04); border:1px solid var(--border);
  color:var(--text); padding:7px 14px; border-radius:9px;
  cursor:pointer; font-size:0.82rem; font-family:inherit; transition:all 0.2s;
}
.refresh-btn:hover { background:rgba(255,255,255,0.08); border-color:var(--primary); color:var(--primary); }

/* الرسوم البيانية */
.charts-row { display:grid; grid-template-columns:2fr 1fr; gap:16px; margin-bottom:24px; }
.box { background:var(--card-bg); border-radius:16px; padding:22px; border:1px solid var(--border); backdrop-filter:blur(10px); }
.box:hover { background:var(--card-bg-hover); }
.box-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:18px; }
.box-title { font-size:0.95rem; font-weight:700; color:#cbd5e1; }
.box-sub { font-size:0.72rem; color:var(--text-muted); margin-top:2px; }
.chart-wrap { position:relative; }

/* الجدول */
.bottom-grid { display:grid; grid-template-columns:3fr 2fr; gap:16px; margin-bottom:24px; }
table { width:100%; border-collapse:collapse; font-size:0.82rem; }
th { color:var(--text-muted); padding:10px 12px; text-align:right; border-bottom:1px solid var(--border); font-weight:600; font-size:0.76rem; text-transform:uppercase; letter-spacing:0.5px; }
td { padding:11px 12px; border-bottom:1px solid rgba(255,255,255,0.03); color:#94a3b8; vertical-align:middle; }
tr:last-child td { border:none; }
tr:hover td { background:rgba(255,255,255,0.025); }
.mono { font-family:monospace; font-weight:700; color:var(--primary); font-size:0.85rem; }
.badge { padding:3px 10px; border-radius:20px; font-size:0.72rem; font-weight:700; display:inline-block; }
.badge.active   { background:rgba(16,185,129,0.15); color:var(--accent); }
.badge.expired  { background:rgba(239,68,68,0.15); color:#ef4444; }
.badge.disabled { background:rgba(100,116,139,0.15); color:var(--text-muted); }
.badge.online   { background:rgba(16,185,129,0.15); color:var(--accent); animation:pulse 2s infinite; }

.kick-btn {
  background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.25);
  color:#ef4444; padding:4px 10px; border-radius:6px;
  cursor:pointer; font-size:0.74rem; font-weight:700;
  font-family:'Cairo',sans-serif; transition:all 0.2s;
}
.kick-btn:hover { background:rgba(239,68,68,0.25); }

/* مراقبة النظام */
.sys-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; margin-bottom:24px; }
.sys-card { background:var(--card-bg); border-radius:14px; padding:18px; border:1px solid var(--border); backdrop-filter:blur(10px); }
.sys-label { font-size:0.75rem; color:var(--text-muted); margin-bottom:8px; font-weight:700; text-transform:uppercase; letter-spacing:1px; }
.sys-value { font-size:1.3rem; font-weight:800; color:var(--text); }
.sys-bar-wrap { background:rgba(255,255,255,0.06); border-radius:20px; height:6px; margin-top:10px; overflow:hidden; }
.sys-bar { height:6px; border-radius:20px; transition:width 1s ease; }
.sys-bar.ok     { background:linear-gradient(90deg,var(--accent),#34d399); }
.sys-bar.warn   { background:linear-gradient(90deg,#f59e0b,#fbbf24); }
.sys-bar.danger { background:linear-gradient(90deg,#ef4444,#f97316); }

/* سجل النشاط */
.log-item { display:flex; align-items:flex-start; gap:12px; padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.03); }
.log-item:last-child { border:none; }
.log-dot { width:8px; height:8px; border-radius:50%; margin-top:5px; flex-shrink:0; }
.log-dot.login   { background:var(--accent); }
.log-dot.kick    { background:#ef4444; }
.log-dot.default { background:var(--primary); }
.log-action { font-size:0.82rem; color:var(--text); line-height:1.4; }
.log-time { font-size:0.7rem; color:var(--text-muted); margin-top:2px; }
.log-code { font-family:monospace; color:var(--secondary); font-weight:700; }

/* أعلى الكروت */
.top-card-item { display:flex; align-items:center; gap:12px; padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.03); }
.top-card-item:last-child { border:none; }
.rank { width:26px; height:26px; border-radius:8px; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:0.78rem; }
.rank-1 { background:rgba(245,158,11,0.2); color:#f59e0b; }
.rank-2 { background:rgba(156,163,175,0.2); color:#9ca3af; }
.rank-3 { background:rgba(180,83,9,0.2); color:#b45309; }
.rank-n { background:rgba(255,255,255,0.05); color:var(--text-muted); }
.top-code { font-family:monospace; color:var(--primary); font-weight:700; font-size:0.88rem; flex:1; }
.top-mb { font-size:0.78rem; color:var(--text-muted); }
.top-bar-wrap { background:rgba(255,255,255,0.06); border-radius:10px; height:4px; flex:1; margin:0 8px; }
.top-bar { height:4px; border-radius:10px; background:linear-gradient(90deg,var(--primary),var(--secondary)); }

/* الحالة الفارغة */
.empty-state { text-align:center; padding:40px 20px; color:var(--text-muted); }
.empty-state .icon { font-size:2.5rem; margin-bottom:12px; opacity:0.4; }
.empty-state p { font-size:0.85rem; }

@keyframes countUp {
  from { opacity:0; transform:translateY(10px); }
  to   { opacity:1; transform:translateY(0); }
}

@media (max-width:1200px) {
  .stats-grid  { grid-template-columns:repeat(2,1fr); }
  .charts-row  { grid-template-columns:1fr; }
  .bottom-grid { grid-template-columns:1fr; }
  .sys-grid    { grid-template-columns:repeat(2,1fr); }
}
@media (max-width:600px) {
  .sys-grid    { grid-template-columns:1fr; }
  .stats-grid  { grid-template-columns:1fr; }
}
</style>

<div class="main">
  <!-- TOPBAR -->
  <div class="topbar">
    <div>
      <h1>📊 لوحة التحكم الرئيسية</h1>
      <p style="color:var(--text-muted); font-size:0.82rem; margin-top:3px;">مرحباً بك – <?= date('l، d F Y') ?></p>
    </div>
    <div style="display:flex; gap:12px; align-items:center;">
      <div class="live-badge">
        <span class="live-dot"></span>
        مباشر – يتحدث كل 10 ثوانٍ
      </div>
      <button class="refresh-btn" onclick="refreshAll()">🔄 تحديث</button>
    </div>
  </div>

  <!-- STATS GRID -->
  <div class="stats-grid">
    <div class="stat-card cyan">
      <div class="stat-icon">🎫</div>
      <div class="stat-num" id="s-total"><?= $total_cards ?></div>
      <div class="stat-label">إجمالي الكروت</div>
      <div class="stat-sub">نشطة: <strong style="color:var(--primary)"><?= $active_cards ?></strong></div>
    </div>
    <div class="stat-card green">
      <div class="stat-icon">🟢</div>
      <div class="stat-num" id="s-online"><?= $online_count ?></div>
      <div class="stat-label">متصل الآن</div>
      <div class="stat-sub">من إجمالي <?= $active_cards ?> نشط</div>
    </div>
    <div class="stat-card purple">
      <div class="stat-icon">📡</div>
      <div class="stat-num" id="s-data"><?= number_format($total_data_mb, 0) ?></div>
      <div class="stat-label">إجمالي MB مستهلك</div>
      <div class="stat-sub">~ <?= number_format($total_data_mb / 1024, 2) ?> GB</div>
    </div>
    <div class="stat-card red">
      <div class="stat-icon">⛔</div>
      <div class="stat-num" id="s-expired"><?= $expired_cards ?></div>
      <div class="stat-label">كروت منتهية/معطلة</div>
      <div class="stat-sub">معطلة: <?= $disabled_cards ?> | منتهية: <?= $expired_cards ?></div>
    </div>
  </div>

  <!-- SYSTEM MONITOR -->
  <div class="sys-grid">
    <div class="sys-card">
      <div class="sys-label">⏱ وقت التشغيل</div>
      <div class="sys-value" style="font-size:1rem"><?= $uptime ?: 'N/A' ?></div>
    </div>
    <div class="sys-card">
      <div class="sys-label">💾 الذاكرة RAM</div>
      <div class="sys-value"><?= $mem_pct ?>%</div>
      <div class="sys-bar-wrap">
        <div class="sys-bar <?= $mem_pct > 80 ? 'danger' : ($mem_pct > 60 ? 'warn' : 'ok') ?>" style="width:<?= $mem_pct ?>%"></div>
      </div>
    </div>
    <div class="sys-card">
      <div class="sys-label">⚡ حمل المعالج (CPU)</div>
      <div class="sys-value"><?= $load ?: 'N/A' ?></div>
    </div>
  </div>

  <!-- CHARTS -->
  <div class="charts-row">
    <div class="box">
      <div class="box-header">
        <div>
          <div class="box-title">📈 تسجيلات الدخول – آخر 7 أيام</div>
          <div class="box-sub">عدد المستخدمين الذين سجلوا الدخول يومياً</div>
        </div>
      </div>
      <div class="chart-wrap" style="height:200px">
        <canvas id="lineChart"></canvas>
      </div>
    </div>
    <div class="box">
      <div class="box-header">
        <div>
          <div class="box-title">🍩 توزيع الكروت</div>
          <div class="box-sub">نشطة / منتهية / معطلة</div>
        </div>
      </div>
      <div class="chart-wrap" style="height:200px;display:flex;align-items:center;justify-content:center">
        <canvas id="donutChart"></canvas>
      </div>
    </div>
  </div>

  <!-- BOTTOM GRID -->
  <div class="bottom-grid">
    <!-- المتصلين الآن -->
    <div class="box">
      <div class="box-header">
        <div>
          <div class="box-title">🟢 المتصلين الآن</div>
          <div class="box-sub" id="online-count-label"><?= $online_count ?> مستخدم متصل</div>
        </div>
        <button class="refresh-btn" onclick="loadOnline()">🔄</button>
      </div>
      <div id="online-table-wrap">
        <?php if ($online_users): ?>
        <table>
          <tr>
            <th>الكارت</th>
            <th>IP</th>
            <th>الجهاز</th>
            <th>المدة</th>
            <th>الداتا</th>
            <th></th>
          </tr>
          <?php foreach ($online_users as $u): ?>
          <?php
            $mb_pct = ($u['total_mb'] && $u['used_mb']) ? min(100, round($u['used_mb'] / $u['total_mb'] * 100)) : 0;
            $dur = $u['session_min'] >= 60 ? floor($u['session_min']/60).'h '.($u['session_min']%60).'m' : $u['session_min'].'m';
          ?>
          <tr id="row-<?= str_replace('.', '-', htmlspecialchars($u['ip_address'])) ?>">
            <td><span class="mono"><?= htmlspecialchars($u['card_code']) ?></span></td>
            <td style="font-size:0.78rem"><?= htmlspecialchars($u['ip_address']) ?></td>
            <td style="font-size:0.78rem;color:#94a3b8"><?= htmlspecialchars($u['device_name'] ?? '-') ?></td>
            <td><span class="badge online"><?= $dur ?></span></td>
            <td style="font-size:0.78rem">
              <?php if ($u['total_mb']): ?>
                <?= $u['used_mb'] ?>/<?= $u['total_mb'] ?> MB
              <?php else: ?>
                <span style="color:var(--text-muted)">∞</span>
              <?php endif; ?>
            </td>
            <td>
              <button class="kick-btn" onclick="kickUser('<?= htmlspecialchars($u['ip_address']) ?>')">قطع</button>
            </td>
          </tr>
          <?php endforeach; ?>
        </table>
        <?php else: ?>
        <div class="empty-state">
          <div class="icon">👻</div>
          <p>لا يوجد متصلين حالياً</p>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- النشاطات + أعلى الكروت -->
    <div style="display:flex;flex-direction:column;gap:16px">
      <!-- آخر النشاطات -->
      <div class="box">
        <div class="box-header">
          <div class="box-title">⚡ آخر النشاطات</div>
        </div>
        <?php foreach ($recent_logs as $log): ?>
        <?php
          $type = str_contains($log['action'], 'login') ? 'login' : (str_contains($log['action'], 'kick') ? 'kick' : 'default');
        ?>
        <div class="log-item">
          <div class="log-dot <?= $type ?>"></div>
          <div>
            <div class="log-action">
              <span class="log-code"><?= htmlspecialchars($log['card_code']) ?></span>
              – <?= htmlspecialchars($log['action']) ?>
            </div>
            <div class="log-time"><?= date('H:i', strtotime($log['created_at'])) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
        <?php if (!$recent_logs): ?>
        <div class="empty-state" style="padding:20px">
          <p>لا توجد نشاطات بعد</p>
        </div>
        <?php endif; ?>
      </div>

      <!-- أعلى الكروت استهلاكاً -->
      <div class="box">
        <div class="box-header">
          <div class="box-title">🏆 أكثر الكروت استخداماً</div>
        </div>
        <?php $max_mb = $top_cards ? max(array_column($top_cards, 'used_mb')) : 1; ?>
        <?php foreach ($top_cards as $i => $tc): ?>
        <?php $rank_class = ['rank-1','rank-2','rank-3'][$i] ?? 'rank-n'; ?>
        <div class="top-card-item">
          <div class="rank <?= $rank_class ?>"><?= $i+1 ?></div>
          <span class="top-code"><?= htmlspecialchars($tc['card_code']) ?></span>
          <div class="top-bar-wrap">
            <div class="top-bar" style="width:<?= round($tc['used_mb']/$max_mb*100) ?>%"></div>
          </div>
          <div class="top-mb"><?= $tc['used_mb'] ?> MB</div>
        </div>
        <?php endforeach; ?>
        <?php if (!$top_cards): ?>
        <div class="empty-state" style="padding:20px"><p>لا توجد بيانات بعد</p></div>
        <?php endif; ?>
      </div>
    </div>
  </div>

</div><!-- /main -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
// ===== CHART: LINE =====
const lineCtx = document.getElementById('lineChart').getContext('2d');
new Chart(lineCtx, {
  type: 'line',
  data: {
    labels: <?= json_encode($chart_labels) ?>,
    datasets: [{
      label: 'تسجيلات الدخول',
      data: <?= json_encode($chart_data) ?>,
      borderColor: '<?= $settings['primary_color'] ?? '#00d4ff' ?>',
      backgroundColor: 'rgba(0,212,255,0.08)',
      borderWidth: 2.5,
      pointBackgroundColor: '<?= $settings['primary_color'] ?? '#00d4ff' ?>',
      pointRadius: 5, pointHoverRadius: 7,
      fill: true, tension: 0.4
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      x: {
        ticks: { color: '#64748b', font: { family: 'Cairo', size: 11 } },
        grid: { color: 'rgba(255,255,255,0.04)' }
      },
      y: {
        ticks: { color: '#64748b', font: { family: 'Cairo', size: 11 }, stepSize: 1 },
        grid: { color: 'rgba(255,255,255,0.04)' },
        beginAtZero: true
      }
    }
  }
});

// ===== CHART: DONUT =====
const donutCtx = document.getElementById('donutChart').getContext('2d');
new Chart(donutCtx, {
  type: 'doughnut',
  data: {
    labels: ['نشطة', 'منتهية', 'معطلة'],
    datasets: [{
      data: <?= json_encode($donut_data) ?>,
      backgroundColor: ['rgba(16,185,129,0.8)','rgba(239,68,68,0.8)','rgba(100,116,139,0.6)'],
      borderColor: ['#10b981','#ef4444','#475569'],
      borderWidth: 2, hoverOffset: 8
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: { color: '#94a3b8', font: { family: 'Cairo', size: 11 }, padding: 14 }
      }
    },
    cutout: '65%'
  }
});

// ===== KICK USER =====
function kickUser(ip) {
  if (!confirm('قطع اتصال ' + ip + '؟')) return;
  fetch('/elmajiku/api/online.php?kick=1&ip=' + encodeURIComponent(ip))
    .then(r => r.json())
    .then(d => {
      const rowId = ip.replace(/\./g,'-');
      const row = document.getElementById('row-' + rowId);
      if (row) { row.style.transition='opacity 0.4s'; row.style.opacity='0'; setTimeout(()=>row.remove(),400); }
    });
}

// ===== LOAD ONLINE (AJAX) =====
function loadOnline() {
  fetch('/elmajiku/api/online.php')
    .then(r => r.json())
    .then(d => {
      document.getElementById('online-count-label').textContent = d.count + ' مستخدم متصل';
      document.getElementById('s-online').textContent = d.count;
    });
}

// ===== AUTO REFRESH =====
function refreshAll() { loadOnline(); }
setInterval(refreshAll, 10000);

// ===== NUMBER COUNTER ANIMATION =====
document.querySelectorAll('.stat-num').forEach(el => {
  const target = parseInt(el.textContent.replace(/,/g,'')) || 0;
  let current = 0;
  const step = Math.max(1, Math.floor(target / 30));
  const timer = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current.toLocaleString();
    if (current >= target) clearInterval(timer);
  }, 30);
});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
