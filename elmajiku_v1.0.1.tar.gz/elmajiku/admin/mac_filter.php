<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/iptables.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

$success = '';
$error = '';

// معالجة طلبات POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. إضافة ماك للقائمة البيضاء (Bypass)
    if (isset($_POST['action']) && $_POST['action'] === 'add_bypass') {
        $mac = trim($_POST['mac_address'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        
        if (empty($mac)) {
            $error = 'يرجى إدخال عنوان الماك (MAC Address)';
        } else {
            $mac = normalizeMac($mac);
            if (addBypassedMac($mac, $desc)) {
                $success = 'تمت إضافة الجهاز للقائمة البيضاء بنجاح (سيتخطى صفحة الدخول تلقائياً)';
            } else {
                $error = 'الماك مضاف بالفعل في القائمة البيضاء';
            }
        }
    }
    
    // 2. حذف ماك من القائمة البيضاء
    if (isset($_POST['action']) && $_POST['action'] === 'delete_bypass') {
        $id = intval($_POST['id'] ?? 0);
        if (removeBypassedMac($id)) {
            $success = 'تم إزالة الجهاز من القائمة البيضاء';
        }
    }
    
    // 3. إضافة ماك للقائمة السوداء (Block)
    if (isset($_POST['action']) && $_POST['action'] === 'add_blocked') {
        $mac = trim($_POST['mac_address'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        
        if (empty($mac)) {
            $error = 'يرجى إدخال عنوان الماك (MAC Address)';
        } else {
            $mac = normalizeMac($mac);
            if (isMacBypassed($mac)) {
                $error = 'عذراً، هذا الماك موجود في القائمة البيضاء بالفعل. يجب حذفه أولاً لحجبه.';
            } else {
                if (addBlockedMac($mac, $desc)) {
                    // تطبيق القواعد فوراً
                    applyMacFilterRules();
                    $success = 'تم إضافة الجهاز للقائمة السوداء وحجبه عن الشبكة بالكامل';
                } else {
                    $error = 'الماك مضاف بالفعل في القائمة السوداء';
                }
            }
        }
    }
    
    // 4. حذف ماك من القائمة السوداء
    if (isset($_POST['action']) && $_POST['action'] === 'delete_blocked') {
        $id = intval($_POST['id'] ?? 0);
        if (removeBlockedMac($id)) {
            // إعادة تطبيق القواعد فوراً
            applyMacFilterRules();
            $success = 'تم فك حظر الجهاز وإزالته من القائمة السوداء';
        }
    }
}

// جلب القوائم
$bypassed_list = getBypassedMacs();
$blocked_list = getBlockedMacs();

$page_title = 'تصفية وفلترة الـ MAC Address';
$active_page = 'mac_filter';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="main">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
    <div>
      <h1 style="font-size:1.6rem; font-weight:800; background:linear-gradient(90deg, #fff, var(--primary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">💻 تصفية الـ MAC Address</h1>
      <p style="color:var(--text-muted); font-size:0.85rem; margin-top:4px;">تحكم في الأجهزة المتصلة عن طريق عنوان الـ MAC: اسمح بمرورها تلقائياً بدون تسجيل دخول أو احظرها تماماً عن الشبكة.</p>
    </div>
  </div>

  <?php if ($success): ?>
    <div class="alert success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="alert danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: start;">
    
    <!-- ==================== القائمة البيضاء (Bypass) ==================== -->
    <div style="display: flex; flex-direction: column; gap: 20px;">
      
      <!-- إضافة للبيضاء -->
      <div class="box">
        <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:15px; border-bottom:1px solid var(--border); padding-bottom:10px; color:var(--primary);">🟢 إضافة للقائمة البيضاء (Bypass)</h3>
        <p style="font-size:0.78rem; color:var(--text-muted); margin-bottom:15px;">الأجهزة المضافة هنا ستحصل على الإنترنت تلقائياً فور اتصالها بالواي فاي وتتخطى صفحة تسجيل الدخول تماماً.</p>
        <form method="POST">
          <input type="hidden" name="action" value="add_bypass">
          <div style="margin-bottom:12px;">
            <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">عنوان الـ MAC</label>
            <input type="text" name="mac_address" placeholder="مثال: AA:BB:CC:DD:EE:FF" required>
          </div>
          <div style="margin-bottom:15px;">
            <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">اسم الجهاز / الوصف</label>
            <input type="text" name="description" placeholder="مثال: هاتف صاحب المحل">
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center;">➕ إضافة وتخطي</button>
        </form>
      </div>

      <!-- عرض البيضاء -->
      <div class="box">
        <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:15px; border-bottom:1px solid var(--border); padding-bottom:10px;">📋 الأجهزة المستثناة (البيضاء) (<?= count($bypassed_list) ?>)</h3>
        
        <?php if (empty($bypassed_list)): ?>
          <div style="text-align:center; padding:30px; color:var(--text-muted); font-size:0.8rem;">
            لا توجد أجهزة مستثناة حالياً.
          </div>
        <?php else: ?>
          <div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; text-align:right; font-size:0.85rem;">
              <thead>
                <tr style="border-bottom:1px solid var(--border); color:var(--text-muted);">
                  <th style="padding:10px 5px;">الماك</th>
                  <th style="padding:10px 5px;">الوصف</th>
                  <th style="padding:10px 5px; text-align:center;">إجراء</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($bypassed_list as $b): ?>
                  <tr style="border-bottom:1px solid rgba(255,255,255,0.02); height:45px;">
                    <td style="padding:5px; font-family:monospace; font-weight:700; color:var(--primary);"><?= htmlspecialchars($b['mac_address']) ?></td>
                    <td style="padding:5px; color:#fff;"><?= htmlspecialchars($b['description'] ?: 'بدون وصف') ?></td>
                    <td style="padding:5px; text-align:center;">
                      <form method="POST" style="display:inline;" onsubmit="return confirm('هل تريد إلغاء استثناء هذا الجهاز؟');">
                        <input type="hidden" name="action" value="delete_bypass">
                        <input type="hidden" name="id" value="<?= $b['id'] ?>">
                        <button type="submit" class="btn btn-danger" style="padding:4px 8px; font-size:0.75rem; height:28px;">🗑️ حذف</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    </div>

    <!-- ==================== القائمة السوداء (Block) ==================== -->
    <div style="display: flex; flex-direction: column; gap: 20px;">
      
      <!-- إضافة للسوداء -->
      <div class="box">
        <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:15px; border-bottom:1px solid var(--border); padding-bottom:10px; color:var(--red);">🔴 إضافة للقائمة السوداء (الحظر)</h3>
        <p style="font-size:0.78rem; color:var(--text-muted); margin-bottom:15px;">الأجهزة المضافة هنا سيتم عزلها بالكامل عن الراوتر ولن تسحب إنترنت أو تتمكن من تصفح الشبكة.</p>
        <form method="POST">
          <input type="hidden" name="action" value="add_blocked">
          <div style="margin-bottom:12px;">
            <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">عنوان الـ MAC</label>
            <input type="text" name="mac_address" placeholder="مثال: AA:BB:CC:DD:EE:FF" required>
          </div>
          <div style="margin-bottom:15px;">
            <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">السبب / اسم الجهاز</label>
            <input type="text" name="description" placeholder="مثال: مستخدم مخترق أو مزعج">
          </div>
          <button type="submit" class="btn btn-danger" style="width:100%; justify-content:center; background:rgba(239, 68, 68, 0.2); border:1px solid rgba(239,68,68,0.4); color:#ef4444;">🔴 حظر الجهاز نهائياً</button>
        </form>
      </div>

      <!-- عرض السوداء -->
      <div class="box">
        <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:15px; border-bottom:1px solid var(--border); padding-bottom:10px;">🚫 الأجهزة المحظورة (السوداء) (<?= count($blocked_list) ?>)</h3>
        
        <?php if (empty($blocked_list)): ?>
          <div style="text-align:center; padding:30px; color:var(--text-muted); font-size:0.8rem;">
            لا توجد أجهزة محظورة حالياً.
          </div>
        <?php else: ?>
          <div style="overflow-x:auto;">
            <table style="width:100%; border-collapse:collapse; text-align:right; font-size:0.85rem;">
              <thead>
                <tr style="border-bottom:1px solid var(--border); color:var(--text-muted);">
                  <th style="padding:10px 5px;">الماك</th>
                  <th style="padding:10px 5px;">السبب</th>
                  <th style="padding:10px 5px; text-align:center;">إجراء</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($blocked_list as $b): ?>
                  <tr style="border-bottom:1px solid rgba(255,255,255,0.02); height:45px;">
                    <td style="padding:5px; font-family:monospace; font-weight:700; color:var(--red);"><?= htmlspecialchars($b['mac_address']) ?></td>
                    <td style="padding:5px; color:#fff;"><?= htmlspecialchars($b['description'] ?: 'بدون سبب') ?></td>
                    <td style="padding:5px; text-align:center;">
                      <form method="POST" style="display:inline;" onsubmit="return confirm('هل تريد فك حظر هذا الجهاز؟');">
                        <input type="hidden" name="action" value="delete_blocked">
                        <input type="hidden" name="id" value="<?= $b['id'] ?>">
                        <button type="submit" class="btn btn-success" style="padding:4px 8px; font-size:0.75rem; height:28px;">🟢 إلغاء الحظر</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    </div>

  </div>
</div>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
