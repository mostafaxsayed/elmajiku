<?php
/**
 * أداة إصلاح قاعدة بيانات هوتسبوت ELMAJIKU
 * 
 * قم بفتح هذه الصفحة في متصفحك لإصلاح أي مشاكل في جداول قاعدة البيانات:
 * http://192.168.77.1/elmajiku/admin/fix_db.php
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db = getDB();
$report = [];

// 1. فحص وإصلاح جدول card_logs
try {
    $cols = $db->query("PRAGMA table_info(card_logs)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('created_at', $cols)) {
        // إضافة العمود بدون قيمة افتراضية ديناميكية لتجنب خطأ SQLite
        $db->exec("ALTER TABLE card_logs ADD COLUMN created_at DATETIME");
        // تعيين التاريخ الحالي للسجلات القديمة
        $db->exec("UPDATE card_logs SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL");
        $report[] = "<span style='color:#10b981;'>✓ تم إضافة عمود التاريخ (created_at) لجدول السجلات (card_logs) وتحديث السجلات القديمة بنجاح.</span>";
    } else {
        $report[] = "<span>✓ جدول السجلات (card_logs) سليم ويحتوي على عمود التاريخ.</span>";
    }
} catch (Exception $e) {
    $report[] = "<span style='color:#ef4444;'>خطأ أثناء فحص جدول السجلات: " . $e->getMessage() . "</span>";
}

// 2. فحص وإصلاح جدول settings
try {
    $cols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('portal_title', $cols)) {
        $db->exec("ALTER TABLE settings ADD COLUMN portal_title TEXT NOT NULL DEFAULT 'أهلاً بك في شبكة ELMAJIKU'");
        $db->exec("ALTER TABLE settings ADD COLUMN portal_welcome TEXT NOT NULL DEFAULT 'أدخل كود الكارت لتسجيل الدخول للإنترنت'");
        $report[] = "<span style='color:#10b981;'>✓ تم ترقية جدول الإعدادات وإضافة حقول الترحيب الخاصة بالعملاء.</span>";
    } else {
        $report[] = "<span>✓ جدول الإعدادات سليم ويحتوي على كافة الحقول.</span>";
    }
} catch (Exception $e) {
    $report[] = "<span style='color:#ef4444;'>خطأ أثناء فحص جدول الإعدادات: " . $e->getMessage() . "</span>";
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إصلاح قاعدة البيانات - ELMAJIKU</title>
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<style>
body {
  font-family: 'Tajawal', sans-serif;
  background-color: #0b0d19;
  color: #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  margin: 0;
  padding: 20px;
}
.card {
  background: rgba(22, 27, 39, 0.75);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 20px;
  padding: 40px;
  width: 100%;
  max-width: 480px;
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
  text-align: center;
}
h2 {
  background: linear-gradient(135deg, #00d4ff, #7c3aed);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 25px;
}
.report-list {
  text-align: right;
  background: #111422;
  padding: 20px;
  border-radius: 12px;
  margin-bottom: 25px;
  border: 1px solid rgba(255, 255, 255, 0.05);
  font-size: 0.9rem;
  line-height: 1.6;
}
.report-item {
  margin-bottom: 10px;
  display: flex;
  align-items: center;
  gap: 10px;
}
.btn {
  padding: 12px 24px;
  background: linear-gradient(135deg, #00d4ff, #7c3aed);
  color: #fff;
  border: none;
  border-radius: 12px;
  cursor: pointer;
  font-weight: 700;
  font-family: inherit;
  font-size: 0.95rem;
  text-decoration: none;
  display: inline-block;
}
.btn:hover {
  opacity: 0.9;
}
</style>
</head>
<body>

<div class="card">
  <h2>🔧 تقرير تهيئة وإصلاح الجداول</h2>
  
  <div class="report-list">
    <?php foreach ($report as $item): ?>
      <div class="report-item">▪ <?= $item ?></div>
    <?php endforeach; ?>
  </div>

  <a href="reports/index.php" class="btn">العودة لشاشة التقارير</a>
</div>

</body>
</html>
