<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$success = '';

// مسح السجلات
if (isset($_GET['clear']) && $_GET['clear'] === 'all') {
    $db->exec('DELETE FROM card_logs');
    $success = 'تم مسح جميع سجلات النظام بنجاح!';
}

// فلترة وبحث
$where = '1=1';
$params = [];
if (!empty($_GET['search'])) {
    $where .= ' AND (card_code LIKE ? OR action LIKE ?)';
    $params[] = '%' . $_GET['search'] . '%';
    $params[] = '%' . $_GET['search'] . '%';
}
if (!empty($_GET['date_from'])) {
    $where .= ' AND date(created_at) >= ?';
    $params[] = $_GET['date_from'];
}
if (!empty($_GET['date_to'])) {
    $where .= ' AND date(created_at) <= ?';
    $params[] = $_GET['date_to'];
}
if (!empty($_GET['action_type'])) {
    if ($_GET['action_type'] === 'login') {
        $where .= ' AND action LIKE "%login%"';
    } elseif ($_GET['action_type'] === 'logout') {
        $where .= ' AND (action LIKE "%logout%" OR action LIKE "%kick%")';
    } elseif ($_GET['action_type'] === 'broadcast') {
        $where .= ' AND action LIKE "%broadcast%"';
    }
}

// إحصائيات
$today_logins = $db->query("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%login%' AND date(created_at) = date('now', 'localtime')")->fetchColumn();
$today_kicks = $db->query("SELECT COUNT(*) FROM card_logs WHERE (action LIKE '%kick%' OR action LIKE '%logout%') AND date(created_at) = date('now', 'localtime')")->fetchColumn();
$week_logins = $db->query("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%login%' AND created_at >= datetime('now', '-7 days')")->fetchColumn();
$month_logins = $db->query("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%login%' AND created_at >= datetime('now', '-30 days')")->fetchColumn();

// أكثر الكروت نشاطاً
$top_active = $db->query('
    SELECT card_code, COUNT(*) as count, MAX(created_at) as last_activity
    FROM card_logs
    WHERE card_code != "TRIAL"
    GROUP BY card_code
    ORDER BY count DESC
    LIMIT 10
')->fetchAll();

// السجلات
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 50;
$offset = ($page - 1) * $per_page;

$count_stmt = $db->prepare("SELECT COUNT(*) FROM card_logs WHERE $where");
$count_stmt->execute($params);
$total_count = $count_stmt->fetchColumn();
$total_pages = ceil($total_count / $per_page);

$stmt = $db->prepare("SELECT * FROM card_logs WHERE $where ORDER BY created_at DESC LIMIT $per_page OFFSET $offset");
$stmt->execute($params);
$logs = $stmt->fetchAll();

// إحصائيات الساعات
$hourly_stats = $db->query("
    SELECT strftime('%H', created_at) as hour, COUNT(*) as count
    FROM card_logs
    WHERE created_at >= datetime('now', '-24 hours')
    GROUP BY hour
    ORDER BY hour
")->fetchAll();
?>
<?php
$page_title = 'التقارير والسجلات';
$active_page = 'reports';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
/* Reports specific styles */
.stats { display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:15px; margin-bottom:25px; }
.stat-card { background:var(--card-bg); border-radius:14px; padding:20px; border:1px solid var(--border); text-align:center; transition:transform 0.3s; backdrop-filter: blur(10px); }
.stat-card:hover { transform:translateY(-2px); background: var(--card-bg-hover); border-color: rgba(255,255,255,0.08); }
.stat-card .num { font-size:1.8rem; font-weight:800; margin-bottom:5px; }
.stat-card .label { color:var(--text-muted); font-size:0.78rem; }
.stat-card.green .num { color:var(--accent); }
.stat-card.red .num { color:#ef4444; }
.stat-card.blue .num { color:var(--primary); }
.stat-card.purple .num { color:var(--secondary); }

.toolbar { display:flex; gap:10px; margin-bottom:15px; flex-wrap:wrap; }

table { width:100%; border-collapse:collapse; font-size:0.82rem; }
th { color:var(--text-muted); padding:12px 10px; text-align:right; border-bottom:1px solid var(--border); font-weight:700; font-size:0.78rem; }
td { padding:12px 10px; border-bottom:1px solid rgba(255,255,255,0.04); color:#94a3b8; }
tr:last-child td { border:none; }
tr:hover td { background:rgba(255,255,255,0.02); }

.code-badge { font-family:monospace; background:rgba(124,58,237,0.15); color:var(--secondary); padding:3px 10px; border-radius:6px; font-weight:700; font-size:0.8rem; }

/* Pagination */
.pagination { display:flex; gap:6px; justify-content:center; margin-top:20px; }
.pagination a, .pagination span {
  padding:8px 14px; border-radius:8px; text-decoration:none;
  font-size:0.82rem; font-weight:600; transition:all 0.2s;
}
.pagination a { background:rgba(255,255,255,0.05); color:#94a3b8; border:1px solid rgba(255,255,255,0.08); }
.pagination a:hover { background:rgba(0,212,255,0.1); color:var(--primary); border-color:rgba(0,212,255,0.2); }
.pagination span { background:linear-gradient(90deg,var(--primary),var(--secondary)); color:#fff; }

/* Hourly chart */
.hourly-chart { display:flex; align-items:flex-end; gap:4px; height:120px; padding:15px 0; }
.hour-bar { flex:1; background:linear-gradient(to top, var(--primary), var(--secondary)); border-radius:4px 4px 0 0; min-width:8px; transition:opacity 0.2s; position:relative; }
.hour-bar:hover { opacity:0.8; }
.hour-bar .tooltip { position:absolute; bottom:100%; left:50%; transform:translateX(-50%); background:#0d111f; padding:4px 8px; border-radius:6px; font-size:0.7rem; white-space:nowrap; opacity:0; transition:opacity 0.2s; pointer-events:none; border:1px solid rgba(255,255,255,0.1); }
.hour-bar:hover .tooltip { opacity:1; }

/* Top cards list */
.top-card-item { display:flex; align-items:center; gap:12px; padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.03); }
.top-card-item:last-child { border:none; }
.top-card-rank { width:28px; height:28px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.75rem; font-weight:800; }
.top-card-rank.gold { background:linear-gradient(135deg,#fbbf24,#f59e0b); color:#000; }
.top-card-rank.silver { background:linear-gradient(135deg,#94a3b8,#64748b); color:#fff; }
.top-card-rank.bronze { background:linear-gradient(135deg,#d97706,#b45309); color:#fff; }
.top-card-rank.normal { background:rgba(255,255,255,0.06); color:#64748b; }

/* Box cards */
.box { background:var(--card-bg); border-radius:16px; padding:22px; border:1px solid var(--border); backdrop-filter:blur(10px); }
.box-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; }
.box-header h3 { font-size:0.95rem; font-weight:700; color:#cbd5e1; margin:0; }
</style>

<div class="main">
  <div class="topbar">
    <h1>📈 مركز التحليلات والتقارير</h1>
    <?php if ($logs): ?>
    <a href="index.php?clear=all" class="btn btn-danger" onclick="return confirm('مسح كافة السجلات؟ لا يمكن التراجع.')">🗑️ مسح السجلات</a>
    <?php endif; ?>
  </div>

  <?php if ($success): ?>
    <div class="alert success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <!-- Stats Summary -->
  <div class="stats">
    <div class="stat-card green">
      <div class="num"><?= $today_logins ?></div>
      <div class="label">تسجيلات اليوم</div>
    </div>
    <div class="stat-card red">
      <div class="num"><?= $today_kicks ?></div>
      <div class="label">قطع اتصال اليوم</div>
    </div>
    <div class="stat-card blue">
      <div class="num"><?= $week_logins ?></div>
      <div class="label">آخر 7 أيام</div>
    </div>
    <div class="stat-card purple">
      <div class="num"><?= $month_logins ?></div>
      <div class="label">آخر 30 يوم</div>
    </div>
  </div>

  <div style="display:grid; grid-template-columns:2fr 1fr; gap:20px;">
    <!-- Hourly Activity Chart -->
    <div class="box">
      <div class="box-header">
        <h3>📊 نشاط الساعات (24 ساعة)</h3>
      </div>
      <?php if ($hourly_stats): ?>
      <div class="hourly-chart">
        <?php 
        $max_count = max(array_column($hourly_stats, 'count')) ?: 1;
        foreach ($hourly_stats as $hs): 
          $height_pct = ($hs['count'] / $max_count) * 100;
        ?>
        <div class="hour-bar" style="height:<?= max(5, $height_pct) ?>%">
          <div class="tooltip">الساعة <?= $hs['hour'] ?>: <?= $hs['count'] ?> حدث</div>
        </div>
        <?php endforeach; ?>
      </div>
      <div style="display:flex; justify-content:space-between; margin-top:8px; font-size:0.7rem; color:#475569;">
        <span>00:00</span>
        <span>06:00</span>
        <span>12:00</span>
        <span>18:00</span>
        <span>23:00</span>
      </div>
      <?php else: ?>
        <p style="color:#475569; text-align:center; padding:30px;">لا توجد بيانات كافية</p>
      <?php endif; ?>
    </div>

    <!-- Top Active Cards -->
    <div class="box">
      <div class="box-header"><h3>🏆 أكثر الكروت نشاطاً</h3></div>
      <?php if ($top_active): 
        $rank = 0;
        foreach ($top_active as $tc): 
          $rank++;
          $rank_class = $rank === 1 ? 'gold' : ($rank === 2 ? 'silver' : ($rank === 3 ? 'bronze' : 'normal'));
      ?>
        <div class="top-card-item">
          <div class="top-card-rank <?= $rank_class ?>"><?= $rank ?></div>
          <div style="flex:1;">
            <div style="font-family:monospace; color:#00d4ff; font-weight:700; font-size:0.85rem;"><?= htmlspecialchars($tc['card_code']) ?></div>
            <div style="font-size:0.72rem; color:#475569;"><?= $tc['count'] ?> حدث | آخر نشاط: <?= date('Y-m-d H:i', strtotime($tc['last_activity'])) ?></div>
          </div>
        </div>
      <?php endforeach; else: ?>
        <p style="color:#475569; text-align:center; padding:20px;">لا توجد بيانات</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Logs Table -->
  <div class="box" style="margin-top:20px;">
    <div class="box-header" style="display:block; margin-bottom:20px;">
      <h3 style="margin-bottom:15px;">📋 سجلات النظام</h3>
      <form method="GET" class="toolbar">
        <input type="text" name="search" placeholder="🔍 بحث بكود الكارت أو الحدث..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" style="min-width:200px; flex:1;">
        <select name="action_type">
          <option value="">كل الأنواع</option>
          <option value="login" <?= ($_GET['action_type']??'')==='login'?'selected':'' ?>>🔑 دخول</option>
          <option value="logout" <?= ($_GET['action_type']??'')==='logout'?'selected':'' ?>>🚪 خروج</option>
          <option value="broadcast" <?= ($_GET['action_type']??'')==='broadcast'?'selected':'' ?>>📢 إشعار</option>
        </select>
        <input type="date" name="date_from" value="<?= htmlspecialchars($_GET['date_from'] ?? '') ?>" placeholder="من">
        <input type="date" name="date_to" value="<?= htmlspecialchars($_GET['date_to'] ?? '') ?>" placeholder="إلى">
        <button type="submit" class="btn btn-primary">🔍 بحث</button>
        <?php if (!empty($_GET['search']) || !empty($_GET['action_type']) || !empty($_GET['date_from']) || !empty($_GET['date_to'])): ?>
          <a href="index.php" class="btn btn-danger btn-sm" style="align-self:center;">✕</a>
        <?php endif; ?>
      </form>
    </div>

    <table>
      <tr>
        <th>الكارت</th>
        <th>الحدث</th>
        <th>التاريخ والوقت</th>
      </tr>
      <?php if ($logs): ?>
        <?php foreach ($logs as $log): 
          $action_class = '';
          if (strpos($log['action'], 'login') !== false) $action_class = 'color:#22c55e;';
          elseif (strpos($log['action'], 'logout') !== false || strpos($log['action'], 'kick') !== false) $action_class = 'color:#ef4444;';
          elseif (strpos($log['action'], 'broadcast') !== false) $action_class = 'color:#06b6d4;';
        ?>
        <tr>
          <td><span class="code-badge"><?= htmlspecialchars($log['card_code']) ?></span></td>
          <td style="<?= $action_class ?>"><?= htmlspecialchars($log['action']) ?></td>
          <td style="color:#64748b; font-size:0.78rem;"><?= date('Y-m-d H:i:s', strtotime($log['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      <?php else: ?>
        <tr><td colspan="3" style="text-align:center; color:#475569; padding:40px;">لا توجد سجلات مطابقة</td></tr>
      <?php endif; ?>
    </table>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
    <div class="pagination">
      <?php if ($page > 1): ?>
        <a href="?page=<?= $page-1 ?><?= buildQueryString() ?>">← السابق</a>
      <?php endif; ?>
      <?php for ($i = max(1, $page-2); $i <= min($total_pages, $page+2); $i++): ?>
        <?php if ($i == $page): ?>
          <span><?= $i ?></span>
        <?php else: ?>
          <a href="?page=<?= $i ?><?= buildQueryString() ?>"><?= $i ?></a>
        <?php endif; ?>
      <?php endfor; ?>
      <?php if ($page < $total_pages): ?>
        <a href="?page=<?= $page+1 ?><?= buildQueryString() ?>">التالي →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php
function buildQueryString() {
    $parts = [];
    if (!empty($_GET['search'])) $parts[] = 'search=' . urlencode($_GET['search']);
    if (!empty($_GET['action_type'])) $parts[] = 'action_type=' . urlencode($_GET['action_type']);
    if (!empty($_GET['date_from'])) $parts[] = 'date_from=' . urlencode($_GET['date_from']);
    if (!empty($_GET['date_to'])) $parts[] = 'date_to=' . urlencode($_GET['date_to']);
    return $parts ? '&' . implode('&', $parts) : '';
}
?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>