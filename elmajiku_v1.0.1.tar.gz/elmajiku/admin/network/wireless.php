<?php
header('Location: index.php?tab=router');
exit;