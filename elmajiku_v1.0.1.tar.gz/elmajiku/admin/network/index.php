<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/iptables.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$ping_result = '';
$traceroute_result = '';
$speed_test_result = '';
$error = '';

// دالة التحقق من اتصال المنفذ المادي (Ethernet carrier status)
function getInterfaceCarrier($iface) {
    $carrier_file = "/sys/class/net/{$iface}/carrier";
    if (file_exists($carrier_file)) {
        $c = trim(@file_get_contents($carrier_file));
        if ($c === '1') return true;
    }
    $oper_file = "/sys/class/net/{$iface}/operstate";
    if (file_exists($oper_file)) {
        $o = trim(@file_get_contents($oper_file));
        if ($o === 'up') return true;
    }
    return false;
}

// دالة جلب سرعة الاتصال المادية للمنفذ
function getInterfaceSpeed($iface) {
    if (str_starts_with($iface, 'br-') || str_starts_with($iface, 'lo') || str_starts_with($iface, 'wlan')) {
        return '';
    }
    $speed_file = "/sys/class/net/{$iface}/speed";
    if (file_exists($speed_file)) {
        $s = trim(@file_get_contents($speed_file));
        if ($s !== '' && $s !== '-1' && is_numeric($s)) {
            return $s >= 1000 ? ($s/1000) . ' Gbps' : $s . ' Mbps';
        }
    }
    return '';
}

// دالة جلب عنوان IP المسجل للواجهة
function getInterfaceIP($iface) {
    $output = shell_exec("ip -o -4 addr show dev " . escapeshellarg($iface) . " 2>/dev/null");
    if ($output && preg_match('/inet\s+([0-9.]+)/', $output, $matches)) {
        return $matches[1];
    }
    $output = shell_exec("ifconfig " . escapeshellarg($iface) . " 2>/dev/null");
    if ($output && preg_match('/inet\s+(?:addr:)?([0-9.]+)/', $output, $matches)) {
        return $matches[1];
    }
    return 'لا يوجد IP';
}

// دالة استخلاص واجهة الواي فاي الخاصة بالراديو
function getIfaceForRadio($radio_index) {
    $output = [];
    exec("uci show wireless 2>/dev/null", $output);
    foreach ($output as $line) {
        if (preg_match("/wireless\.([A-Za-z0-9_@\[\]\-]+)\.device=['\"]?radio{$radio_index}['\"]?/", $line, $matches)) {
            return $matches[1];
        }
    }
    return null;
}

// دالة جلب إعدادات الواي فاي من الـ uci
function getWirelessConfig($radio_index) {
    $radio_disabled = trim(shell_exec("uci get wireless.radio{$radio_index}.disabled 2>/dev/null")) === '1';
    $channel = trim(shell_exec("uci get wireless.radio{$radio_index}.channel 2>/dev/null"));
    $htmode = trim(shell_exec("uci get wireless.radio{$radio_index}.htmode 2>/dev/null"));
    $country = trim(shell_exec("uci get wireless.radio{$radio_index}.country 2>/dev/null"));

    $iface_name = null;
    $output = [];
    exec("uci show wireless 2>/dev/null", $output);
    foreach ($output as $line) {
        if (preg_match("/wireless\.([A-Za-z0-9_@\[\]\-]+)\.device=['\"]?radio{$radio_index}['\"]?/", $line, $matches)) {
            $iface_name = $matches[1];
            break;
        }
    }
    if ($iface_name !== null) {
        $ssid = trim(shell_exec("uci get wireless.{$iface_name}.ssid 2>/dev/null"));
        $encryption = trim(shell_exec("uci get wireless.{$iface_name}.encryption 2>/dev/null"));
        $key = trim(shell_exec("uci get wireless.{$iface_name}.key 2>/dev/null"));
        $iface_disabled = trim(shell_exec("uci get wireless.{$iface_name}.disabled 2>/dev/null")) === '1';
    } else {
        $ssid = '';
        $encryption = 'psk2';
        $key = '';
        $iface_disabled = false;
    }
    return [
        'radio_disabled' => $radio_disabled,
        'channel' => $channel ?: 'auto',
        'htmode' => $htmode ?: ($radio_index == 0 ? 'HT20' : 'VHT80'),
        'country' => $country ?: 'EG',
        'ssid' => $ssid ?: ($radio_index == 0 ? 'MyWiFi-2G' : 'MyWiFi-5G'),
        'encryption' => $encryption,
        'key' => $key,
        'iface_disabled' => $iface_disabled,
    ];
}

// 1. معالجة الأجهزة المستثناة (Bypass MAC)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bypass'])) {
    $mac = strtoupper(trim($_POST['mac_address'] ?? ''));
    $desc = trim($_POST['description'] ?? '');
    if (!empty($mac)) {
        addBypassedMac($mac, $desc);
        // تفعيل عبور الماك في جدار الحماية تلقائياً فوراً إذا كان الجهاز متصلاً
        try {
            $normalized_mac = normalizeMac($mac);
            $ip_to_allow = null;
            
            // 1. فحص ملف Leases
            $leases_data = @file_get_contents('/tmp/dhcp.leases');
            if ($leases_data) {
                foreach (explode("\n", trim($leases_data)) as $line) {
                    $parts = explode(' ', $line);
                    if (count($parts) >= 3 && normalizeMac($parts[1]) === $normalized_mac) {
                        $ip_to_allow = $parts[2];
                        break;
                    }
                }
            }
            
            // 2. فحص كاش ARP إذا لم يتم العثور عليه في leases
            if (!$ip_to_allow) {
                $arp = @file_get_contents('/proc/net/arp');
                if ($arp) {
                    foreach (explode("\n", $arp) as $line) {
                        $parts = preg_split('/\s+/', trim($line));
                        if (isset($parts[0]) && isset($parts[3]) && normalizeMac($parts[3]) === $normalized_mac) {
                            $ip_to_allow = $parts[0];
                            break;
                        }
                    }
                }
            }
            
            // 3. تفعيل وإضافة لقائمة المتصلين فوراً
            if ($ip_to_allow) {
                allowIP($ip_to_allow);
                addOnlineUser('BYPASS', $ip_to_allow, $normalized_mac, $desc ?: 'Bypassed Device');
                addLog('BYPASS', "تخطي يدوي: تم إضافة وتفعيل عبور جهاز مستثنى بالماك. IP: $ip_to_allow, MAC: $normalized_mac");
            }
        } catch (Exception $e) {}
        
        header('Location: index.php?msg=bypass_added&tab=bypass');
        exit;
    }
}
if (isset($_GET['delete_bypass'])) {
    removeBypassedMac(intval($_GET['delete_bypass']));
    header('Location: index.php?msg=bypass_deleted&tab=bypass');
    exit;
}

// فصل مستخدم من الشبكة بشكل فوري
if (isset($_GET['disconnect'])) {
    $row = $db->prepare('SELECT ip_address, card_code FROM online_users WHERE id = ?');
    $row->execute([intval($_GET['disconnect'])]);
    $u = $row->fetch();
    if ($u) {
        blockIP($u['ip_address']);
        removeOnlineUser($u['ip_address']);
        addLog($u['card_code'], "فصل يدوي من لوحة التحكم. IP: " . $u['ip_address']);
    }
    header('Location: index.php?msg=disconnected&tab=live');
    exit;
}

// دالة مساعدة: جلب عنوان IP من عنوان MAC (للاستخدام في صفحة الشبكة)
function getIPFromMac_net($mac) {
    $mac = strtoupper(trim($mac));
    $leases = @file_get_contents('/tmp/dhcp.leases');
    if ($leases) {
        foreach (explode("\n", $leases) as $line) {
            $p = explode(' ', trim($line));
            if (count($p) >= 3 && strtoupper($p[1]) === $mac) return $p[2];
        }
    }
    $arp = @file_get_contents('/proc/net/arp');
    if ($arp) {
        foreach (explode("\n", $arp) as $line) {
            $p = preg_split('/\s+/', trim($line));
            if (count($p) >= 4 && strtoupper($p[3]) === $mac) return $p[0];
        }
    }
    return null;
}

// دالة جلب MAC من منفذ جسر مادي (مع دعم بديل لـ brctl)
function getMacsOnPort_net($port) {
    $macs = [];
    $port = trim($port);
    
    // 1. طريقة bridge fdb show dev (الحديثة والافتراضية)
    $out = shell_exec("bridge fdb show dev " . escapeshellarg($port) . " 2>/dev/null");
    if ($out) {
        foreach (explode("\n", $out) as $line) {
            $line = trim($line);
            if (empty($line) || str_contains($line, 'self') || str_contains($line, 'permanent')) continue;
            $p = explode(' ', $line);
            if (isset($p[0]) && preg_match('/^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/', $p[0])) {
                $macs[] = strtoupper($p[0]);
            }
        }
    }
    
    // 2. طريقة brctl showmacs (البديلة للأجهزة القديمة)
    if (empty($macs)) {
        $lan_iface = LAN_INTERFACE;
        $port_no_file = "/sys/class/net/{$lan_iface}/brif/{$port}/port_no";
        if (file_exists($port_no_file)) {
            $port_no = hexdec(trim(@file_get_contents($port_no_file)));
            if ($port_no > 0) {
                $brctl_out = shell_exec("brctl showmacs {$lan_iface} 2>/dev/null");
                if ($brctl_out) {
                    foreach (explode("\n", $brctl_out) as $line) {
                        $line = trim($line);
                        $p = preg_split('/\s+/', $line);
                        if (count($p) >= 4 && is_numeric($p[0]) && intval($p[0]) == $port_no && $p[2] === 'no') {
                            $macs[] = strtoupper($p[1]);
                        }
                    }
                }
            }
        }
    }
    return array_unique($macs);
}

// 2. معالجة منافذ وواجهات الشبكة (Interfaces Control)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_interface'])) {
    $iface = trim($_POST['interface_name'] ?? '');
    $mode  = trim($_POST['mode'] ?? 'hotspot');
    $desc  = trim($_POST['description'] ?? '');
    if (!empty($iface)) {
        $stmt = $db->prepare('INSERT OR REPLACE INTO interface_rules (interface_name, mode, description) VALUES (?, ?, ?)');
        $stmt->execute([$iface, $mode, $desc]);

        // تطبيق فوري للأجهزة المتصلة حالياً بالمنفذ (IP-based كبديل فوري عن physdev)
        try {
            $port_macs = getMacsOnPort_net($iface);
            foreach ($port_macs as $pm) {
                $pip = getIPFromMac_net($pm);
                if (!$pip) continue;
                if ($mode === 'bypass') {
                    allowIP($pip);
                    $already = $db->prepare('SELECT COUNT(*) FROM online_users WHERE ip_address = ?');
                    $already->execute([$pip]);
                    if ($already->fetchColumn() == 0) {
                        addOnlineUser('BYPASS', $pip, $pm, 'Port Bypass Device (' . $iface . ')');
                        addLog('BYPASS', "عبور فوري من صفحة التحكم لجهاز متصل بمنفذ ($iface). IP: $pip, MAC: $pm");
                    }
                } elseif ($mode === 'blocked' || $mode === 'hotspot') {
                    blockIP($pip);
                    removeOnlineUser($pip);
                }
            }
        } catch (Exception $e) { /* فشل صامت لو لم يتوفر bridge */ }

        // إعادة تطبيق جدار الحماية بالكامل
        initHotspotChain();

        header('Location: index.php?msg=interface_updated&tab=interfaces');
        exit;
    }
}

// 3. معالجة إعدادات الراوتر (LAN IP Address)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_lan_ip'])) {
    $new_ip = trim($_POST['lan_ip'] ?? '');
    $netmask = trim($_POST['netmask'] ?? '255.255.255.0');
    if (filter_var($new_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        shell_exec("uci set network.lan.ipaddr=" . escapeshellarg($new_ip));
        shell_exec("uci set network.lan.netmask=" . escapeshellarg($netmask));
        shell_exec("uci commit network");
        shell_exec("nohup /etc/init.d/network restart > /dev/null 2>&1 &");
        header('Location: index.php?msg=lan_ip_changed&tab=router');
        exit;
    } else {
        $error = "عنوان IP غير صحيح.";
    }
}

// 4. معالجة إعدادات الواي فاي
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_wifi'])) {
    $ssid_2g = trim($_POST['ssid_2g'] ?? '');
    $encryption_2g = $_POST['encryption_2g'] ?? 'psk2';
    $key_2g = trim($_POST['key_2g'] ?? '');
    $iface_disabled_2g = 0; // تمكين الواجهة دائماً والاعتماد على تمكين الراديو للتحكم بالبث
    $channel_2g = $_POST['channel_2g'] ?? 'auto';
    $htmode_2g = $_POST['htmode_2g'] ?? 'HT20';
    $country_2g = strtoupper(trim($_POST['country_2g'] ?? 'EG'));
    $radio_disabled_2g = isset($_POST['radio_disabled_2g']) ? 0 : 1;

    $ssid_5g = trim($_POST['ssid_5g'] ?? '');
    $encryption_5g = $_POST['encryption_5g'] ?? 'psk2';
    $key_5g = trim($_POST['key_5g'] ?? '');
    $iface_disabled_5g = 0; // تمكين الواجهة دائماً والاعتماد على تمكين الراديو للتحكم بالبث
    $channel_5g = $_POST['channel_5g'] ?? 'auto';
    $htmode_5g = $_POST['htmode_5g'] ?? 'VHT80';
    $country_5g = strtoupper(trim($_POST['country_5g'] ?? 'EG'));
    $radio_disabled_5g = isset($_POST['radio_disabled_5g']) ? 0 : 1;

    if (empty($ssid_2g) || empty($ssid_5g)) {
        $error = "اسم الشبكة مطلوب للترددين.";
    } else {
        $commands = [];
        $commands[] = "uci set wireless.radio0.disabled='$radio_disabled_2g'";
        $commands[] = "uci set wireless.radio0.channel='$channel_2g'";
        $commands[] = "uci set wireless.radio0.htmode='$htmode_2g'";
        $commands[] = "uci set wireless.radio0.country='$country_2g'";
        
        $commands[] = "uci set wireless.radio1.disabled='$radio_disabled_5g'";
        $commands[] = "uci set wireless.radio1.channel='$channel_5g'";
        $commands[] = "uci set wireless.radio1.htmode='$htmode_5g'";
        $commands[] = "uci set wireless.radio1.country='$country_5g'";

        foreach ([0 => '2g', 1 => '5g'] as $idx => $band) {
            $ssid = ${"ssid_{$band}"};
            $enc = ${"encryption_{$band}"};
            $key = ${"key_{$band}"};
            $disabled = ${"iface_disabled_{$band}"};

            $iface_name = null;
            $output = [];
            exec("uci show wireless 2>/dev/null", $output);
            foreach ($output as $line) {
                if (preg_match("/wireless\.([A-Za-z0-9_@\[\]\-]+)\.device=['\"]?radio{$idx}['\"]?/", $line, $matches)) {
                    $iface_name = $matches[1];
                    break;
                }
            }
            if ($iface_name === null) {
                exec("uci add wireless wifi-iface");
                $iface_name = '@wifi-iface[-1]';
            }
            $commands[] = "uci set wireless.{$iface_name}.device='radio{$idx}'";
            $commands[] = "uci set wireless.{$iface_name}.network='lan'";
            $commands[] = "uci set wireless.{$iface_name}.mode='ap'";
            $commands[] = "uci set wireless.{$iface_name}.ssid='{$ssid}'";
            $commands[] = "uci set wireless.{$iface_name}.encryption='{$enc}'";
            if ($enc !== 'none') {
                $commands[] = "uci set wireless.{$iface_name}.key='{$key}'";
            } else {
                $commands[] = "uci set wireless.{$iface_name}.key=''";
            }
            $commands[] = "uci set wireless.{$iface_name}.disabled='{$disabled}'";
        }

        $commands[] = "uci commit wireless";
        foreach ($commands as $cmd) {
            exec($cmd);
        }
        // إيقاف الواي فاي وإعادة تشغيله بالكامل لضمان تطبيق الإعدادات
        shell_exec("wifi down 2>/dev/null; sleep 1; wifi up 2>/dev/null &");
        header('Location: index.php?msg=wifi_saved&tab=router');
        exit;
    }
}

// 5. أوامر الطاقة (Reboot / Shutdown)
if (isset($_GET['reboot'])) {
    shell_exec("nohup reboot > /dev/null 2>&1 &");
    header('Location: index.php?msg=rebooting&tab=router');
    exit;
}
if (isset($_GET['shutdown'])) {
    shell_exec("nohup poweroff > /dev/null 2>&1 &");
    header('Location: index.php?msg=shutting_down&tab=router');
    exit;
}

// 6. تشخيص الفحص (Ping / Traceroute)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ping_host'])) {
    $host = preg_replace('/[^a-zA-Z0-9.-]/', '', $_POST['ping_host']);
    if (!empty($host)) {
        $ping_result = shell_exec("ping -c 4 " . escapeshellarg($host) . " 2>&1");
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['traceroute_host'])) {
    $host = preg_replace('/[^a-zA-Z0-9.-]/', '', $_POST['traceroute_host']);
    if (!empty($host)) {
        $traceroute_result = shell_exec("traceroute -m 15 " . escapeshellarg($host) . " 2>&1");
    }
}

// 7. اختبار السرعة (Speed Test)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['speed_test'])) {
    $start_time = microtime(true);
    $test_data = @file_get_contents('https://speed.hetzner.de/10MB.bin');
    $end_time = microtime(true);
    $duration = $end_time - $start_time;
    $speed_mbps = $duration > 0 ? round((10 * 8) / $duration, 2) : 0;
    $speed_test_result = "⏱️ المدة: " . round($duration, 2) . " ثانية\n";
    $speed_test_result .= "🚀 السرعة: ~" . $speed_mbps . " Mbps\n";
    $speed_test_result .= "📦 الحجم: 10 MB\n";
    $speed_test_result .= "📡 الخادم: Hetzner Speed Test";
}

// جلب تفاصيل النظام للشبكة
$uptime = shell_exec("uptime 2>/dev/null") ?: 'غير متوفر';
$ram_usage = 'غير متوفر';
$mem_pct = 0;
if (file_exists('/proc/meminfo')) {
    $meminfo = file_get_contents('/proc/meminfo');
    preg_match('/MemTotal:\s+(\d+)/', $meminfo, $matches_total);
    preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $matches_avail);
    if (empty($matches_avail)) {
        preg_match('/MemFree:\s+(\d+)/', $meminfo, $matches_free);
        preg_match('/Buffers:\s+(\d+)/', $meminfo, $matches_buffers);
        preg_match('/Cached:\s+(\d+)/', $meminfo, $matches_cached);
        $free = ($matches_free[1] ?? 0) + ($matches_buffers[1] ?? 0) + ($matches_cached[1] ?? 0);
    } else {
        $free = $matches_avail[1];
    }
    $total = $matches_total[1] ?? 0;
    if ($total > 0) {
        $used = $total - $free;
        $mem_pct = round(($used / $total) * 100);
        $ram_usage = round($used / 1024, 1) . ' MB / ' . round($total / 1024, 1) . ' MB (' . $mem_pct . '%)';
    }
}

$lan_ip = '192.168.77.1';
$lan_info = shell_exec("ip -o -4 addr show dev " . LAN_INTERFACE . " 2>/dev/null");
if ($lan_info && preg_match('/inet\s+([0-9.]+)/', $lan_info, $m)) {
    $lan_ip = $m[1];
}
$wan_ip = shell_exec("ip route get 8.8.8.8 2>/dev/null | grep -oE 'src [0-9.]+' | awk '{print \$2}'") ?: 'غير متصل';
$gateway = trim(shell_exec("ip route | grep default | awk '{print \$3}' | head -1")) ?: 'غير معروف';
$dns_servers = trim(shell_exec("cat /etc/resolv.conf | grep nameserver | awk '{print \$2}' | head -2 | tr '\n' ', '")) ?: 'غير معروف';

// DHCP Leases
$dhcp_leases = [];
if (file_exists('/tmp/dhcp.leases')) {
    $leases_data = file_get_contents('/tmp/dhcp.leases');
    foreach (explode("\n", trim($leases_data)) as $line) {
        if (empty($line)) continue;
        $parts = explode(' ', $line);
        if (count($parts) >= 4) {
            $expiry = intval($parts[0]);
            $time_left = $expiry - time();
            $time_left_str = ($time_left > 0) ? round($time_left / 60) . ' دقيقة' : 'منتهي';
            $dhcp_leases[] = [
                'mac' => strtoupper($parts[1]),
                'ip'  => $parts[2],
                'name'=> $parts[3] !== '*' ? $parts[3] : 'جهاز غير مسمى',
                'left'=> $time_left_str
            ];
        }
    }
}

$route_table = shell_exec("ip route show 2>/dev/null | head -10") ?: '';
$iptables_stats = shell_exec("iptables -L HOTSPOT_ACNT -v -n 2>/dev/null | tail -n +3 | head -20") ?: '';

// جلب قائمة الأجهزة المستثناة
$bypasses = $db->query('SELECT * FROM bypassed_macs ORDER BY created_at DESC')->fetchAll();

// جلب منافذ الشبكة المتاحة
$net_dir    = '/sys/class/net/';
$interfaces = [];
if (is_dir($net_dir)) {
    $files = scandir($net_dir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..' && $file !== 'lo' && !str_starts_with($file, 'teql') && !str_starts_with($file, 'ifb')) {
            $interfaces[] = $file;
        }
    }
}
if (empty($interfaces)) {
    $interfaces = ['lan1', 'lan2', 'lan3', 'lan4', 'wlan0', 'wlan1', 'br-lan'];
}

// جلب المتصلين حالياً مع بيانات كروتهم للـ Live Status tab
$online_with_cards = $db->query('
    SELECT
        o.id,
        o.ip_address,
        o.mac_address,
        o.device_name,
        o.card_code,
        o.login_time,
        o.last_seen,
        c.total_mb,
        c.used_mb,
        c.total_minutes,
        c.used_minutes,
        c.download_speed,
        c.upload_speed,
        c.expire_date,
        c.status  AS card_status,
        c.max_devices
    FROM online_users o
    LEFT JOIN cards c ON o.card_code = c.card_code
    ORDER BY o.login_time DESC
')->fetchAll();

// قراءة الإعدادات الحالية للواي فاي
$config_2g = getWirelessConfig(0);
$config_5g = getWirelessConfig(1);
?>
<?php
$page_title = 'الشبكة والمنظومة';
$active_page = 'network';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
/* Network specific styles */
.info-row { display:flex; justify-content:space-between; padding:12px 0; border-bottom:1px solid rgba(255,255,255,0.03); font-size:0.85rem; }
.info-row:last-child { border:none; }
.info-label { color:var(--text-muted); }
.info-val { color:#e2e8f0; font-weight:600; font-family:monospace; }
.info-val.highlight { color:var(--primary); }
.info-val.success { color:var(--accent); }

.progress-wrap { background:rgba(255,255,255,0.06); border-radius:10px; height:6px; margin-top:5px; }
.progress-bar { height:6px; border-radius:10px; background:linear-gradient(90deg,var(--primary),var(--secondary)); }

pre {
  background:#0d111f; padding:15px; border-radius:10px;
  font-family:'Fira Code', monospace; font-size:0.78rem;
  overflow-x:auto; border:1px solid rgba(255,255,255,0.05);
  color:#00ffcc; margin-top:10px; max-height:300px; overflow-y:auto;
  line-height:1.6;
}

table { width:100%; border-collapse:collapse; font-size:0.82rem; }
th { color:var(--text-muted); padding:10px 8px; text-align:right; border-bottom:1px solid rgba(255,255,255,0.06); font-weight:700; font-size:0.78rem; }
td { padding:10px 8px; border-bottom:1px solid rgba(255,255,255,0.04); color:#94a3b8; }
tr:last-child td { border:none; }
tr:hover td { background:rgba(255,255,255,0.02); }

.tabs { display:flex; gap:4px; margin-bottom:20px; background:rgba(255,255,255,0.03); padding:4px; border-radius:12px; flex-wrap:wrap; }
.tab-btn { padding:10px 20px; border-radius:10px; border:none; background:transparent; color:#94a3b8; cursor:pointer; font-size:0.85rem; font-weight:700; transition:all 0.2s; font-family:inherit; }
.tab-btn.active { background:rgba(0,212,255,0.1); color:var(--primary); }

.net-status { display:inline-flex; align-items:center; gap:6px; }
.net-status-dot { width:8px; height:8px; border-radius:50%; animation:pulse-dot 2s infinite; }
.net-status-dot.online { background:#22c55e; }
.net-status-dot.offline { background:#ef4444; animation:none; }
@keyframes pulse-dot { 0%,100%{opacity:1} 50%{opacity:.4} }

.checkbox-group { display:flex; align-items:center; gap:10px; margin-top:8px; margin-bottom:12px; }
.checkbox-group input { width:auto; margin-bottom:0; cursor:pointer; }
.checkbox-group label { margin-bottom:0; cursor:pointer; font-size:0.82rem; }
.section-title { font-size:1.05rem; font-weight:700; color:var(--primary); margin-bottom:15px; border-right:3px solid var(--primary); padding-right:12px; }

.grid2 { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px; }
@media (max-width:900px) { .grid2 { grid-template-columns:1fr; } }
.tab-content { display: none; }
.tab-content.active { display: block; }
</style>

<div class="main">
  <div class="topbar">
    <h1>🌐 مركز الشبكة والتشخيص</h1>
    <div class="net-status">
      <span class="net-status-dot <?= $wan_ip !== 'غير متصل' ? 'online' : 'offline' ?>"></span>
      <span style="font-size:0.85rem; color:#64748b;"><?= $wan_ip !== 'غير متصل' ? 'متصل بالإنترنت' : 'غير متصل' ?></span>
    </div>
  </div>

  <?php if (isset($_GET['msg'])): ?>
    <?php if ($_GET['msg'] === 'bypass_added'): ?>
      <div class="alert success">✅ تم إضافة الجهاز لقائمة الاستثناء بنجاح</div>
    <?php elseif ($_GET['msg'] === 'bypass_deleted'): ?>
      <div class="alert danger">🗑️ تم حذف الجهاز من قائمة الاستثناء</div>
    <?php elseif ($_GET['msg'] === 'interface_updated'): ?>
      <div class="alert success">🔌 تم تحديث وضع منفذ الشبكة وإعادة تطبيق جدار الحماية</div>
    <?php elseif ($_GET['msg'] === 'lan_ip_changed'): ?>
      <div class="alert success">⚙️ تم تغيير عنوان IP للراوتر وجاري إعادة تشغيل الشبكة. يرجى الانتظار والدخول للعنوان الجديد.</div>
    <?php elseif ($_GET['msg'] === 'wifi_saved'): ?>
      <div class="alert success">📶 تم حفظ إعدادات الواي فاي وتحديث البث بنجاح</div>
    <?php elseif ($_GET['msg'] === 'disconnected'): ?>
      <div class="alert danger">🔌 تم فصل الجهاز وحظر IP من الشبكة</div>
    <?php elseif ($_GET['msg'] === 'rebooting'): ?>
      <div class="alert info">🔄 جاري إعادة تشغيل الراوتر... سيستغرق الأمر دقيقة واحدة.</div>
    <?php elseif ($_GET['msg'] === 'shutting_down'): ?>
      <div class="alert danger">🔌 جاري إيقاف تشغيل الراوتر...</div>
    <?php endif; ?>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="alert danger">⚠️ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <!-- Tabs -->
  <div class="tabs">
    <button class="tab-btn active" onclick="showTab('overview')">📊 نظرة عامة</button>
    <button class="tab-btn" onclick="showTab('live')">📡 المتصلين الآن</button>
    <button class="tab-btn" onclick="showTab('diagnostics')">🔧 تشخيص</button>
    <button class="tab-btn" onclick="showTab('devices')">📱 الأجهزة المتصلة</button>
    <button class="tab-btn" onclick="showTab('bypass')">🔒 الأجهزة المستثناة</button>
    <button class="tab-btn" onclick="showTab('interfaces')">🔌 التحكم بالمنافذ</button>
    <button class="tab-btn" onclick="showTab('router')">⚙️ إعدادات الراوتر</button>
    <button class="tab-btn" onclick="showTab('advanced')">🛠️ متقدم</button>
  </div>

  <!-- Live Status Tab -->
  <div id="tab-live" class="tab-content">
    <style>
    .live-card {
      background: rgba(0,212,255,0.03); border:1px solid rgba(0,212,255,0.1);
      border-radius:14px; padding:16px 18px; margin-bottom:12px;
      display:grid; grid-template-columns:auto 1fr auto; gap:14px; align-items:start;
    }
    .live-card:hover { background:rgba(0,212,255,0.06); border-color:rgba(0,212,255,0.2); }
    .live-avatar {
      width:44px; height:44px; border-radius:12px; background:linear-gradient(135deg,#00d4ff,#7c3aed);
      display:flex; align-items:center; justify-content:center; font-size:1.3rem; flex-shrink:0;
    }
    .live-info h4 { font-size:0.88rem; font-weight:700; color:#e2e8f0; margin-bottom:4px; }
    .live-info .meta { font-size:0.75rem; color:#64748b; display:flex; gap:14px; flex-wrap:wrap; margin-bottom:8px; }
    .live-bars { display:flex; flex-direction:column; gap:5px; }
    .live-bar-row { display:flex; align-items:center; gap:8px; font-size:0.72rem; }
    .live-bar-row span:first-child { width:32px; color:#64748b; text-align:left; }
    .live-bar-wrap { flex:1; background:rgba(255,255,255,0.06); border-radius:6px; height:5px; }
    .live-bar-fill { height:5px; border-radius:6px; background:linear-gradient(90deg,#00d4ff,#7c3aed); }
    .live-bar-fill.warn { background:linear-gradient(90deg,#f59e0b,#d97706); }
    .live-bar-fill.danger { background:linear-gradient(90deg,#ef4444,#f97316); }
    .live-bar-row .val { font-size:0.68rem; color:#94a3b8; min-width:80px; text-align:right; }
    .badge-code {
      font-family:monospace; font-weight:800; color:#00d4ff;
      background:rgba(0,212,255,0.08); padding:3px 10px; border-radius:6px;
      font-size:0.82rem;
    }
    .badge-bypass { color:#a855f7; background:rgba(168,85,247,0.1); }
    .badge-trial  { color:#22c55e; background:rgba(34,197,94,0.1); }
    .disconnect-btn {
      padding:7px 14px; border-radius:9px; border:1px solid rgba(239,68,68,0.3);
      background:rgba(239,68,68,0.08); color:#ef4444; font-size:0.75rem;
      font-weight:700; cursor:pointer; font-family:inherit; transition:all 0.2s;
      white-space:nowrap;
    }
    .disconnect-btn:hover { background:rgba(239,68,68,0.2); }
    .live-empty { text-align:center; padding:60px 20px; color:#475569; font-size:0.9rem; }
    .live-summary { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:20px; }
    .live-sum-box { background:rgba(22,27,39,0.5); border-radius:12px; padding:16px;
      border:1px solid rgba(255,255,255,0.05); text-align:center; }
    .live-sum-box .n { font-size:1.8rem; font-weight:800; }
    .live-sum-box .l { font-size:0.72rem; color:#64748b; margin-top:4px; }
    </style>

    <!-- ملخص سريع -->
    <div class="live-summary">
      <div class="live-sum-box">
        <div class="n" style="color:#00d4ff"><?= count($online_with_cards) ?></div>
        <div class="l">إجمالي المتصلين الآن</div>
      </div>
      <div class="live-sum-box">
        <div class="n" style="color:#22c55e"><?= count(array_filter($online_with_cards, fn($u) => !in_array($u['card_code'], ['BYPASS','TRIAL']))) ?></div>
        <div class="l">مشتركين بكروت</div>
      </div>
      <div class="live-sum-box">
        <div class="n" style="color:#a855f7"><?= count(array_filter($online_with_cards, fn($u) => $u['card_code'] === 'BYPASS')) ?></div>
        <div class="l">أجهزة مستثناة</div>
      </div>
    </div>

    <?php if ($online_with_cards): ?>
      <?php foreach ($online_with_cards as $u):
        $is_bypass = in_array($u['card_code'], ['BYPASS']);
        $is_trial  = $u['card_code'] === 'TRIAL';
        $mb_pct  = ($u['total_mb']      > 0) ? min(100, round($u['used_mb']      / $u['total_mb']      * 100)) : 0;
        $min_pct = ($u['total_minutes'] > 0) ? min(100, round($u['used_minutes'] / $u['total_minutes'] * 100)) : 0;
        $mb_left  = ($u['total_mb']      > 0) ? max(0, round($u['total_mb']      - $u['used_mb'],      1)) : null;
        $min_left = ($u['total_minutes'] > 0) ? max(0, round($u['total_minutes'] - $u['used_minutes'], 1)) : null;
        $login_ago = $u['login_time'] ? round((time() - strtotime($u['login_time'])) / 60) . ' دقيقة' : 'غير معروف';
        $last_ago  = $u['last_seen']  ? round((time() - strtotime($u['last_seen']))  / 60) . ' دقيقة' : 'الآن';
      ?>
      <div class="live-card">
        <!-- الأيقونة -->
        <div class="live-avatar"><?= $is_bypass ? '🔒' : ($is_trial ? '⚡' : '🎫') ?></div>

        <!-- بيانات المستخدم -->
        <div class="live-info">
          <h4>
            <?php if ($is_bypass): ?>
              <span class="badge-code badge-bypass">BYPASS</span>
            <?php elseif ($is_trial): ?>
              <span class="badge-code badge-trial">TRIAL</span>
            <?php else: ?>
              <span class="badge-code"><?= htmlspecialchars($u['card_code']) ?></span>
            <?php endif; ?>
            &nbsp;·&nbsp; <?= htmlspecialchars($u['device_name'] ?: 'جهاز غير مسمى') ?>
          </h4>
          <div class="meta">
            <span>🌐 <?= htmlspecialchars($u['ip_address']) ?></span>
            <span>🔌 <?= htmlspecialchars($u['mac_address'] ?: 'غير معروف') ?></span>
            <span>⏱️ منذ: <?= $login_ago ?></span>
            <span>👁️ آخر ظهور: <?= $last_ago ?></span>
            <?php if ($u['download_speed']): ?>
              <span>⬇<?= number_format($u['download_speed']) ?>K &nbsp; ⬆<?= number_format($u['upload_speed']) ?>K</span>
            <?php endif; ?>
          </div>

          <!-- أشرطة الاستهلاك -->
          <?php if (!$is_bypass): ?>
          <div class="live-bars">
            <?php if ($u['total_mb'] > 0): ?>
            <div class="live-bar-row">
              <span>📦</span>
              <div class="live-bar-wrap">
                <div class="live-bar-fill <?= $mb_pct>=90?'danger':($mb_pct>=70?'warn':'') ?>" style="width:<?= $mb_pct ?>%"></div>
              </div>
              <span class="val">
                <?= number_format($u['used_mb'],1) ?> / <?= number_format($u['total_mb']) ?> MB
                (<?= $mb_left ?> MB متبقي)
              </span>
            </div>
            <?php endif; ?>
            <?php if ($u['total_minutes'] > 0): ?>
            <div class="live-bar-row">
              <span>⏱️</span>
              <div class="live-bar-wrap">
                <div class="live-bar-fill <?= $min_pct>=90?'danger':($min_pct>=70?'warn':'') ?>" style="width:<?= $min_pct ?>%"></div>
              </div>
              <span class="val">
                <?= round($u['used_minutes'],1) ?> / <?= $u['total_minutes'] ?> دقيقة
                (<?= $min_left ?> دقيقة متبقية)
              </span>
            </div>
            <?php endif; ?>
            <?php if (!$u['total_mb'] && !$u['total_minutes']): ?>
              <span style="font-size:0.72rem; color:#475569;">∞ باقة غير محدودة</span>
            <?php endif; ?>
          </div>
          <?php endif; ?>
        </div>

        <!-- زر الفصل -->
        <div style="flex-shrink:0;">
          <a href="index.php?disconnect=<?= $u['id'] ?>&tab=live"
             class="disconnect-btn"
             onclick="return confirm('فصل الجهاز <?= htmlspecialchars($u['ip_address']) ?>؟')">
            🔌 فصل
          </a>
        </div>
      </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="live-empty">📡 لا يوجد أي مستخدم متصل حالياً</div>
    <?php endif; ?>
  </div>

  <!-- Overview Tab -->
  <div id="tab-overview" class="tab-content">
    <div class="grid2">
      <div class="box">
        <h3>📡 معلومات الشبكة</h3>
        <div class="info-row">
          <span class="info-label">عنوان IP المحلي (LAN)</span>
          <span class="info-val highlight"><?= htmlspecialchars($lan_ip) ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">عنوان IP الخارجي (WAN)</span>
          <span class="info-val <?= $wan_ip !== 'غير متصل' ? 'success' : '' ?>"><?= htmlspecialchars($wan_ip) ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">البوابة الافتراضية</span>
          <span class="info-val"><?= htmlspecialchars($gateway) ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">خوادم DNS</span>
          <span class="info-val"><?= htmlspecialchars($dns_servers) ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">واجهة LAN</span>
          <span class="info-val"><?= LAN_INTERFACE ?></span>
        </div>
        <div class="info-row">
          <span class="info-label">واجهة WAN</span>
          <span class="info-val"><?= WAN_INTERFACE ?></span>
        </div>
      </div>

      <div class="box">
        <h3>📈 أداء النظام</h3>
        <div class="info-row">
          <span class="info-label">وقت العمل (Uptime)</span>
          <span class="info-val"><?= htmlspecialchars($uptime) ?></span>
        </div>
        <div class="info-row" style="display:block">
          <div style="display:flex;justify-content:space-between">
            <span class="info-label">استهلاك الذاكرة</span>
            <span class="info-val"><?= $ram_usage ?></span>
          </div>
          <div class="progress-wrap"><div class="progress-bar" style="width:<?= $mem_pct ?>%"></div></div>
        </div>
        <div class="info-row">
          <span class="info-label">المتصلين حالياً</span>
          <span class="info-val highlight"><?= $db->query('SELECT COUNT(*) FROM online_users')->fetchColumn() ?> مستخدم</span>
        </div>
        <div class="info-row">
          <span class="info-label">إجمالي الكروت</span>
          <span class="info-val"><?= $db->query('SELECT COUNT(*) FROM cards')->fetchColumn() ?> كارت</span>
        </div>
      </div>
    </div>

    <!-- RJ45 Physical Ports Status - Detailed -->
    <?php
    // تعريف وصف وظيفة كل واجهة
    $iface_roles = [
        'br-lan'  => ['label' => 'الجسر الرئيسي (Bridge)', 'desc' => 'يجمع كل المنافذ LAN معاً'],
        'eth0'    => ['label' => 'المنفذ الرئيسي', 'desc' => 'الكارت الفيزيائي الأم للجهاز'],
        'lan1'    => ['label' => 'LAN 1', 'desc' => 'منفذ شبكة سلكي رقم 1'],
        'lan2'    => ['label' => 'LAN 2', 'desc' => 'منفذ شبكة سلكي رقم 2'],
        'lan3'    => ['label' => 'LAN 3', 'desc' => 'منفذ شبكة سلكي رقم 3'],
        'lan4'    => ['label' => 'LAN 4', 'desc' => 'منفذ شبكة سلكي رقم 4'],
        'wan'     => ['label' => 'WAN (الإنترنت)', 'desc' => 'منفذ الاتصال بالإنترنت'],
        'wlan0'   => ['label' => 'واي فاي 2.4GHz', 'desc' => 'كرت الواي فاي 2.4 جيجاهرتز'],
        'wlan1'   => ['label' => 'واي فاي 5GHz', 'desc' => 'كرت الواي فاي 5 جيجاهرتز'],
    ];
    // الأولوية: عرض المنافذ المحددة أولاً ثم أي منافذ إضافية أخرى
    $priority_ifaces = array_keys($iface_roles);
    $extra_ifaces = array_diff($interfaces, $priority_ifaces);
    $display_ifaces = array_merge(array_intersect($priority_ifaces, array_merge($interfaces, $priority_ifaces)), $extra_ifaces);
    $display_ifaces = array_unique(array_merge(
        array_intersect($priority_ifaces, array_merge($interfaces, $priority_ifaces)),
        $extra_ifaces
    ));

    // جلب قواعد الواجهات من قاعدة البيانات
    $iface_rules_db = [];
    foreach ($db->query('SELECT * FROM interface_rules') as $r) {
        $iface_rules_db[$r['interface_name']] = $r['mode'];
    }
    ?>
    <div class="box" style="margin-top:20px;">
        <h3>🔌 حالة المنافذ المادية وكابلات الشبكة (Ethernet Ports)</h3>
        <div style="overflow-x:auto; margin-top:15px;">
          <table style="width:100%; border-collapse:collapse; font-size:0.83rem;">
            <thead>
              <tr style="border-bottom:1px solid rgba(255,255,255,0.08);">
                <th style="padding:10px 14px; text-align:right; color:#475569; font-weight:700; font-size:0.76rem; letter-spacing:0.5px;">المنفذ</th>
                <th style="padding:10px 14px; text-align:right; color:#475569; font-weight:700; font-size:0.76rem;">الوظيفة</th>
                <th style="padding:10px 14px; text-align:center; color:#475569; font-weight:700; font-size:0.76rem;">حالة الكيبل</th>
                <th style="padding:10px 14px; text-align:right; color:#475569; font-weight:700; font-size:0.76rem;">عنوان IP</th>
                <th style="padding:10px 14px; text-align:center; color:#475569; font-weight:700; font-size:0.76rem;">وضع التشغيل</th>
                <th style="padding:10px 14px; text-align:right; color:#475569; font-weight:700; font-size:0.76rem;">السرعة</th>
              </tr>
            </thead>
            <tbody>
            <?php
            $shown = [];
            // عرض المنافذ المحددة أولاً (سواء وُجدت فعلياً في sysfs أم لا)
            foreach ($priority_ifaces as $iface):
                $shown[] = $iface;
                $is_up = getInterfaceCarrier($iface);
                $exists = in_array($iface, $interfaces);
                $ip_addr = $exists ? getInterfaceIP($iface) : '—';
                $speed = $exists && $is_up ? getInterfaceSpeed($iface) : '';
                $port_color = $is_up ? '#22c55e' : '#475569';
                $bg_row = $is_up ? 'rgba(34,197,94,0.03)' : 'transparent';
                $mode = $iface_rules_db[$iface] ?? 'hotspot';
                $role = $iface_roles[$iface] ?? ['label' => $iface, 'desc' => ''];
                if ($mode === 'bypass') {
                    $mode_badge = '<span style="background:rgba(34,197,94,0.15);color:#22c55e;padding:3px 10px;border-radius:8px;font-size:0.72rem;font-weight:700;">🟢 نت مباشر</span>';
                } elseif ($mode === 'blocked') {
                    $mode_badge = '<span style="background:rgba(239,68,68,0.15);color:#ef4444;padding:3px 10px;border-radius:8px;font-size:0.72rem;font-weight:700;">🔴 محظور</span>';
                } else {
                    $mode_badge = '<span style="background:rgba(0,212,255,0.1);color:#00d4ff;padding:3px 10px;border-radius:8px;font-size:0.72rem;font-weight:700;">🔵 بوابة الكروت</span>';
                }
                // أيقونة خاصة للواجهة
                if (str_starts_with($iface, 'wlan')) {
                    $icon = '📶';
                } elseif ($iface === 'wan') {
                    $icon = '🌐';
                } elseif ($iface === 'br-lan') {
                    $icon = '🔀';
                } else {
                    $icon = '🔌';
                }
            ?>
              <tr style="border-bottom:1px solid rgba(255,255,255,0.04); background:<?= $bg_row ?>;">
                <td style="padding:12px 14px;">
                  <div style="display:flex;align-items:center;gap:8px;">
                    <span style="font-size:1.2rem;"><?= $icon ?></span>
                    <div>
                      <div style="font-family:monospace;font-weight:800;color:#fff;font-size:0.88rem;"><?= htmlspecialchars($iface) ?></div>
                      <div style="font-size:0.7rem;color:#64748b;margin-top:2px;"><?= htmlspecialchars($role['desc']) ?></div>
                    </div>
                  </div>
                </td>
                <td style="padding:12px 14px; color:#94a3b8; font-size:0.82rem;"><?= htmlspecialchars($role['label']) ?></td>
                <td style="padding:12px 14px; text-align:center;">
                  <?php if (!$exists): ?>
                    <span style="color:#374151; font-size:0.75rem;">غير موجود</span>
                  <?php elseif ($is_up): ?>
                    <span style="display:inline-flex;align-items:center;gap:5px;background:rgba(34,197,94,0.12);color:#22c55e;padding:4px 12px;border-radius:10px;font-weight:700;font-size:0.78rem;"><span style="width:7px;height:7px;background:#22c55e;border-radius:50%;display:inline-block;"></span>متصل</span>
                  <?php else: ?>
                    <span style="display:inline-flex;align-items:center;gap:5px;background:rgba(100,116,139,0.12);color:#475569;padding:4px 12px;border-radius:10px;font-weight:700;font-size:0.78rem;"><span style="width:7px;height:7px;background:#475569;border-radius:50%;display:inline-block;"></span>مفصول</span>
                  <?php endif; ?>
                </td>
                <td style="padding:12px 14px; font-family:monospace; color:<?= $is_up && $exists ? '#00d4ff' : '#374151' ?>; font-size:0.82rem;"><?= htmlspecialchars($ip_addr) ?></td>
                <td style="padding:12px 14px; text-align:center;"><?= $mode_badge ?></td>
                <td style="padding:12px 14px; color:#64748b; font-size:0.8rem; font-family:monospace;"><?= $speed ?: '—' ?></td>
              </tr>
            <?php endforeach; ?>
            <?php // عرض أي منافذ إضافية غير مدرجة في القائمة المحددة
            foreach ($extra_ifaces as $iface):
                if (in_array($iface, $shown)) continue;
                $is_up = getInterfaceCarrier($iface);
                $ip_addr = getInterfaceIP($iface);
                $speed = $is_up ? getInterfaceSpeed($iface) : '';
                $port_color = $is_up ? '#22c55e' : '#475569';
                $mode = $iface_rules_db[$iface] ?? 'hotspot';
                if ($mode === 'bypass') {
                    $mode_badge = '<span style="background:rgba(34,197,94,0.15);color:#22c55e;padding:3px 10px;border-radius:8px;font-size:0.72rem;font-weight:700;">🟢 نت مباشر</span>';
                } elseif ($mode === 'blocked') {
                    $mode_badge = '<span style="background:rgba(239,68,68,0.15);color:#ef4444;padding:3px 10px;border-radius:8px;font-size:0.72rem;font-weight:700;">🔴 محظور</span>';
                } else {
                    $mode_badge = '<span style="background:rgba(0,212,255,0.1);color:#00d4ff;padding:3px 10px;border-radius:8px;font-size:0.72rem;font-weight:700;">🔵 بوابة الكروت</span>';
                }
            ?>
              <tr style="border-bottom:1px solid rgba(255,255,255,0.04);">
                <td style="padding:12px 14px;">
                  <div style="display:flex;align-items:center;gap:8px;">
                    <span style="font-size:1.2rem;">🔌</span>
                    <div style="font-family:monospace;font-weight:800;color:#fff;font-size:0.88rem;"><?= htmlspecialchars($iface) ?></div>
                  </div>
                </td>
                <td style="padding:12px 14px; color:#64748b; font-size:0.82rem;">واجهة شبكة إضافية</td>
                <td style="padding:12px 14px; text-align:center;">
                  <?= $is_up
                    ? '<span style="display:inline-flex;align-items:center;gap:5px;background:rgba(34,197,94,0.12);color:#22c55e;padding:4px 12px;border-radius:10px;font-weight:700;font-size:0.78rem;"><span style="width:7px;height:7px;background:#22c55e;border-radius:50%;display:inline-block;"></span>متصل</span>'
                    : '<span style="display:inline-flex;align-items:center;gap:5px;background:rgba(100,116,139,0.12);color:#475569;padding:4px 12px;border-radius:10px;font-weight:700;font-size:0.78rem;"><span style="width:7px;height:7px;background:#475569;border-radius:50%;display:inline-block;"></span>مفصول</span>'
                  ?>
                </td>
                <td style="padding:12px 14px; font-family:monospace; color:<?= $is_up ? '#00d4ff' : '#374151' ?>; font-size:0.82rem;"><?= htmlspecialchars($ip_addr) ?></td>
                <td style="padding:12px 14px; text-align:center;"><?= $mode_badge ?></td>
                <td style="padding:12px 14px; color:#64748b; font-size:0.8rem; font-family:monospace;"><?= $speed ?: '—' ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
    </div>

    <!-- Speed Test -->
    <div class="box">
      <h3>🚀 اختبار سرعة الإنترنت</h3>
      <form method="POST">
        <button type="submit" name="speed_test" class="btn btn-success">▶️ بدء الاختبار</button>
      </form>
      <?php if ($speed_test_result): ?>
        <pre><?= htmlspecialchars($speed_test_result) ?></pre>
      <?php else: ?>
        <p style="color:#475569; font-size:0.85rem; margin-top:10px;">اضغط الزر لبدء اختبار السرعة. قد يستغرق بضع ثوانٍ.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Diagnostics Tab -->
  <div id="tab-diagnostics" class="tab-content">
    <div class="grid2">
      <div class="box">
        <h3>🛠️ فحص الاتصال (Ping)</h3>
        <form method="POST">
          <input type="text" name="ping_host" placeholder="مثال: google.com أو 8.8.8.8" required value="<?= htmlspecialchars($_POST['ping_host'] ?? '') ?>">
          <button type="submit" class="btn btn-primary">🚀 ابدأ الفحص</button>
        </form>
        <?php if ($ping_result): ?>
          <pre><?= htmlspecialchars($ping_result) ?></pre>
        <?php endif; ?>
      </div>

      <div class="box">
        <h3>🔍 تتبع المسار (Traceroute)</h3>
        <form method="POST">
          <input type="text" name="traceroute_host" placeholder="مثال: google.com" required value="<?= htmlspecialchars($_POST['traceroute_host'] ?? '') ?>">
          <button type="submit" class="btn btn-info">🔍 تتبع</button>
        </form>
        <?php if ($traceroute_result): ?>
          <pre><?= htmlspecialchars($traceroute_result) ?></pre>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Devices Tab -->
  <div id="tab-devices" class="tab-content">
    <div class="box">
      <h3>📱 الأجهزة المتصلة (DHCP Leases)</h3>
      <table>
        <tr>
          <th>اسم الجهاز</th>
          <th>عنوان IP</th>
          <th>عنوان MAC</th>
          <th>الوقت المتبقي</th>
          <th>الحالة</th>
          <th>إجراء</th>
        </tr>
        <?php if ($dhcp_leases): ?>
          <?php foreach ($dhcp_leases as $l): 
            $is_online = $db->prepare('SELECT COUNT(*) FROM online_users WHERE ip_address = ?');
            $is_online->execute([$l['ip']]);
            $online = $is_online->fetchColumn() > 0;
            $is_bypassed = isMacBypassed($l['mac']);
          ?>
          <tr>
            <td><strong><?= htmlspecialchars($l['name']) ?></strong></td>
            <td style="font-family:monospace; color:#00d4ff;"><?= htmlspecialchars($l['ip']) ?></td>
            <td style="font-family:monospace; color:#64748b;"><?= htmlspecialchars($l['mac']) ?></td>
            <td><?= htmlspecialchars($l['left']) ?></td>
            <td>
              <?php if ($online): ?>
                <span style="color:#22c55e; font-size:0.78rem;">🟢 نشط</span>
              <?php elseif ($is_bypassed): ?>
                <span style="color:#00d4ff; font-size:0.78rem;">🔒 مستثنى</span>
              <?php else: ?>
                <span style="color:#475569; font-size:0.78rem;">⚫ غير نشط</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if (!$is_bypassed): ?>
                <form method="POST" style="margin:0; display:inline;">
                  <input type="hidden" name="mac_address" value="<?= htmlspecialchars($l['mac']) ?>">
                  <input type="hidden" name="description" value="<?= htmlspecialchars($l['name']) ?>">
                  <button type="submit" name="add_bypass" class="btn btn-info btn-sm">➕ استثناء الجهاز</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="6" style="text-align:center; color:#475569; padding:30px;">لا يوجد أجهزة مسجلة في الـ DHCP حالياً</td></tr>
        <?php endif; ?>
      </table>
    </div>
  </div>

  <!-- Bypass Tab -->
  <div id="tab-bypass" class="tab-content">
    <div class="grid2">
      <div class="box">
        <h3>🔒 استثناء جهاز جديد (تخطي تسجيل الدخول)</h3>
        <form method="POST">
          <div class="form-group">
            <label>عنوان الماك (MAC Address)</label>
            <input type="text" name="mac_address" placeholder="مثال: 00:11:22:33:44:55" required style="font-family: monospace; text-transform: uppercase;">
          </div>
          <div class="form-group">
            <label>اسم أو وصف الجهاز</label>
            <input type="text" name="description" placeholder="مثال: شاشة ذكية / هاتف المدير">
          </div>
          <button type="submit" name="add_bypass" class="btn btn-primary">➕ إضافة للأجهزة المستثناة</button>
        </form>
      </div>

      <div class="box">
        <h3>📋 قائمة الأجهزة المستثناة</h3>
        <table>
          <tr>
            <th>الوصف</th>
            <th>عنوان MAC</th>
            <th>تاريخ الإضافة</th>
            <th>إجراء</th>
          </tr>
          <?php if ($bypasses): ?>
            <?php foreach ($bypasses as $b): ?>
            <tr>
              <td><strong><?= htmlspecialchars($b['description'] ?: 'بدون وصف') ?></strong></td>
              <td style="font-family:monospace; color:#00d4ff;"><?= htmlspecialchars($b['mac_address']) ?></td>
              <td style="font-size:0.75rem; color:#64748b;"><?= $b['created_at'] ?></td>
              <td>
                <a href="index.php?delete_bypass=<?= $b['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('إزالة استثناء الجهاز؟')">🗑️ حذف</a>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="4" style="text-align:center; color:#475569; padding:30px;">لا توجد أجهزة مستثناة حالياً</td></tr>
          <?php endif; ?>
        </table>
      </div>
    </div>
  </div>

  <!-- Interfaces Tab -->
  <div id="tab-interfaces" class="tab-content">
    <div class="grid2">
      <div class="box">
        <h3>🔌 ضبط ووضع منفذ / شبكة</h3>
        <form method="POST">
          <div class="form-group">
            <label>اختر المنفذ أو واجهة الشبكة</label>
            <select name="interface_name" required>
              <option value="">اختر منفذ...</option>
              <?php foreach ($interfaces as $iface): ?>
                <option value="<?= htmlspecialchars($iface) ?>"><?= htmlspecialchars($iface) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label>الوضع (Mode)</label>
            <select name="mode" required>
              <option value="hotspot"> خاضع لتسجيل الدخول (Hotspot)</option>
              <option value="bypass"> نت مباشر بدون كروت (Direct Bypass)</option>
              <option value="blocked"> حظر كامل للإنترنت (Blocked)</option>
            </select>
          </div>
          <div class="form-group">
            <label>وصف / ملاحظة</label>
            <input type="text" name="description" placeholder="مثال: منفذ LAN 1 الخاص بالمكتب">
          </div>
          <button type="submit" name="update_interface" class="btn btn-primary">💾 حفظ وتطبيق الإعدادات</button>
        </form>
      </div>

      <div class="box">
        <h3>📋 أوضاع فتحات وواجهات الشبكة الحالية</h3>
        <table>
          <tr>
            <th>اسم الواجهة/المنفذ</th>
            <th>الوضع الحالي</th>
            <th>الوصف</th>
            <th>تاريخ الضبط</th>
          </tr>
          <?php
            $current_rules = $db->query('SELECT * FROM interface_rules')->fetchAll();
            if ($current_rules):
              foreach ($current_rules as $rule):
          ?>
          <tr>
            <td><strong style="color:var(--primary); font-family:monospace;"><?= htmlspecialchars($rule['interface_name']) ?></strong></td>
            <td>
              <?php if ($rule['mode'] === 'bypass'): ?>
                <span style="color:#22c55e; font-weight:700;">🟢 نت مباشر</span>
              <?php elseif ($rule['mode'] === 'blocked'): ?>
                <span style="color:#ef4444; font-weight:700;">🔴 حظر كامل</span>
              <?php else: ?>
                <span style="color:#94a3b8; font-weight:700;">🔵 بوابة كروت</span>
              <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($rule['description']) ?></td>
            <td style="font-size:0.75rem; color:#64748b;"><?= $rule['created_at'] ?></td>
          </tr>
          <?php
              endforeach;
            else:
          ?>
            <tr><td colspan="4" style="text-align:center; color:#475569; padding:30px;">كافة المنافذ تعمل بوضع البوابة الافتراضية (خاضعة للكروت)</td></tr>
          <?php endif; ?>
        </table>
      </div>
    </div>
  </div>

  <!-- Router Settings Tab -->
  <div id="tab-router" class="tab-content">
    <div class="grid2">
      <!-- LAN IP -->
      <div class="box">
        <h3>⚙️ إعدادات الآي بي المحلي (LAN IP)</h3>
        <form method="POST">
          <div class="form-group">
            <label>عنوان IP المحلي الحالي</label>
            <input type="text" value="<?= htmlspecialchars($lan_ip) ?>" disabled style="opacity: 0.6;">
          </div>
          <div class="form-group">
            <label>عنوان IP المحلي الجديد</label>
            <input type="text" name="lan_ip" placeholder="مثال: 192.168.77.1" required value="<?= htmlspecialchars($lan_ip) ?>">
          </div>
          <div class="form-group">
            <label>قناع الشبكة (Subnet Mask)</label>
            <input type="text" name="netmask" value="255.255.255.0" required>
          </div>
          <button type="submit" name="change_lan_ip" class="btn btn-primary" onclick="return confirm('تنبيه: سيؤدي هذا لتغيير آي بي الراوتر وإعادة تحميل الشبكة وقد ينقطع اتصالك باللوحة. هل تريد المتابعة؟')">💾 حفظ وتعديل IP</button>
        </form>
      </div>

      <!-- Power Controls -->
      <div class="box">
        <h3>🔌 التحكم في الطاقة والتشغيل</h3>
        <p style="font-size:0.85rem; color:#94a3b8; margin-bottom:20px; line-height: 1.5;">تحكم في تشغيل الراوتر بشكل مباشر وآمن عن بعد:</p>
        <div style="display:flex; gap:12px; flex-direction:column;">
          <a href="index.php?reboot=1" class="btn btn-primary" onclick="return confirm('هل تريد بالتأكيد إعادة تشغيل الجهاز؟')" style="justify-content:center;">🔄 إعادة تشغيل الجهاز (Reboot)</a>
          <a href="index.php?shutdown=1" class="btn btn-danger" onclick="return confirm('هل تريد بالتأكيد إيقاف تشغيل الجهاز تماماً؟')" style="justify-content:center;">🔌 إيقاف تشغيل الجهاز (Shutdown)</a>
        </div>
      </div>
    </div>

    <!-- WiFi Settings Form (Merged) -->
    <form method="POST">
      <!-- 2.4GHz -->
      <div class="box">
        <div class="section-title">📶 إعدادات الواي فاي 2.4 GHz</div>
        <div class="form-group">
          <label>اسم الشبكة (SSID)</label>
          <input type="text" name="ssid_2g" value="<?= htmlspecialchars($config_2g['ssid']) ?>" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>نوع التشفير</label>
            <select name="encryption_2g" id="encryption_2g">
              <option value="psk2" <?= $config_2g['encryption'] == 'psk2' ? 'selected' : '' ?>>WPA2-PSK</option>
              <option value="mixed-psk" <?= $config_2g['encryption'] == 'mixed-psk' ? 'selected' : '' ?>>WPA/WPA2 مختلط</option>
              <option value="none" <?= $config_2g['encryption'] == 'none' ? 'selected' : '' ?>>مفتوح (بدون كلمة مرور)</option>
            </select>
          </div>
          <div class="form-group">
            <label>كلمة المرور (8 رموز على الأقل)</label>
            <input type="text" name="key_2g" id="key_2g" value="<?= htmlspecialchars($config_2g['key']) ?>" <?= $config_2g['encryption'] == 'none' ? 'disabled' : '' ?>>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>القناة</label>
            <select name="channel_2g">
              <option value="auto" <?= $config_2g['channel'] == 'auto' ? 'selected' : '' ?>>تلقائي</option>
              <?php for ($ch = 1; $ch <= 11; $ch++): ?>
                <option value="<?= $ch ?>" <?= $config_2g['channel'] == $ch ? 'selected' : '' ?>><?= $ch ?></option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="form-group">
            <label>عرض النطاق</label>
            <select name="htmode_2g">
              <option value="HT20" <?= $config_2g['htmode'] == 'HT20' ? 'selected' : '' ?>>20 MHz</option>
              <option value="HT40" <?= $config_2g['htmode'] == 'HT40' ? 'selected' : '' ?>>40 MHz</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>الدولة</label>
            <input type="text" name="country_2g" value="<?= htmlspecialchars($config_2g['country']) ?>" maxlength="2" style="text-transform:uppercase">
          </div>
          <div class="form-group">
            <div class="checkbox-group">
              <input type="checkbox" name="radio_disabled_2g" id="radio_disabled_2g" <?= $config_2g['radio_disabled'] ? '' : 'checked' ?>>
              <label for="radio_disabled_2g">تمكين بث 2.4GHz</label>
            </div>
          </div>
        </div>
      </div>

      <!-- 5GHz -->
      <div class="box">
        <div class="section-title">⚡ إعدادات الواي فاي 5 GHz</div>
        <div class="form-group">
          <label>اسم الشبكة (SSID)</label>
          <input type="text" name="ssid_5g" value="<?= htmlspecialchars($config_5g['ssid']) ?>" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>نوع التشفير</label>
            <select name="encryption_5g" id="encryption_5g">
              <option value="psk2" <?= $config_5g['encryption'] == 'psk2' ? 'selected' : '' ?>>WPA2-PSK</option>
              <option value="mixed-psk" <?= $config_5g['encryption'] == 'mixed-psk' ? 'selected' : '' ?>>WPA/WPA2 مختلط</option>
              <option value="none" <?= $config_5g['encryption'] == 'none' ? 'selected' : '' ?>>مفتوح (بدون كلمة مرور)</option>
            </select>
          </div>
          <div class="form-group">
            <label>كلمة المرور (8 رموز على الأقل)</label>
            <input type="text" name="key_5g" id="key_5g" value="<?= htmlspecialchars($config_5g['key']) ?>" <?= $config_5g['encryption'] == 'none' ? 'disabled' : '' ?>>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>القناة</label>
            <select name="channel_5g">
              <option value="auto" <?= $config_5g['channel'] == 'auto' ? 'selected' : '' ?>>تلقائي</option>
              <option value="36" <?= $config_5g['channel'] == '36' ? 'selected' : '' ?>>36 (5180 MHz)</option>
              <option value="40" <?= $config_5g['channel'] == '40' ? 'selected' : '' ?>>40 (5200 MHz)</option>
              <option value="44" <?= $config_5g['channel'] == '44' ? 'selected' : '' ?>>44 (5220 MHz)</option>
              <option value="48" <?= $config_5g['channel'] == '48' ? 'selected' : '' ?>>48 (5240 MHz)</option>
            </select>
          </div>
          <div class="form-group">
            <label>عرض النطاق</label>
            <select name="htmode_5g">
              <option value="VHT20" <?= $config_5g['htmode'] == 'VHT20' ? 'selected' : '' ?>>20 MHz</option>
              <option value="VHT40" <?= $config_5g['htmode'] == 'VHT40' ? 'selected' : '' ?>>40 MHz</option>
              <option value="VHT80" <?= $config_5g['htmode'] == 'VHT80' ? 'selected' : '' ?>>80 MHz</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>الدولة</label>
            <input type="text" name="country_5g" value="<?= htmlspecialchars($config_5g['country']) ?>" maxlength="2" style="text-transform:uppercase">
          </div>
          <div class="form-group">
            <div class="checkbox-group">
              <input type="checkbox" name="radio_disabled_5g" id="radio_disabled_5g" <?= $config_5g['radio_disabled'] ? '' : 'checked' ?>>
              <label for="radio_disabled_5g">تمكين بث 5GHz</label>
            </div>
          </div>
        </div>
      </div>

      <div style="text-align:center; margin-bottom: 20px;">
        <button type="submit" name="save_wifi" class="btn btn-success">💾 حفظ وتحديث إعدادات الواي فاي</button>
      </div>
    </form>
  </div>

  <!-- Advanced Tab -->
  <div id="tab-advanced" class="tab-content">
    <div class="grid2">
      <div class="box">
        <h3>🗺️ جدول التوجيه</h3>
        <pre><?= htmlspecialchars($route_table) ?: 'لا توجد بيانات' ?></pre>
      </div>
      <div class="box">
        <h3>📊 إحصائيات iptables</h3>
        <pre><?= htmlspecialchars($iptables_stats) ?: 'لا توجد بيانات' ?></pre>
      </div>
    </div>
  </div>
</div>

<script>
function showTab(tabId) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + tabId).classList.add('active');
  
  // إيجاد وزر التبويب المضغط
  const btns = document.querySelectorAll('.tab-btn');
  btns.forEach(btn => {
    if (btn.getAttribute('onclick').includes("'" + tabId + "'")) {
      btn.classList.add('active');
    }
  });
  
  // تحديث الرابط بدون ريلود
  const url = new URL(window.location);
  url.searchParams.set('tab', tabId);
  window.history.pushState({}, '', url);
}

document.addEventListener('DOMContentLoaded', function() {
  const urlParams = new URLSearchParams(window.location.search);
  const activeTab = urlParams.get('tab') || 'overview';
  showTab(activeTab);
  
  // التحكم بتعطيل/تمكين حقول الكلمات السرية
  const enc2g = document.getElementById('encryption_2g');
  const key2g = document.getElementById('key_2g');
  if (enc2g && key2g) {
    enc2g.addEventListener('change', function() {
      key2g.disabled = (this.value === 'none');
      if (this.value === 'none') key2g.value = '';
    });
  }

  const enc5g = document.getElementById('encryption_5g');
  const key5g = document.getElementById('key_5g');
  if (enc5g && key5g) {
    enc5g.addEventListener('change', function() {
      key5g.disabled = (this.value === 'none');
      if (this.value === 'none') key5g.value = '';
    });
  }
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>