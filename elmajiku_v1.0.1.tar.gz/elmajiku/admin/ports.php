<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/iptables.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

$success = '';
$error = '';

// معالجة طلبات POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. إضافة قاعدة منفذ جديدة
    if (isset($_POST['action']) && $_POST['action'] === 'add_rule') {
        $name = trim($_POST['name'] ?? '');
        $type = trim($_POST['type'] ?? 'open'); // open أو forward
        $proto = trim($_POST['proto'] ?? 'tcp'); // tcp, udp, both
        $ext_port = intval($_POST['ext_port'] ?? 0);
        $int_ip = trim($_POST['int_ip'] ?? '');
        $int_port = intval($_POST['int_port'] ?? 0);
        
        if (empty($name)) {
            $error = 'يرجى إدخال اسم القاعدة لتمييزها';
        } elseif ($ext_port <= 0 || $ext_port > 65535) {
            $error = 'يرجى إدخال منفذ خارجي صحيح (بين 1 و 65535)';
        } elseif ($type === 'forward' && empty($int_ip)) {
            $error = 'لتوجيه المنفذ، يجب إدخال عنوان الأي بي الداخلي للجهاز';
        } elseif ($type === 'forward' && ($int_port <= 0 || $int_port > 65535)) {
            $error = 'يرجى إدخال منفذ داخلي صحيح للجهاز المستهدف';
        } else {
            $stmt = $db->prepare('INSERT INTO port_rules (name, type, proto, ext_port, int_ip, int_port, status) VALUES (?, ?, ?, ?, ?, ?, 1)');
            if ($stmt->execute([$name, $type, $proto, $ext_port, $type === 'forward' ? $int_ip : null, $type === 'forward' ? $int_port : null])) {
                // تطبيق القواعد فوراً
                applyPortRules();
                $success = 'تمت إضافة قاعدة المنفذ وتطبيقها بنجاح';
            } else {
                $error = 'حدث خطأ أثناء حفظ القاعدة في قاعدة البيانات';
            }
        }
    }
    
    // 2. تفعيل / تعطيل القاعدة
    if (isset($_POST['action']) && $_POST['action'] === 'toggle_rule') {
        $rule_id = intval($_POST['id'] ?? 0);
        $stmt = $db->prepare('SELECT status FROM port_rules WHERE id = ?');
        $stmt->execute([$rule_id]);
        $current_status = $stmt->fetchColumn();
        
        if ($current_status !== false) {
            $new_status = $current_status ? 0 : 1;
            $stmt = $db->prepare('UPDATE port_rules SET status = ? WHERE id = ?');
            $stmt->execute([$new_status, $rule_id]);
            // تطبيق القواعد فوراً
            applyPortRules();
            $success = 'تم تحديث حالة القاعدة بنجاح';
        }
    }
    
    // 3. حذف قاعدة منفذ
    if (isset($_POST['action']) && $_POST['action'] === 'delete_rule') {
        $rule_id = intval($_POST['id'] ?? 0);
        $stmt = $db->prepare('DELETE FROM port_rules WHERE id = ?');
        $stmt->execute([$rule_id]);
        // تطبيق القواعد فوراً
        applyPortRules();
        $success = 'تم حذف قاعدة المنفذ وإزالتها من الراوتر';
    }
}

// جلب جميع قواعد المنافذ
$rules = $db->query('SELECT * FROM port_rules ORDER BY created_at DESC')->fetchAll();

$page_title = 'إدارة المنافذ وفتح البورتات';
$active_page = 'ports';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<div class="main">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
    <div>
      <h1 style="font-size:1.6rem; font-weight:800; background:linear-gradient(90deg, #fff, var(--primary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">🔌 إدارة المنافذ وفتح البورتات</h1>
      <p style="color:var(--text-muted); font-size:0.85rem; margin-top:4px;">افتح منافذ (Ports) في الراوتر نفسه أو قم بتوجيهها (Port Forwarding) للأجهزة والسيرفرات داخل الشبكة المحلية الخاصة بك.</p>
    </div>
  </div>

  <?php if ($success): ?>
    <div class="alert success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>
  <?php if ($error): ?>
    <div class="alert danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 24px; align-items: start;">
    
    <!-- كارت إضافة قاعدة جديدة -->
    <div class="box">
      <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:20px; border-bottom:1px solid var(--border); padding-bottom:10px; color:var(--primary);">➕ إضافة قاعدة منفذ جديدة</h3>
      <form method="POST" autocomplete="off">
        <input type="hidden" name="action" value="add_rule">
        
        <div style="margin-bottom:12px;">
          <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">اسم القاعدة</label>
          <input type="text" name="name" placeholder="مثال: فتح سيرفر الكاميرات" required>
        </div>

        <div style="margin-bottom:12px;">
          <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">نوع القاعدة</label>
          <select name="type" id="rule_type" onchange="toggleForwardFields()" style="width:100%;">
            <option value="open">🔓 فتح منفذ بالراوتر نفسه (Open Input)</option>
            <option value="forward">🔗 توجيه منفذ لجهاز داخلي (Port Forwarding)</option>
          </select>
        </div>

        <div style="margin-bottom:12px;">
          <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">البروتوكول</label>
          <select name="proto" style="width:100%;">
            <option value="tcp">TCP</option>
            <option value="udp">UDP</option>
            <option value="both">TCP + UDP (كلاهما)</option>
          </select>
        </div>

        <div style="margin-bottom:12px;">
          <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;" id="port_label">المنفذ الخارجي</label>
          <input type="number" name="ext_port" placeholder="مثال: 8080" min="1" max="65535" required>
        </div>

        <!-- حقول إضافية فقط للتوجيه Forwarding -->
        <div id="forward_fields" style="display:none; border-top:1px solid var(--border); padding-top:12px; margin-top:12px; transition:all 0.2s;">
          <div style="margin-bottom:12px;">
            <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">الأي بي الداخلي المستهدف</label>
            <input type="text" name="int_ip" id="int_ip" placeholder="مثال: 192.168.77.100">
          </div>
          
          <div style="margin-bottom:12px;">
            <label style="display:block; margin-bottom:6px; font-size:0.8rem; font-weight:600;">المنفذ الداخلي للجهاز</label>
            <input type="number" name="int_port" id="int_port" placeholder="مثال: 80" min="1" max="65535">
          </div>
        </div>
        
        <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center; margin-top:10px;">⚡ حفظ وتطبيق القاعدة</button>
      </form>
    </div>

    <!-- كارت القواعد الحالية -->
    <div class="box">
      <h3 style="font-size:1.05rem; font-weight:700; margin-bottom:20px; border-bottom:1px solid var(--border); padding-bottom:10px;">📋 قواعد فتح وتوجيه المنافذ الحالية (<?= count($rules) ?>)</h3>
      
      <?php if (empty($rules)): ?>
        <div style="text-align:center; padding:40px; color:var(--text-muted);">
          <span style="font-size:3rem; display:block; margin-bottom:10px;">🔌</span>
          لا توجد قواعد منافذ مضافة حالياً.
        </div>
      <?php else: ?>
        <div style="overflow-x:auto;">
          <table style="width:100%; border-collapse:collapse; text-align:right; font-size:0.85rem;">
            <thead>
              <tr style="border-bottom:1px solid var(--border); color:var(--text-muted); height:40px;">
                <th style="padding:10px 5px;">اسم القاعدة</th>
                <th style="padding:10px 5px;">النوع</th>
                <th style="padding:10px 5px;">البروتوكول</th>
                <th style="padding:10px 5px;">المنفذ الخارجي</th>
                <th style="padding:10px 5px;">التوجيه الداخلي</th>
                <th style="padding:10px 5px; text-align:center;">الحالة</th>
                <th style="padding:10px 5px; text-align:center;">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rules as $r): ?>
                <tr style="border-bottom:1px solid rgba(255,255,255,0.02); height:50px;">
                  <td style="padding:5px; font-weight:700; color:#fff;"><?= htmlspecialchars($r['name']) ?></td>
                  <td style="padding:5px;">
                    <span style="font-size:0.72rem; padding:3px 6px; border-radius:6px; background:<?= $r['type'] === 'open' ? 'rgba(0,212,255,0.1)' : 'rgba(124,58,237,0.1)' ?>; color:<?= $r['type'] === 'open' ? 'var(--primary)' : 'var(--secondary)' ?>;">
                      <?= $r['type'] === 'open' ? '🔓 فتح منفذ' : '🔗 توجيه' ?>
                    </span>
                  </td>
                  <td style="padding:5px; font-family:monospace; font-weight:600;"><?= strtoupper($r['proto']) ?></td>
                  <td style="padding:5px; font-family:monospace; font-weight:700; color:var(--primary);"><?= $r['ext_port'] ?></td>
                  <td style="padding:5px; font-family:monospace; color:var(--text-muted);">
                    <?= $r['type'] === 'forward' ? htmlspecialchars($r['int_ip'] . ':' . $r['int_port']) : '-' ?>
                  </td>
                  <td style="padding:5px; text-align:center;">
                    <span style="font-size:0.7rem; font-weight:700; padding:2px 6px; border-radius:6px; background:<?= $r['status'] ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)' ?>; color:<?= $r['status'] ? '#22c55e' : '#ef4444' ?>;">
                      <?= $r['status'] ? 'نشط' : 'معطل' ?>
                    </span>
                  </td>
                  <td style="padding:5px; text-align:center; display:flex; gap:6px; justify-content:center; align-items:center; height:50px;">
                    <form method="POST" style="display:inline;">
                      <input type="hidden" name="action" value="toggle_rule">
                      <input type="hidden" name="id" value="<?= $r['id'] ?>">
                      <button type="submit" class="btn <?= $r['status'] ? 'btn-secondary' : 'btn-success' ?>" style="padding:4px 8px; font-size:0.72rem; height:28px;">
                        <?= $r['status'] ? '⏸️' : '▶️' ?>
                      </button>
                    </form>
                    
                    <form method="POST" style="display:inline;" onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذه القاعدة وإيقافها بالراوتر؟');">
                      <input type="hidden" name="action" value="delete_rule">
                      <input type="hidden" name="id" value="<?= $r['id'] ?>">
                      <button type="submit" class="btn btn-danger" style="padding:4px 8px; font-size:0.72rem; height:28px;">🗑️</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<script>
function toggleForwardFields() {
  const typeSelect = document.getElementById('rule_type');
  const forwardFields = document.getElementById('forward_fields');
  const portLabel = document.getElementById('port_label');
  const intIp = document.getElementById('int_ip');
  const intPort = document.getElementById('int_port');
  
  if (typeSelect && typeSelect.value === 'forward') {
    forwardFields.style.display = 'block';
    portLabel.textContent = 'المنفذ الخارجي (المنفذ المطلوب طلبه من الخارج)';
    if (intIp) intIp.setAttribute('required', 'required');
    if (intPort) intPort.setAttribute('required', 'required');
  } else {
    forwardFields.style.display = 'none';
    portLabel.textContent = 'المنفذ الخارجي لفتحه في الراوتر';
    if (intIp) intIp.removeAttribute('required');
    if (intPort) intPort.removeAttribute('required');
  }
}

// تشغيل الفحص عند التحميل لضمان إعداد الحقول بشكل صحيح
document.addEventListener('DOMContentLoaded', toggleForwardFields);
</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
