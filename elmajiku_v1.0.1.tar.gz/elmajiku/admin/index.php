<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';

if (isAdminLoggedIn()) {
    header('Location: ' . ADMIN_URL . '/dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    if (adminLogin($user, $pass)) {
        header('Location: ' . ADMIN_URL . '/dashboard.php');
        exit;
    } else {
        $error = 'اسم المستخدم أو كلمة المرور غير صحيح';
    }
}

$settings = getSettings();
$primary   = $settings['primary_color']   ?? '#00d4ff';
$secondary = $settings['secondary_color'] ?? '#7c3aed';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($settings['login_title'] ?? 'تسجيل الدخول') ?> - <?= htmlspecialchars($settings['site_name']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --primary:   <?= $primary ?>;
  --secondary: <?= $secondary ?>;
}
* { margin:0; padding:0; box-sizing:border-box; }
body {
  min-height:100vh;
  display:flex; align-items:center; justify-content:center;
  background: #070913;
  font-family: 'Cairo', system-ui, -apple-system, sans-serif;
  overflow:hidden;
}

/* الهالات الضوئية المتحركة في الخلفية */
.blob {
  position:fixed;
  border-radius:50%;
  filter:blur(120px);
  opacity:0.12;
  pointer-events:none;
  animation: float-blob 20s infinite alternate;
}
.blob-1 { width:600px; height:600px; background:var(--primary);  top:-200px; right:-200px; }
.blob-2 { width:500px; height:500px; background:var(--secondary); bottom:-200px; left:-150px; animation-delay:-7s; }
@keyframes float-blob {
  0%   { transform: translate(0,0) scale(1); }
  100% { transform: translate(80px,60px) scale(1.12); }
}

/* بطاقة تسجيل الدخول */
.login-card {
  background: rgba(22, 27, 39, 0.5);
  backdrop-filter: blur(24px);
  -webkit-backdrop-filter: blur(24px);
  border: 1px solid rgba(255,255,255,0.07);
  border-radius: 24px;
  padding: 44px 40px;
  width: 380px;
  max-width: 94vw;
  box-shadow: 0 24px 64px rgba(0,0,0,0.5);
  position: relative;
  z-index: 10;
  animation: slide-in 0.4s ease;
}
@keyframes slide-in {
  from { opacity:0; transform:translateY(20px); }
  to   { opacity:1; transform:translateY(0); }
}

/* شريط ملوّن في الأعلى */
.login-card::before {
  content:'';
  position:absolute; top:0; left:0; right:0; height:3px;
  border-radius:24px 24px 0 0;
  background:linear-gradient(90deg, var(--primary), var(--secondary));
}

/* الشعار */
.logo { text-align:center; margin-bottom:34px; }
.logo-icon {
  width:68px; height:68px; border-radius:18px;
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  display:inline-flex; align-items:center; justify-content:center;
  font-size:1.9rem; margin-bottom:14px;
  box-shadow: 0 8px 24px rgba(0,212,255,0.2);
}
.logo h1 {
  font-size:1.3rem; font-weight:800; color:#f1f5f9; margin-bottom:4px;
}
.logo p {
  color:#64748b; font-size:0.82rem;
}

/* مجموعة النموذج */
.form-group { margin-bottom:18px; }
.form-group label {
  display:block; color:#94a3b8;
  font-size:0.82rem; font-weight:700;
  margin-bottom:7px;
}
.form-group input {
  width:100%; padding:12px 15px;
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 11px;
  color:#fff; font-size:0.9rem;
  outline:none; font-family:inherit;
  transition: all 0.25s;
}
.form-group input:focus {
  border-color: var(--primary);
  background: rgba(255,255,255,0.07);
  box-shadow: 0 0 0 3px rgba(0,212,255,0.1);
}

/* زر الدخول */
.submit-btn {
  width:100%; padding:13px;
  border:none; border-radius:12px;
  cursor:pointer;
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  color:#fff; font-size:0.95rem; font-weight:800;
  font-family:inherit; letter-spacing:0.5px;
  transition: all 0.25s;
  margin-top:6px;
  box-shadow: 0 4px 15px rgba(0,212,255,0.2);
}
.submit-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0,212,255,0.3);
  opacity:0.95;
}
.submit-btn:active { transform:translateY(0); }

/* رسالة الخطأ */
.error-msg {
  background: rgba(239, 68, 68, 0.1);
  border: 1px solid rgba(239, 68, 68, 0.2);
  color: #ef4444;
  padding: 12px 16px;
  border-radius: 10px;
  margin-bottom: 20px;
  font-size: 0.85rem;
  text-align: center;
  animation: shake 0.3s ease;
}
@keyframes shake {
  0%,100% { transform:translateX(0); }
  25%      { transform:translateX(-6px); }
  75%      { transform:translateX(6px); }
}

/* تذييل */
.login-footer {
  text-align:center; margin-top:22px;
  color:#334155; font-size:0.75rem;
}
</style>
</head>
<body>
<div class="blob blob-1"></div>
<div class="blob blob-2"></div>

<div class="login-card">
  <div class="logo">
    <div class="logo-icon">🔐</div>
    <h1><?= htmlspecialchars($settings['site_name']) ?></h1>
    <p>لوحة تحكم الإدارة | <?= date('Y') ?></p>
  </div>

  <?php if ($error): ?>
    <div class="error-msg">⚠️ <?= $error ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label for="username">👤 اسم المستخدم</label>
      <input type="text" id="username" name="username"
             placeholder="admin" required autofocus autocomplete="username">
    </div>
    <div class="form-group">
      <label for="password">🔑 كلمة المرور</label>
      <input type="password" id="password" name="password"
             placeholder="••••••••" required autocomplete="current-password">
    </div>
    <button type="submit" class="submit-btn">دخول للوحة التحكم →</button>
  </form>

  <div class="login-footer">
    نظام Hotspot الإدارة | OpenWrt
  </div>
</div>
</body>
</html>
