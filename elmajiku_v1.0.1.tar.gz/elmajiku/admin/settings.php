<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$msg = '';

// تغيير كلمة المرور
if (isset($_POST['change_pass'])) {
    $old  = $_POST['old_password'] ?? '';
    $new  = $_POST['new_password'] ?? '';
    $conf = $_POST['confirm_password'] ?? '';

    $admin = $db->prepare('SELECT * FROM admins WHERE id=?');
    $admin->execute([$_SESSION['admin_id']]);
    $admin = $admin->fetch();

    if (!password_verify($old, $admin['password'])) {
        $msg = ['type'=>'error', 'text'=>'كلمة المرور القديمة غلط'];
    } elseif ($new !== $conf) {
        $msg = ['type'=>'error', 'text'=>'كلمة المرور الجديدة مش متطابقة'];
    } elseif (strlen($new) < 6) {
        $msg = ['type'=>'error', 'text'=>'كلمة المرور لازم تكون 6 حروف على الأقل'];
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $db->prepare('UPDATE admins SET password=? WHERE id=?')->execute([$hash, $_SESSION['admin_id']]);
        $msg = ['type'=>'success', 'text'=>'تم تغيير كلمة المرور بنجاح'];
    }
}

// تحديث إعدادات الموقع
if (isset($_POST['save_settings'])) {
    // نحدد أي فورم تم إرساله حتى نحافظ على قيم الحقول الغائبة
    $is_general_form  = isset($_POST['site_name']);     // فورم الإعدادات العامة
    $is_trial_form    = isset($_POST['trial_mb']);       // فورم التجربة المجانية
    $is_security_form = isset($_POST['session_timeout']) || isset($_POST['brute_force_duration']); // فورم الأمان

    $site_name      = trim($_POST['site_name']      ?? ($settings['site_name']      ?? 'ELMAJIKU Hotspot'));
    $login_title    = trim($_POST['login_title']    ?? ($settings['login_title']    ?? ''));
    $portal_title   = trim($_POST['portal_title']   ?? ($settings['portal_title']   ?? ''));
    $portal_welcome = trim($_POST['portal_welcome'] ?? ($settings['portal_welcome'] ?? ''));
    $primary        = trim($_POST['primary_color']   ?? ($settings['primary_color']   ?? '#00d4ff'));
    $secondary      = trim($_POST['secondary_color'] ?? ($settings['secondary_color'] ?? '#7c3aed'));
    $accent         = trim($_POST['accent_color']    ?? ($settings['accent_color']    ?? '#22c55e'));
    $session_timeout = intval($_POST['session_timeout'] ?? ($settings['session_timeout'] ?? 3600)) ?: 3600;
    $device_model    = trim($_POST['device_model']    ?? ($settings['device_model']    ?? ''));
    $firmware_ver    = trim($_POST['firmware_version'] ?? ($settings['firmware_version'] ?? ''));
    $brand_name      = trim($_POST['brand_name']      ?? ($settings['brand_name']      ?? ''));

    // checkbox: نحفظ القيمة الحالية لو مش الفورم بتاعها هو اللي اتبعت
    $auto_refresh  = $is_general_form
        ? (isset($_POST['auto_refresh']) ? 1 : 0)
        : intval($settings['auto_refresh'] ?? 0);
    $trial_enabled = $is_trial_form
        ? (isset($_POST['trial_enabled']) ? 1 : 0)
        : intval($settings['trial_enabled'] ?? 1);
    $trial_mb  = intval($_POST['trial_mb']  ?? ($settings['trial_mb']  ?? 50))  ?: 50;
    $trial_min = intval($_POST['trial_min'] ?? ($settings['trial_min'] ?? 10))  ?: 10;

    $bf_enabled = $is_security_form
        ? (isset($_POST['brute_force_enabled']) ? 1 : 0)
        : intval($settings['brute_force_enabled'] ?? 1);
    $bf_duration = intval($_POST['brute_force_duration'] ?? ($settings['brute_force_duration'] ?? 15)) ?: 15;
    $bf_max_attempts = intval($_POST['brute_force_max_attempts'] ?? ($settings['brute_force_max_attempts'] ?? 5)) ?: 5;

    // Check if columns exist, add if not
    $cols = $db->query("PRAGMA table_info(settings)")->fetchAll(PDO::FETCH_COLUMN, 1);

    $update_fields = ['site_name', 'login_title', 'primary_color', 'secondary_color'];
    $new_fields = ['portal_title', 'portal_welcome', 'accent_color', 'session_timeout', 'auto_refresh', 'trial_enabled', 'trial_mb', 'trial_min', 'device_model', 'firmware_version', 'brand_name', 'brute_force_enabled', 'brute_force_duration', 'brute_force_max_attempts'];

    foreach ($new_fields as $field) {
        if (!in_array($field, $cols)) {
            $db->exec("ALTER TABLE settings ADD COLUMN $field TEXT DEFAULT ''");
        }
    }

    $db->prepare('UPDATE settings SET 
        site_name=?, login_title=?, portal_title=?, portal_welcome=?,
        primary_color=?, secondary_color=?, accent_color=?,
        session_timeout=?, auto_refresh=?, trial_enabled=?, trial_mb=?, trial_min=?,
        device_model=?, firmware_version=?, brand_name=?,
        brute_force_enabled=?, brute_force_duration=?, brute_force_max_attempts=?
        WHERE id = (SELECT id FROM settings LIMIT 1)')
       ->execute([$site_name, $login_title, $portal_title, $portal_welcome,
                  $primary, $secondary, $accent,
                  $session_timeout, $auto_refresh, $trial_enabled, $trial_mb, $trial_min,
                  $device_model, $firmware_ver, $brand_name,
                  $bf_enabled, $bf_duration, $bf_max_attempts]);

    // تحديث الإعدادات بعد الحفظ (نُعيد القراءة من الـ DB)
    $settings = getSettings(true);
    $msg = ['type'=>'success', 'text'=>'تم حفظ الإعدادات بنجاح'];
}

// إعادة تعيين النظام
if (isset($_POST['reset_system'])) {
    $confirm = $_POST['reset_confirm'] ?? '';
    if ($confirm === 'RESET') {
        $db->exec('DELETE FROM online_users');
        $db->exec('DELETE FROM card_logs');
        $db->exec('DELETE FROM devices');
        $msg = ['type'=>'success', 'text'=>'تم إعادة تعيين النظام بنجاح. تم مسح الجلسات والسجلات.'];
    } else {
        $msg = ['type'=>'error', 'text'=>'كلمة التأكيد غير صحيحة. اكتب RESET بالحروف الكبيرة.'];
    }
}

// نسخ احتياطي
if (isset($_GET['backup'])) {
    $backup_file = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $backup_file . '"');

    $tables = $db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        echo "-- Table: $table\n";
        $rows = $db->query("SELECT * FROM $table")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $columns = implode(', ', array_keys($row));
            $values = implode(', ', array_map(function($v) { return is_null($v) ? 'NULL' : "'" . addslashes($v) . "'"; }, array_values($row)));
            echo "INSERT INTO $table ($columns) VALUES ($values);\n";
        }
        echo "\n";
    }
    exit;
}

// معلومات النظام - تنظيف واستبدال الأسماء الافتراضية Horus و H&M بـ ELMAJIKU
$raw_device   = trim(@file_get_contents('/tmp/sysinfo/model')) ?: 'ELMAJIKU Router Pro';
if ($raw_device === 'Unknown' || stripos($raw_device, 'H&M') !== false || stripos($raw_device, 'KM08') !== false) {
    $raw_device = 'ELMAJIKU KM08-708H-9000';
}
$raw_firmware = (function() {
    $rel = @file_get_contents('/etc/openwrt_release');
    if ($rel) {
        if (preg_match('/DISTRIB_RELEASE=["\']([^"\']+)["\']/', $rel, $m)) {
            $ver = $m[1];
            $ver = str_ireplace('Horus-WitWrt', 'ELMAJIKU OS', $ver);
            $ver = str_ireplace('Horus', 'ELMAJIKU', $ver);
            return $ver;
        }
    }
    return 'ELMAJIKU OS 22.03.7 r20341';
})();

$sys_info = [
    'device'   => (!empty($settings['device_model']))   ? $settings['device_model']   : $raw_device,
    'firmware' => (!empty($settings['firmware_version'])) ? $settings['firmware_version'] : $raw_firmware,
    'system'   => $raw_firmware,
    'kernel'   => trim(shell_exec("uname -r")) ?: 'Unknown',
    'memory'   => trim(shell_exec("free | grep Mem | awk '{print int(\$4/1024)}'")) ?: 'N/A',
    'memory_total' => trim(shell_exec("free | grep Mem | awk '{print int(\$2/1024)}'")) ?: 'N/A',
    'storage'  => trim(shell_exec("df /overlay | tail -1 | awk '{print int(\$4/1024)}'")) ?: 'N/A',
    'storage_total' => trim(shell_exec("df /overlay | tail -1 | awk '{print int(\$2/1024)}'")) ?: 'N/A',
    'uptime'   => trim(shell_exec("uptime | awk -F'up ' '{print \$2}' | awk -F',' '{print \$1}'")) ?: 'N/A',
    'cpu_load' => trim(shell_exec("cat /proc/loadavg | awk '{print \$1}'")) ?: 'N/A',
    'php_version' => phpversion(),
    'sqlite_version' => $db->query('SELECT sqlite_version()')->fetchColumn(),
];
?>
<?php
$page_title = 'الإعدادات';
$active_page = 'settings';
$path_prefix = '';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<style>
/* Settings specific styles */
.tabs { display:flex; gap:4px; margin-bottom:20px; background:rgba(255,255,255,0.03); padding:4px; border-radius:12px; }
.tab-btn { padding:10px 20px; border-radius:10px; border:none; background:transparent; color:#94a3b8; cursor:pointer; font-size:0.85rem; font-weight:700; transition:all 0.2s; font-family:inherit; }
.tab-btn.active { background:rgba(0,212,255,0.1); color:var(--primary); }
.tab-btn:hover:not(.active) { color:#cbd5e1; }
.tab-content { display:none; }
.tab-content.active { display:block; }

.progress-bar-system { background:rgba(255,255,255,0.06); border-radius:10px; height:8px; margin-top:6px; }
.progress-bar-system-fill { height:8px; border-radius:10px; background:linear-gradient(90deg,var(--primary),var(--secondary)); transition:width 0.5s; }
</style>

<div class="main">
  <div class="topbar"><h1>⚙️ الإعدادات المتقدمة</h1></div>

  <?php if ($msg): ?>
    <div class="alert <?= $msg['type'] ?>"><?= htmlspecialchars($msg['text']) ?></div>
  <?php endif; ?>

  <!-- Tabs -->
  <div class="tabs">
    <button class="tab-btn active" onclick="showTab('general')">🎨 عام</button>
    <button class="tab-btn" onclick="showTab('security')">🔐 الأمان</button>
    <button class="tab-btn" onclick="showTab('trial')">⚡ التجربة المجانية</button>
    <button class="tab-btn" onclick="showTab('system')">🖥️ النظام</button>
    <button class="tab-btn" onclick="showTab('danger')">⚠️ خطر</button>
  </div>

  <div class="grid2">
    <div>
      <!-- General Settings -->
      <div id="tab-general" class="tab-content active">
        <div class="box">
          <h3>🎨 إعدادات المظهر والموقع</h3>
          <form method="POST">
            <div class="form-group">
              <label>اسم الموقع</label>
              <input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label>عنوان صفحة تسجيل الدخول</label>
              <input type="text" name="login_title" value="<?= htmlspecialchars($settings['login_title'] ?? '') ?>">
            </div>
            <div class="form-group">
              <label>عنوان بوابة العملاء</label>
              <input type="text" name="portal_title" value="<?= htmlspecialchars($settings['portal_title'] ?? '') ?>" placeholder="أهلاً بك في شبكتنا">
            </div>
            <div class="form-group">
              <label>رسالة الترحيب</label>
              <textarea name="portal_welcome" rows="2" placeholder="أدخل كود الكارت لتسجيل الدخول"><?= htmlspecialchars($settings['portal_welcome'] ?? '') ?></textarea>
            </div>
            <div class="form-group">
              <label>اللون الأساسي</label>
              <div class="color-row">
                <input type="color" id="pc" value="<?= $settings['primary_color'] ?? '#00d4ff' ?>" oninput="document.getElementById('pc_text').value=this.value">
                <input type="text" name="primary_color" id="pc_text" value="<?= htmlspecialchars($settings['primary_color'] ?? '#00d4ff') ?>">
              </div>
            </div>
            <div class="form-group">
              <label>اللون الثانوي</label>
              <div class="color-row">
                <input type="color" id="sc" value="<?= $settings['secondary_color'] ?? '#7c3aed' ?>" oninput="document.getElementById('sc_text').value=this.value">
                <input type="text" name="secondary_color" id="sc_text" value="<?= htmlspecialchars($settings['secondary_color'] ?? '#7c3aed') ?>">
              </div>
            </div>
            <div class="form-group">
              <label>لون التمييز</label>
              <div class="color-row">
                <input type="color" id="ac" value="<?= $settings['accent_color'] ?? '#22c55e' ?>" oninput="document.getElementById('ac_text').value=this.value">
                <input type="text" name="accent_color" id="ac_text" value="<?= htmlspecialchars($settings['accent_color'] ?? '#22c55e') ?>">
              </div>
            </div>
            <div class="toggle-label">
              <label class="toggle-switch">
                <input type="checkbox" name="auto_refresh" <?= ($settings['auto_refresh'] ?? 0) ? 'checked' : '' ?>>
                <span class="toggle-slider"></span>
              </label>
              <span>تحديث تلقائي للصفحات</span>
            </div>
            <div class="form-group">
              <label>اسم الشرکة / البراند <small style="color:#64748b;font-weight:400;">يظهر في الفوتر</small></label>
              <input type="text" name="brand_name" value="<?= htmlspecialchars($settings['brand_name'] ?? '') ?>" placeholder="مثال: EL-MAJIKU NET">
            </div>
            <div class="form-group">
              <label>موديل الجهاز <small style="color:#64748b;font-weight:400;">يظهر في معلومات النظام</small></label>
              <input type="text" name="device_model" value="<?= htmlspecialchars($settings['device_model'] ?? '') ?>" placeholder="مثال: Router Pro X1">
            </div>
            <div class="form-group">
              <label>إصدار الفيرمووير <small style="color:#64748b;font-weight:400;">يظهر في معلومات النظام</small></label>
              <input type="text" name="firmware_version" value="<?= htmlspecialchars($settings['firmware_version'] ?? '') ?>" placeholder="مثال: EL-MAJIKU OS 1.0.0">
            </div>
            <button type="submit" name="save_settings" class="btn btn-primary">💾 حفظ الإعدادات</button>
          </form>
        </div>
      </div>

      <!-- Security -->
      <div id="tab-security" class="tab-content">
        <div class="box">
          <h3>🔐 تغيير كلمة المرور</h3>
          <form method="POST">
            <div class="form-group">
              <label>كلمة المرور القديمة</label>
              <input type="password" name="old_password" required placeholder="••••••••">
            </div>
            <div class="form-group">
              <label>كلمة المرور الجديدة</label>
              <input type="password" name="new_password" required placeholder="6 أحرف على الأقل" minlength="6">
            </div>
            <div class="form-group">
              <label>تأكيد كلمة المرور</label>
              <input type="password" name="confirm_password" required placeholder="••••••••">
            </div>
            <button type="submit" name="change_pass" class="btn btn-primary">🔒 تغيير</button>
          </form>
        </div>
        <div class="box">
          <h3>⏱️ إعدادات الجلسة</h3>
          <form method="POST">
            <div class="form-group">
              <label>مدة الجلسة (ثانية)</label>
              <input type="number" name="session_timeout" value="<?= $settings['session_timeout'] ?? 3600 ?>" min="300" max="86400">
              <small style="color:#475569; font-size:0.75rem;">الحد الأدنى 5 دقائق، الحد الأقصى 24 ساعة</small>
            </div>
            <button type="submit" name="save_settings" class="btn btn-primary">💾 حفظ الإعدادات</button>
          </form>
        </div>

        <div class="box">
          <h3>🛡️ الحماية ضد التخمين (Anti-Brute Force)</h3>
          <form method="POST">
            <div class="toggle-label" style="display:flex; align-items:center; gap:10px; margin-bottom:15px;">
              <label class="toggle-switch">
                <input type="checkbox" name="brute_force_enabled" value="1" <?= ($settings['brute_force_enabled'] ?? 1) ? 'checked' : '' ?>>
                <span class="toggle-slider"></span>
              </label>
              <span>تفعيل الحماية من التخمين</span>
            </div>
            <div class="form-group">
              <label>أقصى محاولات خاطئة مسموحة</label>
              <input type="number" name="brute_force_max_attempts" value="<?= $settings['brute_force_max_attempts'] ?? 5 ?>" min="1" max="20" required>
            </div>
            <div class="form-group">
              <label>مدة الحظر (بالدقائق)</label>
              <input type="number" name="brute_force_duration" value="<?= $settings['brute_force_duration'] ?? 15 ?>" min="1" max="1440" required>
            </div>
            <button type="submit" name="save_settings" class="btn btn-primary">💾 حفظ إعدادات الحماية</button>
          </form>
        </div>
      </div>

      <!-- Trial Settings -->
      <div id="tab-trial" class="tab-content">
        <div class="box">
          <h3>⚡ إعدادات التجربة المجانية</h3>
          <form method="POST">
            <div class="toggle-label">
              <label class="toggle-switch">
                <input type="checkbox" name="trial_enabled" <?= ($settings['trial_enabled'] ?? 1) ? 'checked' : '' ?>>
                <span class="toggle-slider"></span>
              </label>
              <span>تفعيل التجربة المجانية</span>
            </div>
            <div class="form-group">
              <label>الداتا المجانية (MB)</label>
              <input type="number" name="trial_mb" value="<?= $settings['trial_mb'] ?? 50 ?>" min="1">
            </div>
            <div class="form-group">
              <label>الوقت المجاني (دقيقة)</label>
              <input type="number" name="trial_min" value="<?= $settings['trial_min'] ?? 10 ?>" min="1">
            </div>
            <button type="submit" name="save_settings" class="btn btn-primary">💾 حفظ</button>
          </form>
        </div>
      </div>

      <!-- System Info -->
      <div id="tab-system" class="tab-content">
        <div class="box">
          <h3>ℹ️ معلومات النظام</h3>
          <div class="info-row"><span>الجهاز / الموديل</span><span><?= htmlspecialchars($sys_info['device']) ?></span></div>
          <div class="info-row"><span>الفيرمووير</span><span><?= htmlspecialchars($sys_info['firmware']) ?></span></div>
          <div class="info-row"><span>نواة النظام</span><span><?= htmlspecialchars($sys_info['kernel']) ?></span></div>
          <div class="info-row"><span>PHP</span><span><?= htmlspecialchars($sys_info['php_version']) ?></span></div>
          <div class="info-row"><span>SQLite</span><span><?= htmlspecialchars($sys_info['sqlite_version']) ?></span></div>
          <div class="info-row"><span>وقت التشغيل</span><span><?= htmlspecialchars($sys_info['uptime']) ?></span></div>
          <div class="info-row"><span>حمل المعالج</span><span><?= htmlspecialchars($sys_info['cpu_load']) ?></span></div>
          <div class="info-row" style="display:block">
            <div style="display:flex;justify-content:space-between"><span>الذاكرة</span><span><?= $sys_info['memory'] ?> / <?= $sys_info['memory_total'] ?> MB</span></div>
            <div class="progress-bar-system"><div class="progress-bar-system-fill" style="width:<?= $sys_info['memory_total'] > 0 ? round((1 - $sys_info['memory']/$sys_info['memory_total'])*100) : 0 ?>%"></div></div>
          </div>
          <div class="info-row" style="display:block">
            <div style="display:flex;justify-content:space-between"><span>التخزين</span><span><?= $sys_info['storage'] ?> / <?= $sys_info['storage_total'] ?> MB</span></div>
            <div class="progress-bar-system"><div class="progress-bar-system-fill" style="width:<?= $sys_info['storage_total'] > 0 ? round((1 - $sys_info['storage']/$sys_info['storage_total'])*100) : 0 ?>%"></div></div>
          </div>
        </div>
        <div class="box">
          <h3>💾 نسخ احتياطي</h3>
          <p style="color:#64748b; font-size:0.85rem; margin-bottom:15px;">قم بتحميل نسخة احتياطية من قاعدة البيانات كاملة.</p>
          <a href="settings.php?backup=1" class="btn btn-success">📥 تحميل نسخة احتياطية</a>
        </div>
      </div>

      <!-- Danger Zone -->
      <div id="tab-danger" class="tab-content">
        <div class="box" style="border-color:rgba(239,68,68,0.2);">
          <h3 style="color:#ef4444;">⚠️ منطقة الخطر</h3>
          <p style="color:#64748b; font-size:0.85rem; margin-bottom:15px;">إعادة تعيين النظام ستمسح جميع الجلسات النشطة وسجلات النظام. لن يتم حذف الكروت.</p>
          <form method="POST" onsubmit="return confirm('هل أنت متأكد؟ لا يمكن التراجع عن هذا الإجراء!')">
            <div class="form-group">
              <label>اكتب RESET للتأكيد</label>
              <input type="text" name="reset_confirm" placeholder="RESET" required pattern="RESET">
            </div>
            <button type="submit" name="reset_system" class="btn btn-danger">🗑️ إعادة تعيين النظام</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function showTab(tabId) {
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + tabId).classList.add('active');
  event.target.classList.add('active');
}
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>