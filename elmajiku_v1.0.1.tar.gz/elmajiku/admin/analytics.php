<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// ===== بيانات التحليل =====

// استهلاك الداتا اليومي (آخر 30 يوم من السجلات)
$data_30 = [];
$labels_30 = [];
for ($i = 29; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $labels_30[] = date('m/d', strtotime("-$i days"));
    $cnt = $db->query("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%login%' AND date(created_at)='$d'")->fetchColumn();
    $data_30[] = (int)$cnt;
}

// توزيع أنواع الكروت حسب الداتا
$ranges = [
    '0–100 MB'   => $db->query("SELECT COUNT(*) FROM cards WHERE total_mb > 0 AND total_mb <= 100")->fetchColumn(),
    '100–500 MB' => $db->query("SELECT COUNT(*) FROM cards WHERE total_mb > 100 AND total_mb <= 500")->fetchColumn(),
    '500–1000 MB'=> $db->query("SELECT COUNT(*) FROM cards WHERE total_mb > 500 AND total_mb <= 1000")->fetchColumn(),
    '1 GB+'      => $db->query("SELECT COUNT(*) FROM cards WHERE total_mb > 1000")->fetchColumn(),
    'بدون حد'   => $db->query("SELECT COUNT(*) FROM cards WHERE total_mb = 0 OR total_mb IS NULL")->fetchColumn(),
];

// ملخص إجمالي
$total_used_mb = $db->query("SELECT COALESCE(SUM(used_mb),0) FROM cards")->fetchColumn();
$total_cards   = $db->query("SELECT COUNT(*) FROM cards")->fetchColumn();
$avg_used      = $total_cards ? round($total_used_mb / $total_cards, 1) : 0;
$total_minutes = $db->query("SELECT COALESCE(SUM(used_minutes),0) FROM cards")->fetchColumn();
$total_sessions= $db->query("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%login%'")->fetchColumn();

// معدل نجاح الاتصالات (تسجيل دخول بدون قطع)
$total_kicks = $db->query("SELECT COUNT(*) FROM card_logs WHERE action LIKE '%kick%'")->fetchColumn();
$success_rate = $total_sessions > 0 ? round((1 - $total_kicks / max($total_sessions, 1)) * 100) : 100;

// الكروت التي اقتربت من نفاد الداتا (90%+)
$critical_cards = $db->query("
    SELECT card_code, used_mb, total_mb, 
           ROUND(used_mb * 100.0 / total_mb) as pct
    FROM cards 
    WHERE total_mb > 0 AND status = 'active' 
      AND (used_mb * 100.0 / total_mb) >= 80
    ORDER BY pct DESC
    LIMIT 10
")->fetchAll();

// الكروت التي اقتربت من نفاد الوقت
$critical_time = $db->query("
    SELECT card_code, used_minutes, total_minutes,
           ROUND(used_minutes * 100.0 / total_minutes) as pct
    FROM cards 
    WHERE total_minutes > 0 AND status='active'
      AND (used_minutes * 100.0 / total_minutes) >= 80
    ORDER BY pct DESC
    LIMIT 10
")->fetchAll();

// الكروت الأكثر استهلاكاً للداتا اليوم (من المتصلين)
$top_today = $db->query("
    SELECT ou.card_code, c.used_mb, c.total_mb,
           CAST((strftime('%s','now') - strftime('%s', ou.login_time)) / 60 AS INTEGER) as dur
    FROM online_users ou
    LEFT JOIN cards c ON c.card_code = ou.card_code
    ORDER BY c.used_mb DESC LIMIT 8
")->fetchAll();

$page_title = 'التحليلات المتقدمة';
$active_page = 'analytics';
$path_prefix = '';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<style>
/* Analytics specific styles */
.kpi-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:14px; margin-bottom:22px; }
.kpi-card {
  background:var(--card-bg); border-radius:16px; padding:20px;
  border:1px solid var(--border); position:relative; overflow:hidden;
  backdrop-filter: blur(10px);
}
.kpi-card::after {
  content:''; position:absolute; bottom:0; left:0; right:0; height:2px;
}
.kpi-card.c1::after { background:linear-gradient(90deg,var(--primary),#0066cc); }
.kpi-card.c2::after { background:linear-gradient(90deg,var(--accent),#34d399); }
.kpi-card.c3::after { background:linear-gradient(90deg,var(--secondary),#a855f7); }
.kpi-card.c4::after { background:linear-gradient(90deg,#f59e0b,#fbbf24); }
.kpi-icon { font-size:1.8rem; margin-bottom:10px; }
.kpi-val { font-size:1.9rem; font-weight:800; margin-bottom:4px; }
.kpi-label { color:var(--text-muted); font-size:0.78rem; }
.kpi-sub { font-size:0.7rem; color:var(--text-muted); margin-top:6px; }
.c1 .kpi-val { color:var(--primary); }
.c2 .kpi-val { color:var(--accent); }
.c3 .kpi-val { color:var(--secondary); }
.c4 .kpi-val { color:#f59e0b; }

.box-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:18px; }
.box-title { font-size:0.95rem; font-weight:700; color:#cbd5e1; }
.box-sub { font-size:0.72rem; color:var(--text-muted); margin-top:2px; }

.charts-row { display:grid; grid-template-columns:2fr 1fr; gap:16px; margin-bottom:22px; }
.bottom-row { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:22px; }
@media (max-width:1000px) {
  .charts-row, .bottom-row { grid-template-columns: 1fr; }
}

.crit-item {
  display:flex; align-items:center; gap:10px;
  padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.03);
}
.crit-item:last-child { border:none; }
.crit-code { font-family:monospace; color:var(--primary); font-weight:700; font-size:0.85rem; flex:1; }
.crit-pct {
  font-size:0.78rem; font-weight:800; padding:3px 9px;
  border-radius:20px;
}
.crit-pct.w, .crit-pct.pct-warn { background:rgba(245,158,11,0.15); color:#f59e0b; }
.crit-pct.d, .crit-pct.pct-danger { background:rgba(239,68,68,0.15); color:#ef4444; }

.mini-bar-wrap { width:60px; background:rgba(255,255,255,0.07); border-radius:10px; height:6px; overflow:hidden; }
.mini-bar { height:6px; border-radius:10px; }
.mini-bar.warn   { background:linear-gradient(90deg,#f59e0b,#fbbf24); }
.mini-bar.danger { background:linear-gradient(90deg,#ef4444,#f97316); }

.dial-wrap { display:flex; justify-content:center; align-items:center; padding:10px; }

.online-row {
  display:flex; align-items:center; gap:10px;
  padding:9px 0; border-bottom:1px solid rgba(255,255,255,0.03);
  font-size:0.8rem;
}
.online-row:last-child { border:none; }
.online-code { font-family:monospace; color:var(--primary); font-weight:700; flex:1; }
.online-dur { color:var(--text-muted); }
</style>

<div class="main">
  <div class="topbar">
    <div>
      <h1>📉 التحليلات المتقدمة</h1>
      <p style="color:var(--muted);font-size:0.82rem;margin-top:3px">نظرة عميقة على أداء الشبكة والاستهلاك</p>
    </div>
  </div>

  <!-- KPI Cards -->
  <div class="kpi-grid">
    <div class="kpi-card c1">
      <div class="kpi-icon">📡</div>
      <div class="kpi-val"><?= number_format($total_used_mb / 1024, 2) ?></div>
      <div class="kpi-label">GB إجمالي البيانات المستهلكة</div>
      <div class="kpi-sub"><?= number_format($total_used_mb) ?> MB</div>
    </div>
    <div class="kpi-card c2">
      <div class="kpi-icon">⏱</div>
      <div class="kpi-val"><?= number_format($total_minutes / 60, 1) ?></div>
      <div class="kpi-label">ساعة إجمالي وقت الاستخدام</div>
      <div class="kpi-sub"><?= number_format($total_minutes) ?> دقيقة</div>
    </div>
    <div class="kpi-card c3">
      <div class="kpi-icon">🔢</div>
      <div class="kpi-val"><?= number_format($total_sessions) ?></div>
      <div class="kpi-label">إجمالي جلسات الاتصال</div>
      <div class="kpi-sub">متوسط <?= round($total_sessions / max(30,1)) ?> / يوم</div>
    </div>
    <div class="kpi-card c4">
      <div class="kpi-icon">📊</div>
      <div class="kpi-val"><?= $avg_used ?></div>
      <div class="kpi-label">MB متوسط استهلاك الكارت</div>
      <div class="kpi-sub">من أصل <?= $total_cards ?> كارت</div>
    </div>
  </div>

  <!-- Main Charts -->
  <div class="charts-row">
    <div class="box">
      <div class="box-header">
        <div>
          <div class="box-title">📅 نشاط الاتصالات – آخر 30 يوم</div>
          <div class="box-sub">عدد تسجيلات الدخول اليومية</div>
        </div>
      </div>
      <div style="height:220px">
        <canvas id="chart30"></canvas>
      </div>
    </div>
    <div class="box">
      <div class="box-header">
        <div class="box-title">🥧 توزيع حجم الكروت</div>
      </div>
      <div style="height:220px;display:flex;align-items:center;justify-content:center">
        <canvas id="donutRange"></canvas>
      </div>
    </div>
  </div>

  <!-- Bottom 3 Cols -->
  <div class="bottom-row">
    <!-- Critical Data -->
    <div class="box">
      <div class="box-header">
        <div class="box-title">⚠️ كروت قاربت على النفاد (داتا)</div>
      </div>
      <?php if ($critical_cards): ?>
        <?php foreach ($critical_cards as $cc): ?>
        <div class="crit-item">
          <div class="crit-code"><?= htmlspecialchars($cc['card_code']) ?></div>
          <div class="mini-bar-wrap">
            <div class="mini-bar <?= $cc['pct']>=90?'danger':'warn' ?>" style="width:<?= min(100,$cc['pct']) ?>%"></div>
          </div>
          <span class="crit-pct <?= $cc['pct']>=90?'pct-danger':'pct-warn' ?>"><?= $cc['pct'] ?>%</span>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p style="color:var(--green);text-align:center;padding:20px;font-size:0.85rem">✅ كل الكروت بخير!</p>
      <?php endif; ?>
    </div>

    <!-- Critical Time -->
    <div class="box">
      <div class="box-header">
        <div class="box-title">⏰ كروت قاربت على النفاد (وقت)</div>
      </div>
      <?php if ($critical_time): ?>
        <?php foreach ($critical_time as $ct): ?>
        <div class="crit-item">
          <div class="crit-code"><?= htmlspecialchars($ct['card_code']) ?></div>
          <div class="mini-bar-wrap">
            <div class="mini-bar <?= $ct['pct']>=90?'danger':'warn' ?>" style="width:<?= min(100,$ct['pct']) ?>%"></div>
          </div>
          <span class="crit-pct <?= $ct['pct']>=90?'pct-danger':'pct-warn' ?>"><?= $ct['pct'] ?>%</span>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p style="color:var(--green);text-align:center;padding:20px;font-size:0.85rem">✅ كل الكروت بخير!</p>
      <?php endif; ?>
    </div>

    <!-- Currently Online -->
    <div class="box">
      <div class="box-header">
        <div class="box-title">🟢 المتصلون الحاليون</div>
      </div>
      <?php if ($top_today): ?>
        <?php foreach ($top_today as $t): ?>
        <?php $dur = $t['dur'] >= 60 ? floor($t['dur']/60).'h '.($t['dur']%60).'m' : $t['dur'].'m'; ?>
        <div class="online-row">
          <span class="online-code"><?= htmlspecialchars($t['card_code']) ?></span>
          <?php if ($t['total_mb']): ?>
            <span style="font-size:0.72rem;color:var(--muted)"><?= $t['used_mb'] ?>/<?= $t['total_mb'] ?> MB</span>
          <?php endif; ?>
          <span class="online-dur"><?= $dur ?></span>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p style="color:var(--muted);text-align:center;padding:20px;font-size:0.85rem">👻 لا يوجد متصلون</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Success Rate -->
  <div class="box">
    <div class="box-header">
      <div class="box-title">📊 معدل نجاح الاتصال</div>
      <div style="font-size:1.5rem;font-weight:800;color:<?= $success_rate>=80?'var(--green)':($success_rate>=60?'var(--yellow)':'var(--red)') ?>"><?= $success_rate ?>%</div>
    </div>
    <div style="background:rgba(255,255,255,0.05);border-radius:20px;height:12px;overflow:hidden">
      <div style="height:12px;border-radius:20px;width:<?= $success_rate ?>%;background:linear-gradient(90deg,<?= $success_rate>=80?'var(--green),#34d399':($success_rate>=60?'var(--yellow),#fbbf24':'var(--red),#f97316') ?>);transition:width 1s ease"></div>
    </div>
    <div style="display:flex;justify-content:space-between;margin-top:10px;font-size:0.78rem;color:var(--muted)">
      <span>🟢 <?= $total_sessions ?> تسجيل دخول</span>
      <span>🔴 <?= $total_kicks ?> قطع اتصال</span>
    </div>
  </div>
</div>

<script>
// 30-day chart
new Chart(document.getElementById('chart30'), {
  type:'line',
  data:{
    labels: <?= json_encode($labels_30) ?>,
    datasets:[{
      data: <?= json_encode($data_30) ?>,
      borderColor:'#00d4ff',
      backgroundColor:'rgba(0,212,255,0.05)',
      borderWidth:2, pointRadius:2, pointHoverRadius:5,
      fill:true, tension:0.4
    }]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{legend:{display:false}},
    scales:{
      x:{ticks:{color:'#64748b',font:{family:'Cairo',size:9},maxRotation:45},grid:{color:'rgba(255,255,255,0.03)'}},
      y:{ticks:{color:'#64748b',font:{family:'Cairo',size:9},stepSize:1},grid:{color:'rgba(255,255,255,0.03)'},beginAtZero:true}
    }
  }
});

// Range donut
new Chart(document.getElementById('donutRange'), {
  type:'doughnut',
  data:{
    labels: <?= json_encode(array_keys($ranges)) ?>,
    datasets:[{
      data: <?= json_encode(array_values($ranges)) ?>,
      backgroundColor:['rgba(0,212,255,0.75)','rgba(16,185,129,0.75)','rgba(124,58,237,0.75)','rgba(245,158,11,0.75)','rgba(100,116,139,0.6)'],
      borderWidth:2, hoverOffset:8
    }]
  },
  options:{
    responsive:true, maintainAspectRatio:false,
    plugins:{
      legend:{position:'bottom',labels:{color:'#94a3b8',font:{family:'Cairo',size:10},padding:10}}
    },
    cutout:'60%'
  }
});
</script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
