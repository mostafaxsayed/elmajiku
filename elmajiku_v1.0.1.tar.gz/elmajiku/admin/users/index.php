<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/iptables.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// AJAX kick
if (isset($_GET['ajax_kick'])) {
    header('Content-Type: application/json');
    $ip = $_GET['ip'] ?? '';
    if ($ip) {
        $user = getOnlineUser($ip);
        if ($user) {
            blockIP($ip);
            removeOnlineUser($ip);
            addLog($user['card_code'], "admin-kick from $ip");
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'msg' => 'المستخدم غير موجود']);
        }
    }
    exit;
}

// قطع مستخدم
if (isset($_GET['kick'])) {
    $ip = $_GET['kick'];
    $user = getOnlineUser($ip);
    if ($user) {
        blockIP($ip);
        removeOnlineUser($ip);
        addLog($user['card_code'], "admin-kick from $ip");
    }
    header('Location: index.php?msg=kicked');
    exit;
}

// قطع الكل
if (isset($_GET['kickall'])) {
    $all = $db->query('SELECT ip_address, card_code FROM online_users')->fetchAll();
    foreach ($all as $u) {
        blockIP($u['ip_address']);
        addLog($u['card_code'], "admin-kickall from {$u['ip_address']}");
    }
    $db->exec('DELETE FROM online_users');
    header('Location: index.php?msg=kickedall');
    exit;
}

$online_users = $db->query('
    SELECT o.*, c.total_mb, c.used_mb, c.total_minutes, c.used_minutes,
           c.download_speed, c.upload_speed,
           CAST((strftime(\'%s\',\'now\') - strftime(\'%s\', o.login_time)) / 60 AS INTEGER) as session_min
    FROM online_users o
    LEFT JOIN cards c ON o.card_code = c.card_code
    ORDER BY o.login_time DESC
')->fetchAll();
$online_count = count($online_users);
?>
<?php
$page_title = 'المستخدمين النشطين';
$active_page = 'users';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
/* Users specific styles */
.summary-row { display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:14px; margin-bottom:22px; }
.sum-card { background:var(--card-bg); border-radius:14px; padding:18px; border:1px solid var(--border); display:flex; align-items:center; gap:14px; backdrop-filter: blur(10px); }
.sum-icon { font-size:2rem; }
.sum-num { font-size:1.8rem; font-weight:800; }
.sum-label { font-size:0.75rem; color:var(--text-muted); }
.sum-card.s1 .sum-num { color:var(--accent); }
.sum-card.s2 .sum-num { color:var(--primary); }
.sum-card.s3 .sum-num { color:var(--secondary); }

.box-header { display:flex; justify-content:space-between; align-items:center; padding:18px 20px; border-bottom:1px solid var(--border); }
.box-title { font-size:0.95rem; font-weight:700; color:#cbd5e1; }
.count-badge { background:rgba(16,185,129,0.1); color:var(--accent); padding:4px 12px; border-radius:20px; font-size:0.8rem; font-weight:700; }

table { width:100%; border-collapse:collapse; font-size:0.82rem; }
th { color:var(--text-muted); padding:11px 14px; text-align:right; border-bottom:1px solid var(--border); font-weight:600; font-size:0.73rem; text-transform:uppercase; background:rgba(255,255,255,0.02); white-space:nowrap; }
td { padding:11px 14px; border-bottom:1px solid rgba(255,255,255,0.03); color:#94a3b8; vertical-align:middle; }
tr:last-child td { border:none; }
tr:hover td { background:rgba(255,255,255,0.025); }

.online-dot { display:inline-block; width:8px; height:8px; background:var(--accent); border-radius:50%; animation:pulse 2s infinite; }
.ip-cell { font-family:monospace; color:var(--primary); font-weight:700; }
.mac-cell { font-family:monospace; font-size:0.74rem; color:var(--text-muted); }
.card-cell { color:var(--secondary); font-weight:700; font-family:monospace; }

.progress-wrap { background:rgba(255,255,255,0.07); border-radius:20px; height:5px; min-width:70px; margin-top:4px; overflow:hidden; }
.progress-bar  { height:5px; border-radius:20px; background:linear-gradient(90deg,var(--primary),var(--secondary)); }
.progress-bar.danger { background:linear-gradient(90deg,#ef4444,#f97316); }

.dur-badge { background:rgba(0,212,255,0.08); color:var(--primary); padding:3px 9px; border-radius:20px; font-size:0.74rem; font-weight:700; }

.empty-state { text-align:center; padding:60px 20px; color:var(--text-muted); }
.empty-icon { font-size:3rem; margin-bottom:16px; opacity:0.3; }

.refresh-count { font-size:0.72rem; color:var(--text-muted); text-align:left; padding:10px 20px; }

.live-badge { display:flex; align-items:center; gap:6px; background:rgba(16,185,129,0.1); border:1px solid rgba(16,185,129,0.2); border-radius:20px; padding:6px 14px; font-size:0.78rem; color:var(--accent); }
.live-dot { width:7px; height:7px; border-radius:50%; background:var(--accent); animation:pulse 1.5s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
</style>
<div class="main">
  <div class="topbar">
    <div>
      <h1>👥 المستخدمون الأونلاين <span class="online-dot"></span></h1>
      <p style="color:var(--muted);font-size:0.82rem;margin-top:3px">يتحدث تلقائياً كل 15 ثانية</p>
    </div>
    <div style="display:flex;gap:10px;align-items:center">
      <div class="live-badge"><span class="live-dot"></span> مباشر</div>
      <?php if ($online_users): ?>
      <a href="index.php?kickall=1" class="btn btn-danger"
         onclick="return confirm('قطع كل المستخدمين؟')">⚡ قطع الكل</a>
      <?php endif; ?>
    </div>
  </div>

  <?php if (isset($_GET['msg'])): ?>
  <div class="alert success">
    ✅ <?= $_GET['msg']==='kicked' ? 'تم قطع المستخدم بنجاح' : 'تم قطع جميع المستخدمين' ?>
  </div>
  <?php endif; ?>

  <!-- Summary -->
  <?php
    $total_mb_online = array_sum(array_column($online_users, 'used_mb'));
    $max_dur = $online_users ? max(array_column($online_users, 'session_min')) : 0;
  ?>
  <div class="summary-row">
    <div class="sum-card s1">
      <div class="sum-icon">🟢</div>
      <div>
        <div class="sum-num"><?= $online_count ?></div>
        <div class="sum-label">مستخدم متصل الآن</div>
      </div>
    </div>
    <div class="sum-card s2">
      <div class="sum-icon">📡</div>
      <div>
        <div class="sum-num"><?= number_format($total_mb_online) ?></div>
        <div class="sum-label">MB إجمالي الاستهلاك المتصلين</div>
      </div>
    </div>
    <div class="sum-card s3">
      <div class="sum-icon">⏱</div>
      <div>
        <div class="sum-num"><?= $max_dur >= 60 ? floor($max_dur/60).'h' : $max_dur.'m' ?></div>
        <div class="sum-label">أطول جلسة اتصال الآن</div>
      </div>
    </div>
  </div>

  <!-- Table -->
  <div class="box">
    <div class="box-header">
      <div class="box-title">المتصلون الآن</div>
      <span class="count-badge" id="count-badge"><?= $online_count ?> متصل</span>
    </div>

    <div id="users-table">
    <?php if ($online_users): ?>
    <table>
      <tr>
        <th>الحالة</th>
        <th>IP</th>
        <th>MAC</th>
        <th>الجهاز</th>
        <th>الكارت</th>
        <th>الداتا</th>
        <th>الوقت</th>
        <th>السرعة</th>
        <th>مدة الجلسة</th>
        <th>إجراء</th>
      </tr>
      <?php foreach ($online_users as $u): ?>
      <?php
        $mb_pct  = ($u['total_mb']      > 0) ? min(100, round($u['used_mb']      / $u['total_mb']      * 100)) : 0;
        $min_pct = ($u['total_minutes'] > 0) ? min(100, round($u['used_minutes'] / $u['total_minutes'] * 100)) : 0;
        $sm = (int)$u['session_min'];
        $dur_str = $sm >= 60 ? floor($sm/60).'h '.($sm%60).'m' : $sm.'m';
      ?>
      <tr id="row-<?= md5($u['ip_address']) ?>">
        <td><span class="online-dot"></span> أونلاين</td>
        <td><span class="ip-cell"><?= htmlspecialchars($u['ip_address']) ?></span></td>
        <td><span class="mac-cell"><?= htmlspecialchars($u['mac_address'] ?? '–') ?></span></td>
        <td><?= htmlspecialchars($u['device_name'] ?? '–') ?></td>
        <td><span class="card-cell"><?= htmlspecialchars($u['card_code']) ?></span></td>
        <td>
          <?php if ($u['total_mb'] > 0): ?>
            <div style="font-size:0.74rem;color:<?= $mb_pct>=80?'var(--red)':'var(--muted)' ?>;margin-bottom:3px">
              <?= $u['used_mb'] ?>/<?= $u['total_mb'] ?> MB
            </div>
            <div class="progress-wrap"><div class="progress-bar <?= $mb_pct>=80?'danger':'' ?>" style="width:<?= $mb_pct ?>%"></div></div>
          <?php else: ?>
            <span style="color:var(--muted)">∞</span>
          <?php endif; ?>
        </td>
        <td>
          <?php if ($u['total_minutes'] > 0): ?>
            <div style="font-size:0.74rem;color:var(--muted);margin-bottom:3px"><?= $u['used_minutes'] ?>/<?= $u['total_minutes'] ?>د</div>
            <div class="progress-wrap"><div class="progress-bar <?= $min_pct>=80?'danger':'' ?>" style="width:<?= $min_pct ?>%"></div></div>
          <?php else: ?>
            <span style="color:var(--muted)">∞</span>
          <?php endif; ?>
        </td>
        <td style="font-size:0.78rem">
          ⬇ <?= $u['download_speed'] ?: '∞' ?><br>
          <span style="color:var(--muted)">⬆ <?= $u['upload_speed'] ?: '∞' ?></span>
        </td>
        <td><span class="dur-badge"><?= $dur_str ?></span></td>
        <td>
          <button class="btn btn-danger btn-sm"
            onclick="kickUser('<?= htmlspecialchars($u['ip_address']) ?>', '<?= md5($u['ip_address']) ?>')">
            ✂️ قطع
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php else: ?>
    <div class="empty-state">
      <div class="empty-icon">👻</div>
      <p>لا يوجد مستخدمون متصلون الآن</p>
    </div>
    <?php endif; ?>
    </div>
    <div class="refresh-count" id="refresh-info">آخر تحديث: الآن</div>
  </div>
</div>

<script>
function kickUser(ip, rowId) {
  if (!confirm('قطع اتصال ' + ip + '؟')) return;
  fetch('index.php?ajax_kick=1&ip=' + encodeURIComponent(ip))
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        const row = document.getElementById('row-' + rowId);
        if (row) {
          row.style.transition = 'opacity 0.4s';
          row.style.opacity = '0';
          setTimeout(() => { row.remove(); updateCount(); }, 400);
        }
      }
    });
}

function updateCount() {
  const rows = document.querySelectorAll('#users-table table tr:not(:first-child)');
  const cnt = rows.length;
  document.getElementById('count-badge').textContent = cnt + ' متصل';
}

// Auto refresh info
setInterval(() => {
  const now = new Date();
  document.getElementById('refresh-info').textContent = 'آخر تحديث: ' + now.toLocaleTimeString('ar-SA');
}, 15000);
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
