<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$msg = '';

// قائمة التطبيقات المدعومة
$supported_apps = ['tiktok', 'youtube', 'facebook', 'whatsapp', 'twitter', 'snapchat', 'telegram', 'games'];

// معالجة حفظ إعدادات الفلترة والحظر
if (isset($_POST['save_filtering'])) {
    $dns_mode = intval($_POST['dns_filter_mode'] ?? 0);
    
    // جمع قيم حظر التطبيقات ديناميكياً
    $app_vals = [];
    foreach ($supported_apps as $app) {
        $app_vals["block_$app"] = isset($_POST["block_$app"]) ? 1 : 0;
    }

    try {
        // بناء جملة UPDATE ديناميكية
        $set_parts = ['dns_filter_mode = ?'];
        $params    = [$dns_mode];
        foreach ($app_vals as $col => $val) {
            $set_parts[] = "$col = ?";
            $params[]    = $val;
        }
        $sql = 'UPDATE settings SET ' . implode(', ', $set_parts) . ' WHERE id = (SELECT id FROM settings LIMIT 1)';
        $db->prepare($sql)->execute($params);

        // تطبيق الإعدادات حياً على الراوتر وجدار الحماية ونظام DNS
        require_once __DIR__ . '/includes/iptables.php';
        applyNetworkFiltering($dns_mode, $app_vals);

        reloadSettings();
        $settings = getSettings();
        
        $msg = ['type' => 'success', 'text' => 'تم تطبيق وحفظ إعدادات الفلترة بنجاح على الشبكة والراوتر!'];
    } catch (Exception $e) {
        $msg = ['type' => 'error', 'text' => 'حدث خطأ أثناء حفظ الإعدادات: ' . $e->getMessage()];
    }
}

$page_title = 'الفلترة والحظر للشبكة';
$active_page = 'filtering';
$path_prefix = '';

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<style>
.filter-card {
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 24px;
  margin-bottom: 24px;
  transition: all 0.3s ease;
}
.filter-card:hover {
  background: rgba(255, 255, 255, 0.03);
  border-color: rgba(0, 212, 255, 0.15);
}
.filter-header {
  display: flex;
  align-items: center;
  gap: 15px;
  margin-bottom: 20px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
  padding-bottom: 12px;
}
.filter-header .icon-wrap {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background: rgba(0, 212, 255, 0.1);
  color: var(--primary);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
}
.filter-header h3 {
  font-size: 1.1rem;
  font-weight: 800;
  color: #fff;
}
.option-select-box {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 15px;
}
.option-item {
  background: rgba(255, 255, 255, 0.01);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  gap: 15px;
  cursor: pointer;
  transition: all 0.2s;
}
.option-item:hover {
  background: rgba(255, 255, 255, 0.03);
  border-color: rgba(255, 255, 255, 0.15);
}
.option-item.selected {
  background: rgba(0, 212, 255, 0.05);
  border-color: var(--primary);
}
.option-item input[type="radio"] {
  display: none;
}
.option-item .radio-dot {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 2px solid #475569;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
  flex-shrink: 0;
}
.option-item.selected .radio-dot {
  border-color: var(--primary);
}
.option-item .radio-dot::after {
  content: '';
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--primary);
  display: none;
}
.option-item.selected .radio-dot::after {
  display: block;
}
.option-details {
  display: flex;
  flex-direction: column;
  text-align: right;
  gap: 4px;
}
.option-title {
  font-weight: 700;
  font-size: 0.95rem;
  color: #fff;
}
.option-desc {
  font-size: 0.78rem;
  color: var(--text-muted);
  line-height: 1.4;
}
.app-block-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
  margin-top: 15px;
}
.app-item {
  background: rgba(255, 255, 255, 0.01);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  transition: all 0.25s;
}
.app-item:hover {
  background: rgba(255, 255, 255, 0.03);
  border-color: rgba(255, 255, 255, 0.15);
}
.app-item-details {
  display: flex;
  align-items: center;
  gap: 12px;
}
.app-icon {
  font-size: 1.8rem;
}
.app-name {
  font-weight: 700;
  font-size: 0.9rem;
  color: #fff;
}
.app-status-text {
  font-size: 0.72rem;
  margin-top: 2px;
}
</style>

<div class="main">
  <div class="topbar">
    <h1>🛡️ إدارة الفلترة والحظر للشبكة</h1>
  </div>

  <?php if ($msg): ?>
    <div class="alert <?= $msg['type'] ?>"><?= htmlspecialchars($msg['text']) ?></div>
  <?php endif; ?>

  <form method="POST" autocomplete="off">
    <div class="grid2">
      <!-- 1. فلترة المواقع وحماية العائلات (DNS Blocking) -->
      <div>
        <div class="filter-card">
          <div class="filter-header">
            <div class="icon-wrap">🌐</div>
            <div>
              <h3>فلترة تصفح الويب (DNS Filter)</h3>
              <p style="color:var(--text-muted); font-size:0.75rem; margin-top:2px;">اختر خادم الـ DNS المناسب لحماية عائلتك والمشتركين بالشبكة</p>
            </div>
          </div>

          <div class="option-select-box">
            <!-- بدون فلترة -->
            <label class="option-item <?= ($settings['dns_filter_mode'] ?? 0) == 0 ? 'selected' : '' ?>" onclick="selectRadio(this, 'dns_none')">
              <input type="radio" name="dns_filter_mode" id="dns_none" value="0" <?= ($settings['dns_filter_mode'] ?? 0) == 0 ? 'checked' : '' ?>>
              <div class="radio-dot"></div>
              <div class="option-details">
                <span class="option-title">تصفح بدون فلترة (Default)</span>
                <span class="option-desc">استخدام الـ DNS التلقائي للشبكة والمزود بالخدمة دون اعتراض.</span>
              </div>
            </label>

            <!-- حظر الإعلانات والبرمجيات الضارة -->
            <label class="option-item <?= ($settings['dns_filter_mode'] ?? 0) == 1 ? 'selected' : '' ?>" onclick="selectRadio(this, 'dns_adguard')">
              <input type="radio" name="dns_filter_mode" id="dns_adguard" value="1" <?= ($settings['dns_filter_mode'] ?? 0) == 1 ? 'checked' : '' ?>>
              <div class="radio-dot"></div>
              <div class="option-details">
                <span class="option-title">🚫 حظر الإعلانات والبرمجيات الضارة (Adguard DNS)</span>
                <span class="option-desc">يقوم بحظر إعلانات الويب المزعجة، النوافذ المنبثقة، ومواقع التصيد والبرمجيات الخبيثة تلقائياً على كل الأجهزة.</span>
              </div>
            </label>

            <!-- فلترة عائلية -->
            <label class="option-item <?= ($settings['dns_filter_mode'] ?? 0) == 2 ? 'selected' : '' ?>" onclick="selectRadio(this, 'dns_family')">
              <input type="radio" name="dns_filter_mode" id="dns_family" value="2" <?= ($settings['dns_filter_mode'] ?? 0) == 2 ? 'checked' : '' ?>>
              <div class="radio-dot"></div>
              <div class="option-details">
                <span class="option-title">🔞 الحماية العائلية وحجب المواقع الإباحية (Adguard Family)</span>
                <span class="option-desc">حظر شامل للمواقع الإباحية والمحتوى غير اللائق والمواقع الضارة، مع تفعيل خاصية البحث الآمن (Safe Search) في جوجل ويوتيوب.</span>
              </div>
            </label>
          </div>
        </div>
      </div>

      <!-- 2. حظر برامج معينة (App Blocking) -->
      <div>
        <div class="filter-card">
          <div class="filter-header">
            <div class="icon-wrap">📱</div>
            <div>
              <h3>حظر وتحديد التطبيقات (App Blocking)</h3>
              <p style="color:var(--text-muted); font-size:0.75rem; margin-top:2px;">تعطيل تطبيقات محددة بالكامل على الشبكة بضغطة زر</p>
            </div>
          </div>

          <div class="app-block-grid">

            <!-- تيك توك -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">🎵</span>
                <div>
                  <span class="app-name">تيك توك (TikTok)</span>
                  <div class="app-status-text" id="status-tiktok" style="color: <?= ($settings['block_tiktok'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_tiktok'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_tiktok" id="block_tiktok" value="1" <?= ($settings['block_tiktok'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-tiktok')">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <!-- يوتيوب -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">📺</span>
                <div>
                  <span class="app-name">يوتيوب (YouTube)</span>
                  <div class="app-status-text" id="status-youtube" style="color: <?= ($settings['block_youtube'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_youtube'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_youtube" id="block_youtube" value="1" <?= ($settings['block_youtube'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-youtube')">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <!-- فيسبوك وإنستغرام -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">👥</span>
                <div>
                  <span class="app-name">فيسبوك وإنستغرام (FB & IG)</span>
                  <div class="app-status-text" id="status-facebook" style="color: <?= ($settings['block_facebook'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_facebook'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_facebook" id="block_facebook" value="1" <?= ($settings['block_facebook'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-facebook')">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <!-- واتساب -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">💬</span>
                <div>
                  <span class="app-name">واتساب (WhatsApp)</span>
                  <div class="app-status-text" id="status-whatsapp" style="color: <?= ($settings['block_whatsapp'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_whatsapp'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_whatsapp" id="block_whatsapp" value="1" <?= ($settings['block_whatsapp'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-whatsapp')">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <!-- تويتر / X -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">🐦</span>
                <div>
                  <span class="app-name">تويتر / X (Twitter)</span>
                  <div class="app-status-text" id="status-twitter" style="color: <?= ($settings['block_twitter'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_twitter'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_twitter" id="block_twitter" value="1" <?= ($settings['block_twitter'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-twitter')">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <!-- سناب شات -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">👻</span>
                <div>
                  <span class="app-name">سناب شات (Snapchat)</span>
                  <div class="app-status-text" id="status-snapchat" style="color: <?= ($settings['block_snapchat'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_snapchat'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_snapchat" id="block_snapchat" value="1" <?= ($settings['block_snapchat'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-snapchat')">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <!-- تيليغرام -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">✈️</span>
                <div>
                  <span class="app-name">تيليغرام (Telegram)</span>
                  <div class="app-status-text" id="status-telegram" style="color: <?= ($settings['block_telegram'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_telegram'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_telegram" id="block_telegram" value="1" <?= ($settings['block_telegram'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-telegram')">
                <span class="toggle-slider"></span>
              </label>
            </div>

            <!-- الألعاب الأونلاين -->
            <div class="app-item">
              <div class="app-item-details">
                <span class="app-icon">🎮</span>
                <div>
                  <span class="app-name">الألعاب الأونلاين (Games)</span>
                  <div class="app-status-text" id="status-games" style="color: <?= ($settings['block_games'] ?? 0) ? 'var(--danger)' : 'var(--success)' ?>">
                    <?= ($settings['block_games'] ?? 0) ? '⚠️ محظور حالياً' : '🟢 مسموح' ?>
                  </div>
                </div>
              </div>
              <label class="toggle-switch">
                <input type="checkbox" name="block_games" id="block_games" value="1" <?= ($settings['block_games'] ?? 0) ? 'checked' : '' ?> onchange="updateAppStatus(this, 'status-games')">
                <span class="toggle-slider"></span>
              </label>
            </div>

          </div><!-- end app-block-grid -->
        </div>

        <div class="box" style="margin-top:24px; background:rgba(0, 212, 255, 0.02); border-color:rgba(0, 212, 255, 0.1);">
          <h4 style="font-weight:700; color:#fff; display:flex; align-items:center; gap:8px; margin-bottom:8px;">💡 معلومات هامة:</h4>
          <p style="font-size:0.78rem; color:var(--text-muted); line-height:1.5;">
            * نظام الحجب يعمل بواسطة <strong>توجيه الـ DNS الإجباري (DNS DNAT Redirect)</strong> في جدار حماية الراوتر، وبالتالي سيتم إجبار الأجهزة المتصلة على تطبيق الحجب حتى لو قام المستخدم بتغيير خوادم الـ DNS يدوياً.
          </p>
          <p style="font-size:0.78rem; color:var(--text-muted); line-height:1.5; margin-top:6px;">
            * عند تفعيل أو تعطيل أي خيار، قد يحتاج هاتف المشترك لـ <strong>دقيقتين</strong> أو إعادة تشغيل الواي فاي لتهيئة وتفريغ كاش الـ DNS في الهاتف ليرى الحجب الجديد.
          </p>
        </div>

        <div style="margin-top:24px; text-align:left;">
          <button type="submit" name="save_filtering" class="btn btn-primary" style="padding:14px 28px; font-size:0.92rem;">🛡️ تطبيق وحفظ التغييرات</button>
        </div>
      </div>
    </div>
  </form>
</div>


<script>
function selectRadio(element, radioId) {
  // إزالة التحديد عن كل الخيارات
  document.querySelectorAll('.option-item').forEach(el => el.classList.remove('selected'));
  // تحديد العنصر المختار
  element.classList.add('selected');
  // تفعيل زر الراديو المقابل
  const radio = document.getElementById(radioId);
  if (radio) radio.checked = true;
}

function updateAppStatus(checkbox, statusId) {
  const statusEl = document.getElementById(statusId);
  if (statusEl) {
    if (checkbox.checked) {
      statusEl.innerText = '⚠️ محظور حالياً بالكامل';
      statusEl.style.color = 'var(--danger)';
    } else {
      statusEl.innerText = '🟢 مسموح به ونشط';
      statusEl.style.color = 'var(--success)';
    }
  }
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
