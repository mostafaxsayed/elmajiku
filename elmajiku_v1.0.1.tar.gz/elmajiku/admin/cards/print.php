<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// فلترة الطباعة
$where = '1=1'; $params = [];
$status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';
$ids    = $_GET['ids']    ?? '';
$group_id = $_GET['group_id'] ?? '';

if ($ids) {
    $id_list = array_map('intval', explode(',', $ids));
    $placeholders = implode(',', $id_list);
    $where .= " AND id IN ($placeholders)";
} elseif ($group_id) {
    $where .= " AND group_id = ?";
    $params[] = intval($group_id);
} else {
    if ($status) { $where .= ' AND status=?'; $params[] = $status; }
    if ($search)  { $where .= ' AND card_code LIKE ?'; $params[] = '%'.$search.'%'; }
}

$stmt = $db->prepare("SELECT * FROM cards WHERE $where ORDER BY created_at DESC");
$stmt->execute($params);
$cards = $stmt->fetchAll();
$site      = htmlspecialchars(!empty($settings['brand_name']) ? $settings['brand_name'] : $settings['site_name']);
$login_url = 'http://192.168.77.1/elmajiku/index.php';?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>طباعة الكروت – <?= $site ?></title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@600;700;800&display=swap');
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Cairo',sans-serif; background:#f0f4f8; padding:20px; }

.no-print {
  background:#1a1a2e; color:#fff; padding:14px 20px;
  border-radius:12px; margin-bottom:20px;
  display:flex; align-items:center; justify-content:space-between;
}
.no-print h3 { font-size:0.95rem; }
.no-print span { font-size:0.82rem; opacity:0.6; }
.print-btn {
  background:linear-gradient(135deg,#00d4ff,#7c3aed); color:#fff;
  border:none; padding:10px 22px; border-radius:8px;
  cursor:pointer; font-family:'Cairo',sans-serif; font-size:0.9rem; font-weight:700;
}

.cards-grid {
  display:grid; grid-template-columns:repeat(3, 1fr); gap:14px;
}

.card {
  background:#fff; border-radius:14px;
  padding:16px; border:2px solid #e2e8f0;
  page-break-inside:avoid; position:relative; overflow:hidden;
}
.card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:4px;
  background:linear-gradient(90deg,#00d4ff,#7c3aed);
}
.card-header {
  display:flex; justify-content:space-between; align-items:flex-start;
  margin-bottom:12px; padding-top:4px;
}
.site-name { font-size:0.7rem; font-weight:700; color:#7c3aed; letter-spacing:1px; text-transform:uppercase; }
.card-type { font-size:0.65rem; color:#94a3b8; background:#f1f5f9; padding:2px 7px; border-radius:10px; }

.card-code {
  text-align:center; font-size:1.5rem; font-weight:800; letter-spacing:2px;
  color:#0f172a; background:#f8fafc; border-radius:10px; padding:10px;
  border:1px dashed #cbd5e1; margin-bottom:10px; font-family:monospace;
}

/* ─── تخطيط QR Code مربع ممركز ─── */
.card-scan-row {
  display:flex; align-items:center; justify-content:center;
  margin-bottom:12px;
}
.qr-wrap {
  width:105px; height:105px;
  padding:5px; background:#fff;
  border:1.5px solid #cbd5e1; border-radius:8px;
  display:flex; align-items:center; justify-content:center;
}
.qr-wrap img {
  width:95px !important; height:95px !important;
  image-rendering:pixelated;
  display:block;
}

.card-details { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:12px; }
.detail-item { text-align:center; }
.detail-val { font-size:0.88rem; font-weight:800; color:#0f172a; }
.detail-key { font-size:0.62rem; color:#94a3b8; margin-top:1px; }

.card-footer {
  border-top:1px dashed #e2e8f0; padding-top:8px;
  text-align:center; font-size:0.6rem; color:#94a3b8;
}
.card-footer .url { font-size:0.65rem; color:#7c3aed; font-weight:700; }
.qr-hint { font-size:0.55rem; color:#94a3b8; margin-top:3px; }

@media print {
  body { background:#fff; padding:0; }
  .no-print { display:none !important; }
  .cards-grid { gap:8px; }
  .card { border:1.5px solid #cbd5e1; }
}
</style>
<script src="../../assets/js/qrcode.min.js"></script>
</head>
<body>

<div class="no-print">
  <div>
    <h3>🖨️ طباعة <?= count($cards) ?> كارت</h3>
    <span>استخدم Ctrl+P أو اضغط الزر للطباعة</span>
  </div>
  <button class="print-btn" onclick="window.print()">🖨️ طباعة الآن</button>
</div>

<div class="cards-grid">
<?php foreach ($cards as $c): ?>
<?php
  $data_label = $c['total_mb'] ? $c['total_mb'].' MB' : '∞ غير محدود';
  $time_label = $c['total_minutes'] ? ($c['total_minutes'].' دقيقة') : '∞ غير محدود';
  $speed_label= ($c['download_speed'] && $c['upload_speed'])
      ? '⬇'.$c['download_speed'].' / ⬆'.$c['upload_speed'].' Kbps'
      : 'غير محدود';
  $exp_label  = $c['expire_date'] ? date('Y/m/d', strtotime($c['expire_date'])) : '–';
?>
<div class="card">
  <div class="card-header">
    <div class="site-name"><?= $site ?></div>
    <div class="card-type">WiFi Card</div>
  </div>

  <div class="card-code"><?= htmlspecialchars($c['card_code']) ?></div>

  <!-- QR Code مربع ممركز -->
  <div class="card-scan-row">
    <div class="qr-wrap" id="qr-<?= htmlspecialchars($c['card_code']) ?>"></div>
  </div>

  <div class="card-details">
    <div class="detail-item">
      <div class="detail-val"><?= $data_label ?></div>
      <div class="detail-key">📡 الداتا</div>
    </div>
    <div class="detail-item">
      <div class="detail-val"><?= $time_label ?></div>
      <div class="detail-key">⏱ الوقت</div>
    </div>
    <?php if ($c['download_speed'] || $c['upload_speed']): ?>
    <div class="detail-item" style="grid-column:span 2">
      <div class="detail-val" style="font-size:0.78rem"><?= $speed_label ?></div>
      <div class="detail-key">⚡ السرعة</div>
    </div>
    <?php endif; ?>
    <?php if ($c['expire_date']): ?>
    <div class="detail-item" style="grid-column:span 2">
      <div class="detail-val" style="font-size:0.82rem"><?= $exp_label ?></div>
      <div class="detail-key">📅 تاريخ الانتهاء</div>
    </div>
    <?php endif; ?>
  </div>

  <div class="card-footer">
    <div>للاتصال: افتح المتصفح أو امسح الـ QR</div>
    <div class="url"><?= $login_url ?></div>
    <div class="qr-hint">📷 امسح الـ QR بـ laksa19.github.io/myqr</div>
  </div>
</div>
<?php endforeach; ?>
</div>

<script>
// توليد QR Code مربع لكل كارت — المحتوى هو رابط تسجيل الدخول المباشر
document.addEventListener('DOMContentLoaded', function() {
  var cards = document.querySelectorAll('[id^="qr-"]');
  cards.forEach(function(wrap) {
    var code = wrap.id.replace('qr-', '');
    var url  = '<?= $login_url ?>?code=' + encodeURIComponent(code);
    try {
      var qr = qrcode(0, 'M'); // 0 = auto version, M = medium correction
      qr.addData(url);
      qr.make();
      // إنشاء صورة QR Code بمقياس 3 ومارجن 0 ليكون مناسباً لـ 95px
      wrap.innerHTML = qr.createImgTag(3, 0);
      var img = wrap.querySelector('img');
      if (img) {
        img.style.cssText = 'width:95px;height:95px;image-rendering:pixelated;display:block;';
      }
    } catch(e) {
      wrap.innerHTML = '<div style="font-size:0.5rem;color:#94a3b8;text-align:center">QR</div>';
    }
  });
});
</script>
</body>
</html>
