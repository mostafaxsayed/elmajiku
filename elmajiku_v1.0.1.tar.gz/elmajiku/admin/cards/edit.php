<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$error = '';

$id = intval($_GET['id'] ?? 0);
$card = $db->prepare('SELECT * FROM cards WHERE id = ?');
$card->execute([$id]);
$card = $card->fetch();
if (!$card) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $total_mb  = intval($_POST['total_mb'])      ?: null;
    $total_min = intval($_POST['total_minutes']) ?: null;
    $dl_speed  = intval($_POST['download_speed'])?: null;
    $ul_speed  = intval($_POST['upload_speed'])  ?: null;
    $max_dev   = intval($_POST['max_devices'])   ?: 1;
    $bind_mac  = isset($_POST['bind_mac']) ? 1 : 0;
    $expire    = !empty($_POST['expire_date']) ? $_POST['expire_date'] : null;
    $status    = $_POST['status'] ?? 'active';
    $used_mb   = intval($_POST['used_mb']);
    $used_min  = intval($_POST['used_minutes']);
    $price     = floatval($_POST['price'] ?? 0.0);

    $stmt = $db->prepare('
        UPDATE cards SET
          total_mb=?, used_mb=?, total_minutes=?, used_minutes=?,
          download_speed=?, upload_speed=?, max_devices=?,
          bind_mac=?, expire_date=?, price=?, status=?
        WHERE id=?
    ');
    $stmt->execute([$total_mb,$used_mb,$total_min,$used_min,
                    $dl_speed,$ul_speed,$max_dev,$bind_mac,$expire,$price,$status,$id]);
    header('Location: index.php?msg=saved');
    exit;
}

$page_title = 'تعديل كارت';
$active_page = 'cards';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
.edit-form { max-width:660px; }
.form-group { margin-bottom:16px; }
.form-group label { display:block; color:#94a3b8; font-size:0.82rem; margin-bottom:7px; font-weight:600; }
.form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.hint { font-size:0.72rem; color:var(--text-muted); margin-top:5px; }
.section-title {
  color:var(--text-muted); font-size:0.72rem; text-transform:uppercase;
  letter-spacing:1.5px; margin:22px 0 14px;
  padding-bottom:8px; border-bottom:1px solid var(--border);
  font-weight:700;
}
.card-code-header {
  font-family:monospace; font-size:1.2rem; color:var(--primary);
  letter-spacing:3px; margin-bottom:22px;
  padding:14px 18px;
  background:rgba(0,212,255,0.06);
  border:1px solid rgba(0,212,255,0.12);
  border-radius:12px;
  display:flex; align-items:center; gap:10px;
}
.checkbox-label {
  display:flex; align-items:center; gap:10px;
  cursor:pointer; font-size:0.88rem; color:#cbd5e1;
}
.checkbox-label input[type=checkbox] {
  width:18px; height:18px; cursor:pointer;
  accent-color:var(--primary);
}
.form-actions { display:flex; gap:12px; margin-top:20px; }
</style>

<div class="main">
  <div class="topbar">
    <div>
      <h1>✏️ تعديل كارت</h1>
      <p style="color:var(--text-muted);font-size:0.82rem;margin-top:3px">تعديل بيانات وإعدادات الكارت</p>
    </div>
    <a href="index.php" class="btn btn-secondary">← رجوع للكروت</a>
  </div>

  <div class="box edit-form">
    <div class="card-code-header">
      🎫 <?= htmlspecialchars($card['card_code']) ?>
    </div>

    <form method="POST">

      <div class="section-title">📊 حدود الاستهلاك</div>
      <div class="form-row-2">
        <div class="form-group">
          <label>الداتا الكلية (MB)</label>
          <input type="number" name="total_mb" value="<?= $card['total_mb'] ?>" placeholder="0 = لانهائي" min="0">
        </div>
        <div class="form-group">
          <label>الداتا المستخدمة (MB)</label>
          <input type="number" name="used_mb" value="<?= $card['used_mb'] ?>" min="0">
        </div>
      </div>

      <div class="form-row-2">
        <div class="form-group">
          <label>الوقت الكلي (دقيقة)</label>
          <input type="number" name="total_minutes" value="<?= $card['total_minutes'] ?>" placeholder="0 = لانهائي" min="0">
        </div>
        <div class="form-group">
          <label>الوقت المستخدم (دقيقة)</label>
          <input type="number" name="used_minutes" value="<?= $card['used_minutes'] ?>" min="0">
        </div>
      </div>

      <div class="section-title">🚀 السرعة</div>
      <div class="form-row-2">
        <div class="form-group">
          <label>⬇️ سرعة التحميل (Kbps)</label>
          <input type="number" name="download_speed" value="<?= $card['download_speed'] ?>" placeholder="0 = بدون حد">
        </div>
        <div class="form-group">
          <label>⬆️ سرعة الرفع (Kbps)</label>
          <input type="number" name="upload_speed" value="<?= $card['upload_speed'] ?>" placeholder="0 = بدون حد">
        </div>
      </div>

      <div class="section-title">⚙️ الإعدادات</div>
      <div class="form-row-2">
        <div class="form-group">
          <label>📱 عدد الأجهزة</label>
          <input type="number" name="max_devices" value="<?= $card['max_devices'] ?>" min="1">
        </div>
        <div class="form-group">
          <label>💰 سعر الكارت (بالجنيه)</label>
          <input type="number" step="0.1" name="price" value="<?= htmlspecialchars($card['price'] ?? 0.0) ?>" required>
        </div>
      </div>

      <div class="form-row-2">
        <div class="form-group">
          <label>🗓️ تاريخ الانتهاء</label>
          <input type="datetime-local" name="expire_date"
                 value="<?= $card['expire_date'] ? date('Y-m-d\TH:i', strtotime($card['expire_date'])) : '' ?>">
          <div class="hint">اتركه فارغاً = لا ينتهي</div>
        </div>
        <div class="form-group">
          <label>🔘 الحالة</label>
          <select name="status">
            <option value="active"   <?= $card['status']==='active'  ?'selected':'' ?>>✅ نشط</option>
            <option value="expired"  <?= $card['status']==='expired' ?'selected':'' ?>>⏰ منتهي</option>
            <option value="disabled" <?= $card['status']==='disabled'?'selected':'' ?>>⛔ معطل</option>
          </select>
        </div>
      </div>

      <div class="form-group" style="margin-top:8px;">
        <label class="checkbox-label">
          <input type="checkbox" name="bind_mac" id="bind_mac" <?= $card['bind_mac']?'checked':'' ?>>
          🔒 ربط الكارت بعنوان MAC الجهاز الأول
        </label>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">💾 حفظ التعديلات</button>
        <a href="index.php" class="btn btn-secondary">إلغاء</a>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
