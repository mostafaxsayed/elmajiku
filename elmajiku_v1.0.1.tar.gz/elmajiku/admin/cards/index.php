<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();

// حذف كارت
if (isset($_GET['delete'])) {
    $db->prepare('DELETE FROM cards WHERE id = ?')->execute([$_GET['delete']]);
    header('Location: index.php?msg=deleted');
    exit;
}

// تعطيل/تفعيل كارت
if (isset($_GET['toggle'])) {
    $card = $db->prepare('SELECT status FROM cards WHERE id = ?');
    $card->execute([$_GET['toggle']]);
    $status = $card->fetchColumn();
    $new_status = ($status === 'active') ? 'disabled' : 'active';
    $db->prepare('UPDATE cards SET status = ? WHERE id = ?')->execute([$new_status, $_GET['toggle']]);
    header('Location: index.php?msg=toggled');
    exit;
}

// تصدير الكروت
if (isset($_GET['export'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=cards_' . date('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($output, ['كود الكارت', 'السعر', 'الداتا الكلية (MB)', 'الداتا المستخدمة (MB)', 'الوقت الكلي (د)', 'الوقت المستخدم (د)', 'سرعة التحميل', 'سرعة الرفع', 'الأجهزة', 'الحالة', 'تاريخ الإنشاء']);

    $all_cards = $db->query('SELECT * FROM cards ORDER BY created_at DESC')->fetchAll();
    foreach ($all_cards as $c) {
        fputcsv($output, [
            $c['card_code'], number_format($c['price'] ?? 0.0, 1) . ' EGP', $c['total_mb'], $c['used_mb'], 
            $c['total_minutes'], $c['used_minutes'],
            $c['download_speed'], $c['upload_speed'],
            $c['max_devices'], $c['status'], $c['created_at']
        ]);
    }
    fclose($output);
    exit;
}

// معالجة العمليات الجماعية (Bulk Actions)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action']) && !empty($_POST['card_ids'])) {
    $ids = array_map('intval', $_POST['card_ids']);
    $action = $_POST['bulk_action'];
    $placeholders = implode(',', $ids);
    
    if ($action === 'delete') {
        $db->exec("DELETE FROM cards WHERE id IN ($placeholders)");
        header('Location: index.php?msg=bulk_deleted');
        exit;
    } elseif ($action === 'enable') {
        $db->exec("UPDATE cards SET status = 'active' WHERE id IN ($placeholders)");
        header('Location: index.php?msg=bulk_enabled');
        exit;
    } elseif ($action === 'disable') {
        $db->exec("UPDATE cards SET status = 'disabled' WHERE id IN ($placeholders)");
        header('Location: index.php?msg=bulk_disabled');
        exit;
    } elseif ($action === 'print') {
        header("Location: print.php?ids=" . implode(',', $ids));
        exit;
    } elseif ($action === 'export') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=selected_cards_' . date('Y-m-d') . '.csv');
        $output = fopen('php://output', 'w');
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($output, ['كود الكارت', 'السعر', 'الداتا الكلية (MB)', 'الداتا المستخدمة (MB)', 'الوقت الكلي (د)', 'الوقت المستخدم (د)', 'سرعة التحميل', 'سرعة الرفع', 'الأجهزة', 'الحالة', 'تاريخ الإنشاء']);

        $selected_cards = $db->query("SELECT * FROM cards WHERE id IN ($placeholders) ORDER BY created_at DESC")->fetchAll();
        foreach ($selected_cards as $c) {
            fputcsv($output, [
                $c['card_code'], number_format($c['price'] ?? 0.0, 1) . ' EGP', $c['total_mb'], $c['used_mb'], 
                $c['total_minutes'], $c['used_minutes'],
                $c['download_speed'], $c['upload_speed'],
                $c['max_devices'], $c['status'], $c['created_at']
            ]);
        }
        fclose($output);
        exit;
    }
}

// فلترة متقدمة
$where = '1=1';
$params = [];
if (!empty($_GET['status'])) {
    $where .= ' AND status = ?';
    $params[] = $_GET['status'];
}
if (!empty($_GET['search'])) {
    $where .= ' AND card_code LIKE ?';
    $params[] = '%' . $_GET['search'] . '%';
}
if (!empty($_GET['min_mb'])) {
    $where .= ' AND total_mb >= ?';
    $params[] = intval($_GET['min_mb']);
}
if (!empty($_GET['max_mb'])) {
    $where .= ' AND total_mb <= ?';
    $params[] = intval($_GET['max_mb']);
}

// الترتيب
$order_by = $_GET['sort'] ?? 'created_at';
$order_dir = $_GET['dir'] ?? 'DESC';
$allowed_sort = ['created_at', 'card_code', 'total_mb', 'used_mb', 'status'];
if (!in_array($order_by, $allowed_sort)) $order_by = 'created_at';
if (!in_array($order_dir, ['ASC', 'DESC'])) $order_dir = 'DESC';

// التصفح
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

// العدد الكلي
$count_stmt = $db->prepare("SELECT COUNT(*) FROM cards WHERE $where");
$count_stmt->execute($params);
$total_count = $count_stmt->fetchColumn();
$total_pages = max(1, ceil($total_count / $per_page));

$stmt = $db->prepare("SELECT * FROM cards WHERE $where ORDER BY $order_by $order_dir LIMIT $per_page OFFSET $offset");
$stmt->execute($params);
$cards = $stmt->fetchAll();
?>
<?php
$page_title = 'إدارة الكروت';
$active_page = 'cards';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
/* Cards specific styles */
.toolbar {
  display:flex; gap:12px; margin-bottom:20px; flex-wrap:wrap; align-items:center;
  background:var(--card-bg); padding:15px; border-radius:14px;
  border:1px solid var(--border);
  backdrop-filter: blur(10px);
}

.btn-edit    { background:rgba(234,179,8,0.15); color:#eab308; border:1px solid rgba(234,179,8,0.3); }
.btn-edit:hover { background:rgba(234,179,8,0.25); }
.btn-sm { padding:6px 12px; font-size:0.75rem; }

table { width:100%; border-collapse:collapse; font-size:0.82rem; }
th { 
  color:var(--text-muted); padding:12px 10px; text-align:right; 
  border-bottom:1px solid var(--border); 
  font-weight:700; font-size:0.78rem; text-transform:uppercase; letter-spacing:0.5px;
}
td { padding:12px 10px; border-bottom:1px solid rgba(255,255,255,0.03); color:#94a3b8; }
tr:last-child td { border:none; }
tr:hover td { background:rgba(255,255,255,0.02); }

.badge {
  padding:4px 12px; border-radius:20px; font-size:0.72rem; font-weight:700;
}
.badge.active   { background:rgba(34,197,94,0.15);  color:#22c55e; }
.badge.expired  { background:rgba(239,68,68,0.15);   color:#ef4444; }
.badge.disabled { background:rgba(156,163,175,0.15); color:#9ca3af; }

.progress-wrap { background:rgba(255,255,255,0.06); border-radius:10px; height:6px; min-width:80px; }
.progress-bar  { height:6px; border-radius:10px; background:linear-gradient(90deg,var(--primary),var(--secondary)); transition:width 0.5s; }
.progress-bar.danger { background:linear-gradient(90deg,#ef4444,#f97316); }
.progress-bar.warning { background:linear-gradient(90deg,#f59e0b,#d97706); }

.actions { display:flex; gap:6px; }

/* Pagination */
.pagination { display:flex; gap:6px; justify-content:center; margin-top:20px; }
.pagination a, .pagination span {
  padding:8px 14px; border-radius:8px; text-decoration:none;
  font-size:0.82rem; font-weight:600; transition:all 0.2s;
}
.pagination a { background:rgba(255,255,255,0.05); color:#94a3b8; border:1px solid rgba(255,255,255,0.08); }
.pagination a:hover { background:rgba(0,212,255,0.1); color:var(--primary); border-color:rgba(0,212,255,0.2); }
.pagination span { background:linear-gradient(90deg,var(--primary),var(--secondary)); color:#fff; }

.code-highlight {
  font-family:'Fira Code', monospace; font-weight:700; color:var(--primary);
  background:rgba(0,212,255,0.08); padding:4px 10px; border-radius:6px;
  font-size:0.85rem; letter-spacing:1px;
}

.sort-link { color:var(--text-muted); text-decoration:none; transition:color 0.2s; }
.sort-link:hover { color:var(--primary); }
.sort-link.active { color:var(--primary); }

.stats-summary { display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:12px; margin-bottom:20px; }
.stat-mini {
  background:var(--card-bg); border-radius:12px; padding:15px;
  border:1px solid var(--border); text-align:center;
  backdrop-filter: blur(10px);
}
.stat-mini .num { font-size:1.4rem; font-weight:800; }
.stat-mini .lbl { font-size:0.72rem; color:var(--text-muted); margin-top:4px; }
.stat-mini.green .num { color:var(--accent); }
.stat-mini.red .num { color:#ef4444; }
.stat-mini.blue .num { color:var(--primary); }
.stat-mini.gray .num { color:#9ca3af; }
</style>

<div class="main">
  <div class="topbar">
    <h1>🎫 إدارة الكروت</h1>
  </div>

  <?php if (isset($_GET['msg'])): ?>
    <?php if ($_GET['msg'] === 'deleted'): ?>
      <div class="alert danger">🗑️ تم حذف الكارت بنجاح</div>
    <?php elseif ($_GET['msg'] === 'saved'): ?>
      <div class="alert success">✅ تم حفظ الكارت بنجاح</div>
    <?php elseif ($_GET['msg'] === 'toggled'): ?>
      <div class="alert info">🔄 تم تغيير حالة الكارت</div>
    <?php elseif ($_GET['msg'] === 'bulk_deleted'): ?>
      <div class="alert danger">🗑️ تم حذف الكروت المحددة بنجاح</div>
    <?php elseif ($_GET['msg'] === 'bulk_enabled'): ?>
      <div class="alert success">🟢 تم تفعيل الكروت المحددة بنجاح</div>
    <?php elseif ($_GET['msg'] === 'bulk_disabled'): ?>
      <div class="alert info">⚫ تم تعطيل الكروت المحددة بنجاح</div>
    <?php endif; ?>
  <?php endif; ?>

  <!-- Stats Summary -->
  <div class="stats-summary">
    <div class="stat-mini">
      <div class="num" style="color:#00d4ff"><?= $total_count ?></div>
      <div class="lbl">إجمالي الكروت</div>
    </div>
    <div class="stat-mini">
      <div class="num" style="color:#22c55e"><?= $db->query("SELECT COUNT(*) FROM cards WHERE status='active'")->fetchColumn() ?></div>
      <div class="lbl">نشطة</div>
    </div>
    <div class="stat-mini">
      <div class="num" style="color:#ef4444"><?= $db->query("SELECT COUNT(*) FROM cards WHERE status='expired' OR (expire_date IS NOT NULL AND expire_date < datetime('now'))")->fetchColumn() ?></div>
      <div class="lbl">منتهية</div>
    </div>
    <div class="stat-mini">
      <div class="num" style="color:#9ca3af"><?= $db->query("SELECT COUNT(*) FROM cards WHERE status='disabled'")->fetchColumn() ?></div>
      <div class="lbl">معطلة</div>
    </div>
  </div>

  <!-- Toolbar -->
  <div class="toolbar">
    <a href="create.php" class="btn btn-primary">➕ إضافة كارت</a>
    <a href="generate.php" class="btn btn-success">⚡ توليد كروت</a>
    <a href="packages.php" class="btn btn-info" style="background:rgba(124,58,237,0.15); color:#a855f7; border:1px solid rgba(124,58,237,0.3);">📦 الباقات</a>
    <a href="index.php?export=1" class="btn btn-info">📥 تصدير CSV الكل</a>

    <form method="GET" style="display:flex;gap:10px;flex:1;flex-wrap:wrap;">
      <input type="text" name="search" placeholder="🔍 بحث بالكود..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>" style="min-width:150px;">
      <select name="status">
        <option value="">كل الحالات</option>
        <option value="active"   <?= ($_GET['status']??'')==='active'  ?'selected':'' ?>>🟢 نشطة</option>
        <option value="expired"  <?= ($_GET['status']??'')==='expired' ?'selected':'' ?>>🔴 منتهية</option>
        <option value="disabled" <?= ($_GET['status']??'')==='disabled'?'selected':'' ?>>⚫ معطلة</option>
      </select>
      <input type="number" name="min_mb" placeholder="حد أدنى للداتا" value="<?= htmlspecialchars($_GET['min_mb'] ?? '') ?>" style="width:120px;">
      <input type="number" name="max_mb" placeholder="حد أقصى للداتا" value="<?= htmlspecialchars($_GET['max_mb'] ?? '') ?>" style="width:120px;">
      <button type="submit" class="btn btn-primary">🔍 بحث</button>
      <?php if (!empty($_GET['search']) || !empty($_GET['status']) || !empty($_GET['min_mb']) || !empty($_GET['max_mb'])): ?>
        <a href="index.php" class="btn btn-danger btn-sm">✕ إلغاء</a>
      <?php endif; ?>
    </form>
  </div>

  <!-- فورم العمليات الجماعية والجدول -->
  <form method="POST" id="bulk_form">
    
    <!-- شريط العمليات الجماعية -->
    <div class="bulk-actions-bar" id="bulk_bar" style="display:none; background: rgba(124, 58, 237, 0.08); border: 1px solid rgba(124, 58, 237, 0.2); padding: 15px 20px; border-radius: 14px; margin-bottom: 20px; align-items: center; justify-content: space-between;">
      <div style="font-size: 0.88rem; font-weight: 700; color: #a855f7;">
        ⚡ تم تحديد <span id="selected_count" style="font-size: 1.1rem; color: #00d4ff;">0</span> كارت:
      </div>
      <div style="display:flex; gap:10px; align-items: center;">
        <select name="bulk_action" id="bulk_action_select" style="background:#0d111f; border:1px solid rgba(255,255,255,0.1); color:#fff; padding:8px 12px; border-radius:10px; font-size:0.82rem; outline:none; font-family:inherit;">
          <option value="">اختر الإجراء...</option>
          <option value="enable">🟢 تفعيل المختار</option>
          <option value="disable">⚫ تعطيل المختار</option>
          <option value="print">🖨️ طباعة المختار</option>
          <option value="export">📥 تصدير CSV للمختار</option>
          <option value="delete">🗑️ حذف المختار نهائياً</option>
        </select>
        <button type="submit" class="btn btn-primary btn-sm" onclick="return confirmBulkAction()">تطبيق الإجراء</button>
      </div>
    </div>

    <div class="box">
      <div class="box-header">
        <h3>قائمة الكروت</h3>
        <span style="color:#475569; font-size:0.82rem;">الصفحة <?= $page ?> من <?= $total_pages ?> | إجمالي <?= $total_count ?> كارت</span>
      </div>
      <table>
        <tr>
          <th style="width: 40px; text-align: center;"><input type="checkbox" id="select_all" style="cursor: pointer; transform: scale(1.1);"></th>
          <th><a href="?sort=card_code&dir=<?= $order_by==='card_code' && $order_dir==='ASC'?'DESC':'ASC' ?><?= !empty($_GET['search'])?'&search='.urlencode($_GET['search']):'' ?>" class="sort-link <?= $order_by==='card_code'?'active':'' ?>">الكود <?= $order_by==='card_code'?($order_dir==='ASC'?'▲':'▼'):'' ?></a></th>
          <th>السعر</th>
          <th>الداتا</th>
          <th>الوقت</th>
          <th>السرعة</th>
          <th>الأجهزة</th>
          <th>الانتهاء</th>
          <th><a href="?sort=status&dir=<?= $order_by==='status' && $order_dir==='ASC'?'DESC':'ASC' ?><?= !empty($_GET['search'])?'&search='.urlencode($_GET['search']):'' ?>" class="sort-link <?= $order_by==='status'?'active':'' ?>">الحالة <?= $order_by==='status'?($order_dir==='ASC'?'▲':'▼'):'' ?></a></th>
          <th>إجراءات</th>
        </tr>
        <?php if ($cards): ?>
          <?php foreach ($cards as $c): ?>
          <?php
            $mb_pct  = $c['total_mb']      ? min(100, round($c['used_mb']      / $c['total_mb']      * 100)) : 0;
            $min_pct = $c['total_minutes'] ? min(100, round($c['used_minutes'] / $c['total_minutes'] * 100)) : 0;
            $is_expired = ($c['expire_date'] && strtotime($c['expire_date']) < time()) || ($c['total_mb'] > 0 && $c['used_mb'] >= $c['total_mb']) || ($c['total_minutes'] > 0 && $c['used_minutes'] >= $c['total_minutes']);
          ?>
          <tr>
            <td style="text-align: center;"><input type="checkbox" name="card_ids[]" value="<?= $c['id'] ?>" class="card-select" style="cursor: pointer; transform: scale(1.1);"></td>
            <td><span class="code-highlight"><?= htmlspecialchars($c['card_code']) ?></span></td>
            <td><span style="font-weight:700; color:#22c55e; font-family:monospace;"><?= number_format($c['price'] ?? 0.0, 1) ?> ج.م</span></td>
            <td>
              <?php if ($c['total_mb']): ?>
                <div style="font-size:0.75rem;color:#64748b;margin-bottom:3px"><?= number_format($c['used_mb']) ?> / <?= number_format($c['total_mb']) ?> MB</div>
                <div class="progress-wrap"><div class="progress-bar <?= $mb_pct>=90?'danger':($mb_pct>=70?'warning':'') ?>" style="width:<?= $mb_pct ?>%"></div></div>
              <?php else: ?>
                <span style="color:#475569">∞</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($c['total_minutes']): ?>
                <div style="font-size:0.75rem;color:#64748b;margin-bottom:3px"><?= round($c['used_minutes']) ?> / <?= $c['total_minutes'] ?> دقيقة</div>
                <div class="progress-wrap"><div class="progress-bar <?= $min_pct>=90?'danger':($min_pct>=70?'warning':'') ?>" style="width:<?= $min_pct ?>%"></div></div>
              <?php else: ?>
                <span style="color:#475569">∞</span>
              <?php endif; ?>
            </td>
            <td style="font-size:0.78rem">
              <span style="color:#22c55e">⬇ <?= $c['download_speed'] ? number_format($c['download_speed']).' Kbps' : '∞' ?></span><br>
              <span style="color:#64748b">⬆ <?= $c['upload_speed'] ? number_format($c['upload_speed']).' Kbps' : '∞' ?></span>
            </td>
            <td style="text-align:center">
              <span style="font-weight:700; color:#00d4ff;"><?= $c['max_devices'] ?></span>
              <?php if ($c['bind_mac']): ?><span style="font-size:0.7rem; color:#475569;">🔒</span><?php endif; ?>
            </td>
            <td style="font-size:0.78rem;color:#64748b">
              <?= $c['expire_date'] ? date('Y-m-d H:i', strtotime($c['expire_date'])) : '<span style="color:#475569">لا ينتهي</span>' ?>
              <?php if ($is_expired && $c['status'] === 'active'): ?><br><span style="color:#ef4444; font-size:0.7rem;">⚠️ منتهي</span><?php endif; ?>
            </td>
            <td><span class="badge <?= htmlspecialchars($c['status']) ?>"><?= $c['status'] === 'active' ? '🟢 نشط' : ($c['status'] === 'expired' ? '🔴 منتهي' : '⚫ معطل') ?></span></td>
            <td>
              <div class="actions">
                <a href="edit.php?id=<?= $c['id'] ?>" class="btn btn-edit btn-sm">✏️</a>
                <a href="index.php?toggle=<?= $c['id'] ?>" class="btn btn-sm" style="background:rgba(0,212,255,0.1);color:#00d4ff;border:1px solid rgba(0,212,255,0.2);">🔄</a>
                <a href="index.php?delete=<?= $c['id'] ?>" class="btn btn-danger btn-sm"
                   onclick="return confirm('حذف الكارت <?= htmlspecialchars($c['card_code']) ?>؟ لا يمكن التراجع!')">🗑️</a>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="9" style="text-align:center;color:#475569;padding:40px">لا توجد كروت مطابقة للبحث</td></tr>
        <?php endif; ?>
      </table>

      <!-- Pagination -->
      <?php if ($total_pages > 1): ?>
      <div class="pagination">
        <?php if ($page > 1): ?>
          <a href="?page=<?= $page-1 ?><?= !empty($_GET['search'])?'&search='.urlencode($_GET['search']):'' ?><?= !empty($_GET['status'])?'&status='.$_GET['status']:'' ?><?= !empty($_GET['sort'])?'&sort='.$_GET['sort'].'&dir='.$_GET['dir']:'' ?>">← السابق</a>
        <?php endif; ?>

        <?php for ($i = max(1, $page-2); $i <= min($total_pages, $page+2); $i++): ?>
          <?php if ($i == $page): ?>
            <span><?= $i ?></span>
          <?php else: ?>
            <a href="?page=<?= $i ?><?= !empty($_GET['search'])?'&search='.urlencode($_GET['search']):'' ?><?= !empty($_GET['status'])?'&status='.$_GET['status']:'' ?><?= !empty($_GET['sort'])?'&sort='.$_GET['sort'].'&dir='.$_GET['dir']:'' ?>"><?= $i ?></a>
          <?php endif; ?>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
          <a href="?page=<?= $page+1 ?><?= !empty($_GET['search'])?'&search='.urlencode($_GET['search']):'' ?><?= !empty($_GET['status'])?'&status='.$_GET['status']:'' ?><?= !empty($_GET['sort'])?'&sort='.$_GET['sort'].'&dir='.$_GET['dir']:'' ?>">التالي →</a>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>

  </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const selectAll = document.getElementById('select_all');
  const cardSelects = document.querySelectorAll('.card-select');
  const bulkBar = document.getElementById('bulk_bar');
  const selectedCount = document.getElementById('selected_count');
  
  function updateBulkBar() {
    const checked = document.querySelectorAll('.card-select:checked');
    selectedCount.textContent = checked.length;
    if (checked.length > 0) {
      bulkBar.style.display = 'flex';
    } else {
      bulkBar.style.display = 'none';
    }
  }
  
  if (selectAll) {
    selectAll.addEventListener('change', function() {
      cardSelects.forEach(cb => {
        cb.checked = selectAll.checked;
      });
      updateBulkBar();
    });
  }
  
  cardSelects.forEach(cb => {
    cb.addEventListener('change', updateBulkBar);
  });
});

function confirmBulkAction() {
  const action = document.getElementById('bulk_action_select').value;
  if (!action) {
    alert('من فضلك اختر إجراءً أولاً ليتم تطبيقه');
    return false;
  }
  if (action === 'delete') {
    return confirm('هل أنت متأكد تماماً من حذف الكروت المحددة نهائياً؟ لا يمكن التراجع عن هذا الإجراء!');
  }
  return true;
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>