<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$msg = '';
$error = '';

// معالجة الأكشنز
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete_group'])) {
        $group_id = intval($_POST['group_id']);
        // حذف الكروت التابعة للمجموعة أولاً
        $db->prepare('DELETE FROM cards WHERE group_id = ?')->execute([$group_id]);
        // حذف المجموعة ذاتها
        $db->prepare('DELETE FROM card_groups WHERE id = ?')->execute([$group_id]);
        $msg = "🗑️ تم حذف المجموعة وكافة كروت التابعة لها بنجاح.";
    } elseif (isset($_POST['edit_group'])) {
        $group_id = intval($_POST['group_id']);
        $price = floatval($_POST['price'] ?? 0.0);
        $dl = intval($_POST['download_speed'] ?? 0);
        $ul = intval($_POST['upload_speed'] ?? 0);
        $max_dev = intval($_POST['max_devices'] ?? 1);
        $status = $_POST['status'] ?? 'active';
        
        $stmt = $db->prepare('
            UPDATE cards 
            SET price = ?, download_speed = ?, upload_speed = ?, max_devices = ?, status = ?
            WHERE group_id = ?
        ');
        $stmt->execute([$price, $dl, $ul, $max_dev, $status, $group_id]);
        $msg = "⚙️ تم تحديث كافة كروت المجموعة بنجاح.";
    }
}

// جلب المجموعات مع تفاصيل الكروت التابعة لها
$groups = $db->query('
    SELECT cg.*, 
           (SELECT COUNT(*) FROM cards c WHERE c.group_id = cg.id) as cards_count,
           (SELECT COALESCE(AVG(c.price), 0.0) FROM cards c WHERE c.group_id = cg.id) as avg_price,
           (SELECT c.download_speed FROM cards c WHERE c.group_id = cg.id LIMIT 1) as dl_speed,
           (SELECT c.upload_speed FROM cards c WHERE c.group_id = cg.id LIMIT 1) as ul_speed,
           (SELECT c.max_devices FROM cards c WHERE c.group_id = cg.id LIMIT 1) as max_dev,
           (SELECT c.status FROM cards c WHERE c.group_id = cg.id LIMIT 1) as card_status
    FROM card_groups cg
    ORDER BY cg.created_at DESC
')->fetchAll();

$page_title = 'مجموعات الكروت';
$active_page = 'groups';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
table { width:100%; border-collapse:collapse; font-size:0.82rem; }
th {
  color:var(--text-muted); padding:12px 10px; text-align:right;
  border-bottom:1px solid var(--border);
  font-weight:700; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.5px;
}
td { padding:11px 10px; border-bottom:1px solid rgba(255,255,255,0.03); color:#94a3b8; vertical-align:middle; }
tr:last-child td { border:none; }
tr:hover td { background:rgba(255,255,255,0.02); }

.grp-name { font-weight:700; color:#f1f5f9; font-size:0.88rem; }
.badge-count {
  display:inline-block; padding:2px 8px; border-radius:20px;
  font-size:0.72rem; font-weight:700;
  background:rgba(0,212,255,0.1); color:var(--primary);
  border:1px solid rgba(0,212,255,0.2);
}

.empty-table { text-align:center; color:var(--text-muted); padding:50px 20px; font-size:0.88rem; }

/* مودال التعديل الجماعي */
.modal {
  display:none; position:fixed; top:0; left:0; width:100%; height:100%;
  background:rgba(3,7,18,0.8); backdrop-filter:blur(8px);
  z-index:999; align-items:center; justify-content:center; padding:20px;
}
.modal-content {
  background:#0f111a; border:1px solid var(--border); border-radius:20px;
  width:100%; max-width:480px; padding:25px; text-align:right;
  box-shadow:0 20px 50px rgba(0,0,0,0.5); position:relative;
}
.modal-content h3 { font-size:1.1rem; font-weight:800; margin-bottom:18px; color:#fff; }
.form-group { margin-bottom:14px; }
.form-group label { display:block; color:#94a3b8; font-size:0.82rem; margin-bottom:6px; font-weight:600; }
.modal-actions { display:flex; gap:10px; margin-top:20px; }
.close-modal-btn {
  position:absolute; top:15px; left:15px; background:none; border:none;
  color:var(--text-muted); font-size:1.2rem; cursor:pointer;
}
</style>

<div class="main">
  <div class="topbar">
    <div>
      <h1>📁 مجموعات الكروت (Batch Groups)</h1>
      <p style="color:var(--text-muted);font-size:0.82rem;margin-top:3px">إدارة الكروت وطباعتها وتعديلها كدفعات كاملة</p>
    </div>
    <a href="generate.php" class="btn btn-primary">➕ توليد دفعة جديدة</a>
  </div>

  <?php if ($msg): ?>
    <div class="alert success"><?= $msg ?></div>
  <?php endif; ?>

  <div class="box">
    <?php if (!empty($groups)): ?>
      <table style="min-width:600px">
        <thead>
          <tr>
            <th>اسم المجموعة</th>
            <th>تاريخ التوليد</th>
            <th>عدد الكروت</th>
            <th>متوسط السعر</th>
            <th>السرعات الحالية</th>
            <th>الأجهزة</th>
            <th>العمليات</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($groups as $g): ?>
            <tr>
              <td>
                <span class="grp-name">📁 <?= htmlspecialchars($g['name']) ?></span>
              </td>
              <td><?= date('Y-m-d H:i', strtotime($g['created_at'])) ?></td>
              <td><span class="badge-count"><?= $g['cards_count'] ?> كارت</span></td>
              <td style="font-family:monospace;font-weight:700;color:var(--primary)"><?= number_format($g['avg_price'], 1) ?> EGP</td>
              <td>
                <?php if ($g['dl_speed'] || $g['ul_speed']): ?>
                  <span style="font-family:monospace; font-size:0.75rem;">⬇<?= $g['dl_speed'] ?> / ⬆<?= $g['ul_speed'] ?> Kbps</span>
                <?php else: ?>
                  <span style="color:var(--accent)">غير محدود</span>
                <?php endif; ?>
              </td>
              <td><?= $g['max_dev'] ?></td>
              <td>
                <div style="display:flex; gap:6px;">
                  <a href="print.php?group_id=<?= $g['id'] ?>" class="btn btn-success btn-sm" style="padding:6px 12px; font-size:0.75rem;" target="_blank">🖨️ طباعة الدفعة</a>
                  <button class="btn btn-secondary btn-sm" style="padding:6px 12px; font-size:0.75rem;" onclick="openEditModal(<?= htmlspecialchars(json_encode($g)) ?>)">⚙️ تعديل</button>
                  <form method="POST" style="display:inline" onsubmit="return confirm('حذف كافة كروت هذه المجموعة نهائياً؟ لا يمكن التراجع.')">
                    <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
                    <button type="submit" name="delete_group" class="btn btn-danger btn-sm" style="padding:6px 12px; font-size:0.75rem;">🗑️ حذف</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <div class="empty-table">
        <div style="font-size:3rem; margin-bottom:15px; opacity:0.3;">📁</div>
        <p>لا يوجد مجموعات كروت نشطة حالياً.<br>قم بالانتقال لشاشة <strong>توليد الكروت</strong> لإنشاء دفعة جديدة.</p>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- مودال التعديل الجماعي -->
<div class="modal" id="editModal">
  <div class="modal-content">
    <button class="close-modal-btn" onclick="closeEditModal()">&times;</button>
    <h3 id="modalTitle">⚙️ تعديل خصائص المجموعة</h3>
    <form method="POST">
      <input type="hidden" name="group_id" id="edit_group_id">
      
      <div class="form-group">
        <label>💰 سعر الكارت (EGP)</label>
        <input type="number" step="0.1" name="price" id="edit_price" required>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
        <div class="form-group">
          <label>⬇️ سرعة التحميل (Kbps)</label>
          <input type="number" name="download_speed" id="edit_dl_speed" required>
        </div>
        <div class="form-group">
          <label>⬆️ سرعة الرفع (Kbps)</label>
          <input type="number" name="upload_speed" id="edit_ul_speed" required>
        </div>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
        <div class="form-group">
          <label>📱 أقصى عدد أجهزة</label>
          <input type="number" name="max_devices" id="edit_max_devices" required min="1">
        </div>
        <div class="form-group">
          <label>🚦 حالة الكروت</label>
          <select name="status" id="edit_status" required>
            <option value="active">نشط</option>
            <option value="disabled">معطل</option>
          </select>
        </div>
      </div>

      <div class="modal-actions">
        <button type="submit" name="edit_group" class="btn btn-primary" style="flex:1">💾 حفظ التغييرات</button>
        <button type="button" class="btn btn-secondary" onclick="closeEditModal()" style="flex:1">إلغاء</button>
      </div>
    </form>
  </div>
</div>

<script>
function openEditModal(group) {
  document.getElementById('edit_group_id').value = group.id;
  document.getElementById('modalTitle').innerText = '⚙️ تعديل المجموعة: ' + group.name;
  document.getElementById('edit_price').value = group.avg_price;
  document.getElementById('edit_dl_speed').value = group.dl_speed || 0;
  document.getElementById('edit_ul_speed').value = group.ul_speed || 0;
  document.getElementById('edit_max_devices').value = group.max_dev || 1;
  document.getElementById('edit_status').value = group.card_status || 'active';
  
  document.getElementById('editModal').style.display = 'flex';
}

function closeEditModal() {
  document.getElementById('editModal').style.display = 'none';
}

// إغلاق المودال عند النقر بالخارج
window.onclick = function(event) {
  const modal = document.getElementById('editModal');
  if (event.target === modal) {
    closeEditModal();
  }
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
