<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code     = trim($_POST['card_code']);
    $total_mb = intval($_POST['total_mb'])      ?: null;
    $total_min= intval($_POST['total_minutes']) ?: null;
    $dl_speed = intval($_POST['download_speed'])?: null;
    $ul_speed = intval($_POST['upload_speed'])  ?: null;
    $max_dev  = intval($_POST['max_devices'])   ?: 1;
    $bind_mac = isset($_POST['bind_mac']) ? 1 : 0;
    $expire   = !empty($_POST['expire_date']) ? $_POST['expire_date'] : null;
    $status   = $_POST['status'] ?? 'active';

    if (empty($code)) {
        $error = 'كود الكارت مطلوب';
    } else {
        try {
            $stmt = $db->prepare('
                INSERT INTO cards
                (card_code, total_mb, total_minutes, download_speed, upload_speed,
                 max_devices, bind_mac, expire_date, status)
                VALUES (?,?,?,?,?,?,?,?,?)
            ');
            $stmt->execute([$code,$total_mb,$total_min,$dl_speed,$ul_speed,$max_dev,$bind_mac,$expire,$status]);
            header('Location: index.php?msg=saved');
            exit;
        } catch (PDOException $e) {
            $error = 'الكود موجود بالفعل أو خطأ في البيانات';
        }
    }
}

// توليد كود عشوائي
function genCode($len=10) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    for ($i=0;$i<$len;$i++) $code .= $chars[random_int(0,strlen($chars)-1)];
    return $code;
}
$suggested = genCode();

$page_title = 'إضافة كارت جديد';
$active_page = 'cards';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
.create-form { max-width:640px; }
.form-group { margin-bottom:18px; }
.form-group label { display:block; color:#94a3b8; font-size:0.82rem; margin-bottom:7px; font-weight:600; }
.form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.hint { font-size:0.72rem; color:var(--text-muted); margin-top:5px; }

.code-field { display:flex; gap:8px; }
.code-field input { flex:1; font-family:monospace; font-size:1rem; letter-spacing:2px; }
.gen-btn {
  padding:10px 14px;
  background:rgba(0,212,255,0.1);
  border:1px solid rgba(0,212,255,0.25);
  color:var(--primary);
  border-radius:10px; cursor:pointer;
  font-size:0.83rem; font-weight:700;
  white-space:nowrap; transition:all 0.2s;
}
.gen-btn:hover { background:rgba(0,212,255,0.2); }

.checkbox-label {
  display:flex; align-items:center; gap:10px;
  cursor:pointer; font-size:0.88rem; color:#cbd5e1;
}
.checkbox-label input[type=checkbox] {
  width:18px; height:18px; cursor:pointer;
  accent-color:var(--primary);
}

.form-actions { display:flex; gap:12px; margin-top:20px; }
</style>

<div class="main">
  <div class="topbar">
    <div>
      <h1>➕ إضافة كارت جديد</h1>
      <p style="color:var(--text-muted);font-size:0.82rem;margin-top:3px">إنشاء كارت إنترنت مخصص يدوياً</p>
    </div>
    <a href="index.php" class="btn btn-secondary">← رجوع للكروت</a>
  </div>

  <?php if ($error): ?>
    <div class="alert error">⚠️ <?= $error ?></div>
  <?php endif; ?>

  <div class="box create-form">
    <form method="POST">

      <!-- كود الكارت -->
      <div class="form-group">
        <label>🔑 كود الكارت *</label>
        <div class="code-field">
          <input type="text" name="card_code" id="card_code"
                 value="<?= htmlspecialchars($_POST['card_code'] ?? $suggested) ?>"
                 placeholder="مثال: ABC12345" required>
          <button type="button" class="gen-btn" onclick="generateCode()">🔀 توليد</button>
        </div>
        <div class="hint">يُستخدم هذا الكود لتسجيل الدخول من قِبَل المستخدم</div>
      </div>

      <!-- الداتا والوقت -->
      <div class="form-row-2">
        <div class="form-group">
          <label>📊 الداتا الكلية (MB)</label>
          <input type="number" name="total_mb"
                 value="<?= htmlspecialchars($_POST['total_mb'] ?? '') ?>"
                 placeholder="0 = لانهائي" min="0">
        </div>
        <div class="form-group">
          <label>⏱️ الوقت الكلي (دقيقة)</label>
          <input type="number" name="total_minutes"
                 value="<?= htmlspecialchars($_POST['total_minutes'] ?? '') ?>"
                 placeholder="0 = لانهائي" min="0">
        </div>
      </div>

      <!-- السرعات -->
      <div class="form-row-2">
        <div class="form-group">
          <label>⬇️ سرعة التحميل (Kbps)</label>
          <input type="number" name="download_speed"
                 value="<?= htmlspecialchars($_POST['download_speed'] ?? '') ?>"
                 placeholder="0 = بدون حد">
        </div>
        <div class="form-group">
          <label>⬆️ سرعة الرفع (Kbps)</label>
          <input type="number" name="upload_speed"
                 value="<?= htmlspecialchars($_POST['upload_speed'] ?? '') ?>"
                 placeholder="0 = بدون حد">
        </div>
      </div>

      <!-- عدد الأجهزة وتاريخ الانتهاء -->
      <div class="form-row-2">
        <div class="form-group">
          <label>📱 عدد الأجهزة المسموحة</label>
          <input type="number" name="max_devices"
                 value="<?= htmlspecialchars($_POST['max_devices'] ?? '1') ?>"
                 min="1">
        </div>
        <div class="form-group">
          <label>🗓️ تاريخ الانتهاء</label>
          <input type="datetime-local" name="expire_date"
                 value="<?= htmlspecialchars($_POST['expire_date'] ?? '') ?>">
          <div class="hint">اتركه فارغاً = لا ينتهي</div>
        </div>
      </div>

      <!-- الحالة وربط MAC -->
      <div class="form-row-2">
        <div class="form-group">
          <label>🔘 الحالة الأولية</label>
          <select name="status">
            <option value="active">✅ نشط</option>
            <option value="disabled">⛔ معطل</option>
          </select>
        </div>
        <div class="form-group">
          <label>&nbsp;</label>
          <div style="margin-top:12px;">
            <label class="checkbox-label">
              <input type="checkbox" name="bind_mac" id="bind_mac" checked>
              🔒 ربط الكارت بعنوان MAC الجهاز الأول
            </label>
          </div>
        </div>
      </div>

      <div class="form-actions">
        <button type="submit" class="btn btn-primary">💾 حفظ الكارت</button>
        <a href="index.php" class="btn btn-secondary">إلغاء</a>
      </div>
    </form>
  </div>
</div>

<script>
const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function generateCode() {
  let code = '';
  for (let i = 0; i < 10; i++) code += chars[Math.floor(Math.random() * chars.length)];
  document.getElementById('card_code').value = code;
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
