<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$msg = '';
$error = '';

// إضافة باقة
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_package'])) {
    $name = trim($_POST['name'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $quota_val = intval($_POST['quota_value'] ?? 0);
    $quota_unit = $_POST['quota_unit'] ?? 'GB';
    $time_val = intval($_POST['time_value'] ?? 0);
    $time_unit = $_POST['time_unit'] ?? 'hours';
    $dl_speed = intval($_POST['download_speed'] ?? 0);
    $ul_speed = intval($_POST['upload_speed'] ?? 0);
    $max_devices = intval($_POST['max_devices'] ?? 1);
    $expire_days = intval($_POST['expire_days'] ?? 0) ?: null;

    if (empty($name)) {
        $error = "اسم الباقة مطلوب.";
    } elseif ($price <= 0) {
        $error = "سعر الباقة يجب أن يكون أكبر من 0.";
    } else {
        // حساب الميجابايتس بناء على الوحدة المختارة
        $total_mb = 0;
        if ($quota_val > 0) {
            $total_mb = ($quota_unit === 'GB') ? $quota_val * 1024 : $quota_val;
        }

        // حساب الدقائق بناء على الوحدة المختارة
        $total_minutes = 0;
        if ($time_val > 0) {
            if ($time_unit === 'days') {
                $total_minutes = $time_val * 24 * 60;
            } elseif ($time_unit === 'hours') {
                $total_minutes = $time_val * 60;
            } else {
                $total_minutes = $time_val;
            }
        }

        $stmt = $db->prepare('
            INSERT INTO packages (name, price, total_mb, total_minutes, download_speed, upload_speed, max_devices, expire_days)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ');
        $stmt->execute([$name, $price, $total_mb, $total_minutes, $dl_speed, $ul_speed, $max_devices, $expire_days]);
        $msg = "✅ تم إضافة الباقة بنجاح.";
    }
}

// حذف باقة
if (isset($_GET['delete'])) {
    $db->prepare('DELETE FROM packages WHERE id = ?')->execute([$_GET['delete']]);
    header('Location: packages.php?msg=deleted');
    exit;
}

if (isset($_GET['msg']) && $_GET['msg'] === 'deleted') {
    $msg = "🗑️ تم حذف الباقة بنجاح.";
}

$packages = getPackages();

$page_title = 'إدارة الباقات';
$active_page = 'packages';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
.pkg-layout { display:grid; grid-template-columns:1fr 1.7fr; gap:20px; }
@media (max-width:1000px) { .pkg-layout { grid-template-columns:1fr; } }

.form-group { margin-bottom:14px; }
.form-group label { display:block; color:#94a3b8; font-size:0.82rem; margin-bottom:6px; font-weight:600; }
.form-row-2 { display:grid; grid-template-columns:1.5fr 1fr; gap:10px; }
.form-row-eq { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
.btn-full { width:100%; justify-content:center; }

/* جدول الباقات */
table { width:100%; border-collapse:collapse; font-size:0.82rem; }
th {
  color:var(--text-muted); padding:12px 10px; text-align:right;
  border-bottom:1px solid var(--border);
  font-weight:700; font-size:0.75rem; text-transform:uppercase; letter-spacing:0.5px;
}
td { padding:11px 10px; border-bottom:1px solid rgba(255,255,255,0.03); color:#94a3b8; vertical-align:middle; }
tr:last-child td { border:none; }
tr:hover td { background:rgba(255,255,255,0.02); }

.pack-name { font-weight:700; color:#f1f5f9; font-size:0.88rem; }
.pack-price { font-weight:800; color:#22c55e; font-family:monospace; font-size:0.95rem; }
.pack-badge {
  display:inline-block; padding:2px 8px; border-radius:20px;
  font-size:0.72rem; font-weight:700;
  background:rgba(0,212,255,0.1); color:var(--primary);
  border:1px solid rgba(0,212,255,0.2);
}

.empty-table { text-align:center; color:var(--text-muted); padding:50px 20px; font-size:0.88rem; }
</style>

<div class="main">
  <div class="topbar">
    <div>
      <h1>📦 إدارة باقات الكروت</h1>
      <p style="color:var(--text-muted);font-size:0.82rem;margin-top:3px">تعريف وإدارة باقات الإنترنت المتاحة</p>
    </div>
    <a href="index.php" class="btn btn-secondary">← رجوع للكروت</a>
  </div>

  <?php if ($msg): ?>
    <div class="alert success"><?= $msg ?></div>
  <?php elseif ($error): ?>
    <div class="alert error">⚠️ <?= $error ?></div>
  <?php endif; ?>

  <div class="pkg-layout">

    <!-- ===== نموذج إضافة باقة ===== -->
    <div class="box" style="align-self:start;">
      <div style="font-size:1rem; font-weight:700; color:#cbd5e1; margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid var(--border);">
        ➕ إضافة باقة جديدة
      </div>
      <form method="POST">
        <div class="form-group">
          <label>🏷️ اسم الباقة</label>
          <input type="text" name="name" placeholder="مثال: باقة الأسبوع 3 جيجا" required>
        </div>

        <div class="form-group">
          <label>💰 السعر (بالجنيه)</label>
          <input type="number" step="0.1" name="price" placeholder="مثال: 10" required>
        </div>

        <div class="form-group">
          <label>📊 حجم البيانات (الداتا)</label>
          <div class="form-row-2">
            <input type="number" name="quota_value" placeholder="0 = لانهائي" min="0">
            <select name="quota_unit">
              <option value="GB">GB</option>
              <option value="MB">MB</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>⏱️ رصيد الوقت</label>
          <div class="form-row-2">
            <input type="number" name="time_value" placeholder="0 = لانهائي" min="0">
            <select name="time_unit">
              <option value="hours">ساعة</option>
              <option value="days">يوم</option>
              <option value="minutes">دقيقة</option>
            </select>
          </div>
        </div>

        <div class="form-group">
          <label>🚀 السرعة (Kbps)</label>
          <div class="form-row-eq">
            <input type="number" name="download_speed" placeholder="⬇ تحميل" min="0">
            <input type="number" name="upload_speed" placeholder="⬆ رفع" min="0">
          </div>
        </div>

        <div class="form-group">
          <label>📱 عدد الأجهزة المسموحة</label>
          <input type="number" name="max_devices" value="1" min="1">
        </div>

        <div class="form-group">
          <label>📅 صلاحية الكارت بالأيام (منذ أول دخول)</label>
          <input type="number" name="expire_days" placeholder="0 = غير محدد" min="0">
        </div>

        <button type="submit" name="add_package" class="btn btn-primary btn-full">
          ➕ إضافة الباقة
        </button>
      </form>
    </div>

    <!-- ===== قائمة الباقات ===== -->
    <div class="box">
      <div style="font-size:1rem; font-weight:700; color:#cbd5e1; margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center;">
        <span>📋 قائمة الباقات الحالية</span>
        <span style="font-size:0.78rem; color:var(--text-muted);"><?= count($packages) ?> باقة</span>
      </div>

      <?php if ($packages): ?>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr>
              <th>اسم الباقة</th>
              <th>السعر</th>
              <th>الداتا</th>
              <th>الوقت</th>
              <th>السرعة</th>
              <th>أجهزة</th>
              <th>صلاحية</th>
              <th>إجراء</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($packages as $p): ?>
            <?php
              $data_lbl = $p['total_mb']
                ? ($p['total_mb'] >= 1024 ? round($p['total_mb']/1024,1).' GB' : $p['total_mb'].' MB')
                : '∞';

              $time_lbl = '∞';
              if ($p['total_minutes'] > 0) {
                  if ($p['total_minutes'] % 1440 === 0) {
                      $time_lbl = ($p['total_minutes']/1440).' يوم';
                  } elseif ($p['total_minutes'] % 60 === 0) {
                      $time_lbl = ($p['total_minutes']/60).' ساعة';
                  } else {
                      $time_lbl = $p['total_minutes'].' دقيقة';
                  }
              }

              $speed_lbl = ($p['download_speed'] || $p['upload_speed'])
                  ? '⬇'.number_format($p['download_speed']).' / ⬆'.number_format($p['upload_speed'])
                  : '∞';
            ?>
            <tr>
              <td><span class="pack-name"><?= htmlspecialchars($p['name']) ?></span></td>
              <td><span class="pack-price"><?= number_format($p['price'], 1) ?> ج.م</span></td>
              <td><span class="pack-badge"><?= $data_lbl ?></span></td>
              <td><?= $time_lbl ?></td>
              <td style="font-size:0.72rem;font-family:monospace;"><?= $speed_lbl ?></td>
              <td style="text-align:center;"><?= $p['max_devices'] ?></td>
              <td><?= $p['expire_days'] ? $p['expire_days'].' يوم' : 'مفتوح' ?></td>
              <td>
                <a href="packages.php?delete=<?= $p['id'] ?>"
                   class="btn btn-danger"
                   style="padding:6px 12px; font-size:0.75rem;"
                   onclick="return confirm('هل تريد حذف هذه الباقة؟')">
                  🗑️ حذف
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php else: ?>
        <div class="empty-table">
          <div style="font-size:3rem; opacity:0.3; margin-bottom:12px;">📦</div>
          <p>لا توجد باقات مضافة حالياً<br>
          <span style="font-size:0.8rem;">أضف أول باقة من الجانب الأيمن</span></p>
        </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
