<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdmin();

$db = getDB();
$settings = getSettings();
$generated = [];
$generated_ids = [];
$error = '';

function genCode($len=8, $format='alphanumeric') {
    if ($format === 'numeric') {
        $chars = '0123456789';
    } elseif ($format === 'alpha') {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    } else {
        // تجنب الحروف المتشابهة مثل 0, O, 1, I
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    }
    $code = '';
    for ($i=0; $i<$len; $i++) {
        $code .= $chars[random_int(0, strlen($chars)-1)];
    }
    return $code;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $count        = min(500, max(1, intval($_POST['count'])));
    $total_mb     = intval($_POST['total_mb'])      ?: null;
    $total_min    = intval($_POST['total_minutes']) ?: null;
    $dl_speed     = intval($_POST['download_speed'])?: null;
    $ul_speed     = intval($_POST['upload_speed'])  ?: null;
    $max_dev      = intval($_POST['max_devices'])   ?: 1;
    $expire       = !empty($_POST['expire_date'])   ? $_POST['expire_date'] : null;
    $expire_days  = intval($_POST['expire_days'])   ?: 0;
    $prefix       = strtoupper(trim($_POST['prefix'] ?? ''));
    $code_format  = $_POST['code_format']           ?? 'alphanumeric';
    $code_len     = min(15, max(4, intval($_POST['code_len'] ?? 8)));
    $price        = floatval($_POST['price']        ?? 0.0);
    $group_name   = trim($_POST['group_name'] ?? '');
    if ($group_name === '') {
        $group_name = 'دفعة ' . date('Y-m-d H:i');
    }

    // إنشاء سجل للمجموعة الجديدة
    $group_stmt = $db->prepare('INSERT INTO card_groups (name, created_at) VALUES (?, CURRENT_TIMESTAMP)');
    $group_stmt->execute([$group_name]);
    $group_id = $db->lastInsertId();

    $stmt = $db->prepare('
        INSERT INTO cards (card_code, total_mb, total_minutes, download_speed, upload_speed, max_devices, expire_date, expire_days, price, group_id, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "active")
    ');

    for ($i=0; $i<$count; $i++) {
        $attempts = 0;
        do {
            $code = $prefix . genCode($code_len - strlen($prefix), $code_format);
            $exists = $db->prepare('SELECT id FROM cards WHERE card_code=?');
            $exists->execute([$code]);
            $attempts++;
        } while ($exists->fetch() && $attempts < 15);

        try {
            $stmt->execute([$code, $total_mb, $total_min, $dl_speed, $ul_speed, $max_dev, $expire, $expire_days, $price, $group_id]);
            $last_id = $db->lastInsertId();
            $generated[] = $code;
            $generated_ids[] = $last_id;
        } catch (PDOException $e) {
            // تجاهل التكرار
        }
    }
}

$packages = getPackages();

$page_title = 'توليد كروت بالجملة';
$active_page = 'cards';
$path_prefix = '../';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>
<style>
.gen-grid { display:grid; grid-template-columns:1.2fr 1fr; gap:20px; }
@media (max-width:1000px) { .gen-grid { grid-template-columns:1fr; } }

.form-group { margin-bottom:16px; }
.form-group label { display:block; color:#94a3b8; font-size:0.83rem; margin-bottom:6px; font-weight:600; }
.form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
.hint { font-size:0.72rem; color:var(--text-muted); margin-top:4px; }

.btn-full { width:100%; justify-content:center; }

.pkg-select {
  background:rgba(0,212,255,0.04);
  border:1px solid rgba(0,212,255,0.15);
  border-radius:12px;
  padding:14px;
  margin-bottom:16px;
}
.pkg-select label { color:var(--primary) !important; font-size:0.82rem; margin-bottom:8px; }

.divider {
  border:none;
  border-top:1px solid var(--border);
  margin:16px 0;
}

/* بطاقات الأكواد المولدة */
.codes-grid {
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(140px,1fr));
  gap:10px; margin-top:15px;
  max-height:420px; overflow-y:auto; padding:5px;
}
.code-item {
  background:rgba(0,212,255,0.04);
  border:1px solid rgba(0,212,255,0.12);
  border-radius:10px; padding:12px;
  text-align:center;
  font-family:monospace; font-size:1rem;
  letter-spacing:2px; color:var(--primary);
  cursor:pointer; transition:all 0.2s;
}
.code-item:hover { background:rgba(0,212,255,0.1); border-color:var(--primary); transform:scale(1.02); }
.code-item.copied { background:rgba(34,197,94,0.1); border-color:rgba(34,197,94,0.3); color:#22c55e; }

.success-header {
  background:rgba(34,197,94,0.08);
  border:1px solid rgba(34,197,94,0.2);
  border-radius:12px; padding:15px 18px;
  margin-bottom:15px;
  display:flex; justify-content:space-between; align-items:center;
  flex-wrap:wrap; gap:10px;
}
.success-header span { color:#22c55e; font-weight:700; }

.action-btns { display:flex; gap:8px; flex-wrap:wrap; }
.btn-copy-all {
  background:rgba(0,212,255,0.12);
  border:1px solid rgba(0,212,255,0.25);
  color:var(--primary);
  padding:8px 16px; border-radius:8px;
  cursor:pointer; font-size:0.82rem; font-weight:700;
  transition:all 0.2s;
}
.btn-copy-all:hover { background:rgba(0,212,255,0.2); }

.btn-print-all {
  background:rgba(34,197,94,0.12);
  border:1px solid rgba(34,197,94,0.25);
  color:#22c55e;
  padding:8px 16px; border-radius:8px;
  cursor:pointer; font-size:0.82rem; font-weight:700;
  text-decoration:none; display:inline-flex; align-items:center; gap:5px;
  transition:all 0.2s;
}
.btn-print-all:hover { background:rgba(34,197,94,0.2); }

.empty-state {
  display:flex; flex-direction:column; align-items:center; justify-content:center;
  padding:80px 20px; color:var(--text-muted);
  text-align:center;
}
.empty-state .empty-icon { font-size:4rem; opacity:0.3; margin-bottom:15px; }
.empty-state p { font-size:0.88rem; line-height:1.7; }
</style>

<div class="main">
  <div class="topbar">
    <div>
      <h1>⚡ توليد كروت بالجملة</h1>
      <p style="color:var(--text-muted);font-size:0.82rem;margin-top:3px">إنشاء دفعات كبيرة من كروت الإنترنت</p>
    </div>
    <a href="index.php" class="btn btn-secondary">← رجوع للكروت</a>
  </div>

  <div class="gen-grid">
    <!-- ===== إعدادات التوليد ===== -->
    <div class="box">
      <form method="POST" id="gen_form">

        <!-- اختيار باقة جاهزة -->
        <div class="pkg-select">
          <label>📦 اختر باقة جاهزة لتعبئة الإعدادات تلقائياً (اختياري)</label>
          <select id="package_select">
            <option value="">-- تعبئة يدوية --</option>
            <?php foreach ($packages as $p): ?>
              <option value="<?= $p['id'] ?>"
                      data-price="<?= $p['price'] ?>"
                      data-mb="<?= $p['total_mb'] ?>"
                      data-min="<?= $p['total_minutes'] ?>"
                      data-dl="<?= $p['download_speed'] ?>"
                      data-ul="<?= $p['upload_speed'] ?>"
                      data-dev="<?= $p['max_devices'] ?>"
                      data-expdays="<?= $p['expire_days'] ?>">
                📦 <?= htmlspecialchars($p['name']) ?> (<?= number_format($p['price'], 1) ?> جنيه)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- اسم المجموعة -->
        <div class="form-group">
          <label>📁 اسم المجموعة (Batch Name)</label>
          <input type="text" name="group_name" placeholder="مثال: دفعة كروت فئة 5 جنيه (توليد تلقائي إذا تُرِك فارغاً)">
          <div class="hint">يساعدك في تنظيم الكروت وإعادة طباعة الدفعة كاملة لاحقاً</div>
        </div>

        <hr class="divider">

        <!-- عدد الكروت والسعر -->
        <div class="form-row-2">
          <div class="form-group">
            <label>🔢 عدد الكروت المراد إنشاؤها</label>
            <input type="number" name="count" value="10" min="1" max="500" required>
          </div>
          <div class="form-group">
            <label>💰 سعر الكارت (بالجنيه)</label>
            <input type="number" step="0.1" name="price" id="price" placeholder="مثال: 10" value="0">
          </div>
        </div>

        <!-- شكل وطول الكود -->
        <div class="form-row-2">
          <div class="form-group">
            <label>🔤 تنسيق كود الكارت</label>
            <select name="code_format">
              <option value="alphanumeric">حروف وأرقام (مختلط)</option>
              <option value="numeric">أرقام فقط</option>
              <option value="alpha">حروف فقط</option>
            </select>
          </div>
          <div class="form-group">
            <label>📏 طول كود الكارت</label>
            <input type="number" name="code_len" value="8" min="4" max="15" required>
          </div>
        </div>

        <!-- البادئة -->
        <div class="form-group">
          <label>🏷️ بادئة الكود (اختياري)</label>
          <input type="text" name="prefix" placeholder="مثال: VIP (حتى 5 أحرف)" maxlength="5">
          <div class="hint">حروف ثابتة تُضاف في بداية كل كارت</div>
        </div>

        <hr class="divider">

        <!-- الداتا والوقت -->
        <div class="form-row-2">
          <div class="form-group">
            <label>📊 حجم البيانات (MB)</label>
            <input type="number" name="total_mb" id="total_mb" placeholder="0 = لانهائي" min="0">
          </div>
          <div class="form-group">
            <label>⏱️ رصيد الوقت (دقيقة)</label>
            <input type="number" name="total_minutes" id="total_minutes" placeholder="0 = لانهائي" min="0">
          </div>
        </div>

        <!-- السرعات -->
        <div class="form-row-2">
          <div class="form-group">
            <label>⬇️ سرعة التحميل (Kbps)</label>
            <input type="number" name="download_speed" id="download_speed" placeholder="0 = بدون حد">
          </div>
          <div class="form-group">
            <label>⬆️ سرعة الرفع (Kbps)</label>
            <input type="number" name="upload_speed" id="upload_speed" placeholder="0 = بدون حد">
          </div>
        </div>

        <!-- الأجهزة وصلاحية الأيام -->
        <div class="form-row-2">
          <div class="form-group">
            <label>📱 عدد الأجهزة المسموحة</label>
            <input type="number" name="max_devices" id="max_devices" value="1" min="1">
          </div>
          <div class="form-group">
            <label>📅 صلاحية بالأيام (منذ أول دخول)</label>
            <input type="number" name="expire_days" id="expire_days" placeholder="0 = غير محدد" min="0">
          </div>
        </div>

        <!-- تاريخ انتهاء ثابت -->
        <div class="form-group">
          <label>🗓️ تاريخ انتهاء ثابت (اختياري)</label>
          <input type="datetime-local" name="expire_date">
          <div class="hint">صلاحية نهائية ثابتة مستقلة عن تاريخ أول تسجيل دخول</div>
        </div>

        <button type="submit" class="btn btn-primary btn-full">
          ⚡ توليد وحفظ الكروت في النظام
        </button>
      </form>
    </div>

    <!-- ===== الكروت المولدة ===== -->
    <div class="box">
      <?php if ($generated): ?>
        <div class="success-header">
          <span>✅ تم توليد <?= count($generated) ?> كارت بنجاح</span>
          <div class="action-btns">
            <button class="btn-copy-all" onclick="copyAll()">📋 نسخ الأكواد</button>
            <a href="print.php?ids=<?= implode(',', $generated_ids) ?>" class="btn-print-all" target="_blank">
              🖨️ طباعة القسائم
            </a>
          </div>
        </div>
        <div class="codes-grid" id="codesGrid">
          <?php foreach ($generated as $code): ?>
            <div class="code-item" onclick="copyCode(this,'<?= $code ?>')"><?= $code ?></div>
          <?php endforeach; ?>
        </div>
        <textarea id="allCodes" style="position:absolute;left:-9999px"><?= implode("\n", $generated) ?></textarea>
      <?php else: ?>
        <div class="empty-state">
          <div class="empty-icon">🎫</div>
          <p>اضبط إعدادات التوليد من اليمين<br>أو اختر باقة جاهزة ثم اضغط <strong>توليد</strong></p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
// تعبئة البيانات تلقائياً عند تغيير الباقة
document.getElementById('package_select').addEventListener('change', function() {
  const selected = this.options[this.selectedIndex];
  if (!selected.value) return;
  document.getElementById('price').value          = selected.getAttribute('data-price') || '0';
  document.getElementById('total_mb').value        = selected.getAttribute('data-mb') || '';
  document.getElementById('total_minutes').value   = selected.getAttribute('data-min') || '';
  document.getElementById('download_speed').value  = selected.getAttribute('data-dl') || '';
  document.getElementById('upload_speed').value    = selected.getAttribute('data-ul') || '';
  document.getElementById('max_devices').value     = selected.getAttribute('data-dev') || '1';
  document.getElementById('expire_days').value     = selected.getAttribute('data-expdays') || '';
});

function copyCode(el, code) {
  navigator.clipboard.writeText(code).then(() => {
    el.classList.add('copied');
    const orig = el.textContent;
    el.textContent = '✓ ' + code;
    setTimeout(() => { el.classList.remove('copied'); el.textContent = orig; }, 1500);
  });
}

function copyAll() {
  const ta = document.getElementById('allCodes');
  navigator.clipboard.writeText(ta.value).then(() => {
    alert('تم نسخ <?= count($generated) ?> كود كارت بنجاح!');
  });
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
