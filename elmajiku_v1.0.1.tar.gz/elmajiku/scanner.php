<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
$return_base = 'http://192.168.77.1/elmajiku/index.php';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>مسح QR / باركود</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }

:root {
  --primary: #00d4ff;
  --secondary: #7c3aed;
  --bg: #030712;
  --card: rgba(17,24,39,0.8);
}

body {
  background: radial-gradient(circle at 20% 30%, rgba(99,102,241,0.12) 0%, transparent 50%),
              radial-gradient(circle at 80% 70%, rgba(0,240,255,0.1)  0%, transparent 50%),
              var(--bg);
  color: #f3f4f6;
  font-family: system-ui,-apple-system,sans-serif;
  min-height: 100vh;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  padding: 20px;
  gap: 18px;
}

h1 {
  font-size: 1.15rem; font-weight: 800;
  background: linear-gradient(90deg, #fff, var(--primary));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  text-align: center;
}

/* ─── صندوق قارئ الكاميرا المباشرة (مربع) ─── */
.scanner-wrap {
  position: relative;
  width: min(360px, 92vw);
  aspect-ratio: 1 / 1;
  border-radius: 22px;
  overflow: hidden;
  border: 2px solid var(--primary);
  box-shadow: 0 0 40px rgba(0,212,255,0.2);
  background: #000;
  display: none; /* تظهر عند تفعيل الكاميرا */
}
.scanner-wrap.active { display: block; }

video {
  width: 100%; height: 100%;
  object-fit: cover; display: block;
}
canvas { display: none; }

/* ركنيات الإطار المربع */
.scan-frame {
  position: absolute;
  top:50%; left:50%;
  transform: translate(-50%,-50%);
  width: 62%; height: 62%;
  pointer-events: none;
}
.scan-frame::before,.scan-frame::after,
.scan-frame span::before,.scan-frame span::after {
  content:''; position:absolute;
  width:26px; height:26px;
  border-color: var(--primary); border-style:solid;
}
.scan-frame::before  { top:0;    left:0;  border-width:3px 0 0 3px; border-radius:5px 0 0 0; }
.scan-frame::after   { top:0;    right:0; border-width:3px 3px 0 0; border-radius:0 5px 0 0; }
.scan-frame span::before { bottom:0; left:0;  border-width:0 0 3px 3px; border-radius:0 0 0 5px; }
.scan-frame span::after  { bottom:0; right:0; border-width:0 3px 3px 0; border-radius:0 0 5px 0; }

/* خط مسح متحرك */
.scan-line {
  position:absolute; left:19%; right:19%;
  height:2px;
  background: linear-gradient(90deg,transparent,var(--primary),transparent);
  box-shadow: 0 0 10px var(--primary);
  animation: scanline 2s ease-in-out infinite;
}
@keyframes scanline {
  0%,100% { top:19%; } 50% { top:81%; }
}

/* ─── بطاقة الخيارات ─── */
.card {
  background: var(--card);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255,255,255,0.08);
  border-radius: 22px;
  padding: 28px 24px;
  width: min(380px, 94vw);
  text-align: center;
}
.card-title {
  font-size: 0.9rem; color: #9ca3af;
  margin-bottom: 20px; font-weight: 600;
}

/* زر التقاط صورة (file input) - الخيار الأول الموثوق */
.btn-capture-wrap {
  position: relative; overflow: hidden;
  display: inline-block; width: 100%;
}
.btn-capture-wrap input[type=file] {
  position: absolute; inset: 0;
  opacity: 0; cursor: pointer;
  font-size: 100px; /* يجعل منطقة النقر كبيرة */
}
.btn {
  width: 100%; padding: 15px 20px;
  border: none; border-radius: 14px;
  font-size: 0.95rem; font-weight: 700;
  cursor: pointer; font-family: inherit;
  display: flex; align-items: center; justify-content: center; gap: 8px;
  transition: all 0.25s;
}
.btn-primary {
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  color: #fff;
  box-shadow: 0 8px 25px rgba(0,212,255,0.25);
  margin-bottom: 12px;
}
.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 35px rgba(0,212,255,0.4);
}
.btn-secondary {
  background: rgba(124,58,237,0.12);
  border: 1px solid rgba(124,58,237,0.3);
  color: #a78bfa;
  margin-bottom: 12px;
}
.btn-secondary:hover {
  background: rgba(124,58,237,0.25);
}
.btn-ghost {
  background: rgba(255,255,255,0.04);
  border: 1px solid rgba(255,255,255,0.08);
  color: #6b7280;
}
.btn-ghost:hover { background: rgba(255,255,255,0.08); color: #fff; }

.divider {
  display: flex; align-items: center; gap: 12px;
  margin: 14px 0; color: #4b5563; font-size: 0.78rem;
}
.divider::before,.divider::after {
  content:''; flex:1;
  height:1px; background: rgba(255,255,255,0.06);
}

/* رسالة الحالة */
.status {
  font-size: 0.88rem; color: #9ca3af;
  min-height: 22px; text-align: center;
  transition: color 0.3s;
}
.status.ok  { color: #10b981; font-weight: 700; }
.status.err { color: #ef4444; }

/* شريط تحميل */
.loader {
  display: none;
  width: 100%; height: 4px;
  background: rgba(255,255,255,0.06);
  border-radius: 99px; overflow: hidden;
  margin-top: 10px;
}
.loader.active { display: block; }
.loader-bar {
  height: 100%; width: 30%;
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  border-radius: 99px;
  animation: loading 1.2s ease-in-out infinite;
}
@keyframes loading {
  0%   { transform: translateX(-100%); }
  100% { transform: translateX(430%); }
}
</style>
</head>
<body>

<h1>📷 مسح رمز QR / باركود</h1>

<!-- ─── منطقة الكاميرا المباشرة (تظهر عند التفعيل) ─── -->
<div class="scanner-wrap" id="scanner-wrap">
  <video id="video" playsinline autoplay muted></video>
  <canvas id="canvas"></canvas>
  <div class="scan-frame"><span></span></div>
  <div class="scan-line"></div>
</div>

<!-- ─── بطاقة الخيارات ─── -->
<div class="card" id="options-card">
  <div class="card-title">اختر طريقة المسح</div>

  <!-- الخيار 1: التقاط صورة من الكاميرا (يعمل على HTTP بدون قيود) -->
  <div class="btn-capture-wrap">
    <input type="file" id="file-input" accept="image/*" capture="environment">
    <button class="btn btn-primary" type="button">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
      التقاط صورة من الكاميرا
    </button>
  </div>

  <div class="divider">أو</div>

  <!-- الخيار 2: فتح كاميرا مباشرة (قد لا يعمل على HTTP) -->
  <button class="btn btn-secondary" type="button" id="live-cam-btn">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM17 17h3v3h-3zM14 20h3"/></svg>
    مسح مباشر عبر الكاميرا
  </button>

  <div class="status" id="status-msg"></div>
  <div class="loader" id="loader"><div class="loader-bar"></div></div>

  <div style="margin-top:14px;">
    <button class="btn btn-ghost" onclick="window.location.href='<?= $return_base ?>'">
      ← العودة لتسجيل الدخول
    </button>
  </div>
</div>

<script src="assets/js/jsQR.min.js"></script>
<script>
const RETURN_URL = '<?= $return_base ?>';
const statusEl   = document.getElementById('status-msg');
const loader     = document.getElementById('loader');
const scanWrap   = document.getElementById('scanner-wrap');
const video      = document.getElementById('video');
const canvas     = document.getElementById('canvas');
const ctx        = canvas.getContext('2d');
let scanning     = false;
let animFrame    = null;

// ─── دالة العودة بالكود ───────────────────────────────────
function redirectWithCode(code) {
  statusEl.textContent = '✅ تم المسح: ' + code;
  statusEl.className   = 'status ok';
  loader.classList.remove('active');
  stopCamera();
  setTimeout(() => {
    window.location.href = RETURN_URL + '?code=' + encodeURIComponent(code.trim().toUpperCase());
  }, 700);
}

function showError(msg) {
  statusEl.textContent = msg;
  statusEl.className   = 'status err';
  loader.classList.remove('active');
}

// ─── الخيار 1: معالجة صورة من الملف ─────────────────────
document.getElementById('file-input').addEventListener('change', function(e) {
  const file = e.target.files[0];
  if (!file) return;

  statusEl.textContent = '🔄 جارٍ تحليل الصورة...';
  statusEl.className   = 'status';
  loader.classList.add('active');

  const img = new Image();
  const url = URL.createObjectURL(file);
  img.onload = function() {
    canvas.width  = img.width;
    canvas.height = img.height;
    ctx.drawImage(img, 0, 0);
    URL.revokeObjectURL(url);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'attemptBoth'
    });
    if (code && code.data) {
      redirectWithCode(code.data);
    } else {
      showError('⚠️ لم يُعثر على QR/باركود في الصورة. حاول مجدداً مع مزيد من الإضاءة.');
    }
  };
  img.onerror = function() {
    URL.revokeObjectURL(url);
    showError('تعذّر فتح الصورة.');
  };
  img.src = url;
});

// ─── الخيار 2: الكاميرا المباشرة ─────────────────────────
document.getElementById('live-cam-btn').addEventListener('click', function() {
  if (scanning) { stopCamera(); return; }

  statusEl.textContent = 'جارٍ تشغيل الكاميرا...';
  statusEl.className   = 'status';
  loader.classList.add('active');

  navigator.mediaDevices.getUserMedia({
    video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
  }).then(stream => {
    video.srcObject = stream;
    video.play();
    scanWrap.classList.add('active');
    document.getElementById('options-card').style.marginTop = '14px';
    scanning = true;
    loader.classList.remove('active');
    statusEl.textContent = 'وجّه الكاميرا نحو الكود...';
    statusEl.className   = 'status';
    this.textContent = '⏹ إيقاف الكاميرا';
    animFrame = requestAnimationFrame(tick);
  }).catch(err => {
    loader.classList.remove('active');
    showError('تعذّر فتح الكاميرا. استخدم خيار التقاط الصورة بدلاً منه.');
    console.warn(err);
  });
});

function tick() {
  if (!scanning) return;
  if (video.readyState === video.HAVE_ENOUGH_DATA) {
    canvas.width  = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert'
    });
    if (code && code.data) {
      redirectWithCode(code.data);
      return;
    }
  }
  animFrame = requestAnimationFrame(tick);
}

function stopCamera() {
  scanning = false;
  cancelAnimationFrame(animFrame);
  if (video.srcObject) video.srcObject.getTracks().forEach(t => t.stop());
  scanWrap.classList.remove('active');
}
</script>
</body>
</html>
