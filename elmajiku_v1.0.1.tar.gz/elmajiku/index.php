<?php
// منع التخزين المؤقت (الكاش) لضمان تطبيق الإعدادات والألوان فوراً على الهواتف والأجهزة المتصلة بالشبكة
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

require_once __DIR__ . '/admin/includes/config.php';
require_once __DIR__ . '/admin/includes/db.php';
require_once __DIR__ . '/admin/includes/iptables.php';

// إعادة توجيه متصفح Captive Portal تلقائياً لعنوان الـ IP لتجنب ظهور روابط قوقل (generate_204) في شريط العنوان
$portal_ip = '192.168.77.1';
if (isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] !== $portal_ip) {
    header('Location: http://' . $portal_ip . '/elmajiku/index.php', true, 302);
    exit;
}

// تهيئة جدار الحماية وقواعد السرعة تلقائياً وتصفير الجلسات (مرة واحدة فقط بعد إقلاع الراوتر لتفادي تعليق المستخدمين)
if (!file_exists('/tmp/hotspot_init_v8_conntrack.lock')) {
    initHotspotChain();
    $db = getDB();
    $db->exec('DELETE FROM online_users'); // تصفير قائمة النشطين لتجنب تكرار عناوين الآي بي القديمة المعلقة
    @touch('/tmp/hotspot_init_v8_conntrack.lock');
}

session_start();

$settings  = getSettings();
$packages  = getPackages();
$db        = getDB();
$active_ads = $db->query('SELECT * FROM ads WHERE status = 1 ORDER BY sort_order ASC, created_at DESC')->fetchAll();
$client_ip = $_SERVER['REMOTE_ADDR'];
$error     = '';
$success   = '';

// فحص حظر الـ IP للتخمين
$blocked_time = isIpBlocked($client_ip);
if ($blocked_time > 0) {
    $blocked_min = ceil($blocked_time / 60);
    $error = "عذراً، تم حظر جهازك مؤقتاً بسبب محاولات دخول خاطئة متكررة. يرجى المحاولة بعد $blocked_min دقيقة.";
}

// جلب MAC و اسم الجهاز
$client_mac  = getMacFromIP($client_ip) ?? 'unknown';
$device_name = getDeviceName($client_ip) ?? 'Unknown Device';

// لو المستخدم متصل بالفعل - روحه لصفحة الحالة
$online = getOnlineUser($client_ip);

// تحقق هل الماك مستثنى من تسجيل الدخول (Bypass MAC)
if ($client_mac !== 'unknown' && isMacBypassed($client_mac)) {
    allowIP($client_ip);
    if (!$online) {
        addOnlineUser('BYPASS', $client_ip, $client_mac, $device_name);
        addLog('BYPASS', "تخطي تسجيل دخول تلقائي لجهاز مستثنى. IP: $client_ip, MAC: $client_mac");
    }
    header('Location: ' . BASE_URL . '/status.php');
    exit;
}

if ($online) {
    header('Location: ' . BASE_URL . '/status.php');
    exit;
}

// معالجة تسجيل الدخول العادي بالكارت
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if ($blocked_time > 0) {
        $blocked_min = ceil($blocked_time / 60);
        $error = "عذراً، تم حظر جهازك مؤقتاً بسبب محاولات دخول خاطئة متكررة. يرجى المحاولة بعد $blocked_min دقيقة.";
    } else {
        $code = strtoupper(trim($_POST['card_code'] ?? ''));

        if (empty($code)) {
            $error = 'من فضلك أدخل كود الكارت';
        } else {
            $card = getCard($code);

            if (!$card) {
                $error = 'كود الكارت غير صحيح، يرجى التأكد وإعادة المحاولة';
                $bf_enabled = intval($settings['brute_force_enabled'] ?? 1);
                if ($bf_enabled) {
                    $max_att = intval($settings['brute_force_max_attempts'] ?? 5);
                    $dur_min = intval($settings['brute_force_duration'] ?? 15);
                    $locked = registerFailedAttempt($client_ip, $max_att, $dur_min);
                    if ($locked) {
                        $error = "تم حظر جهازك مؤقتاً لمدة $dur_min دقيقة بسبب محاولات دخول خاطئة متكررة.";
                        $blocked_time = $dur_min * 60;
                    }
                }
        } elseif (!isCardValid($card)) {
            if ($card['status'] === 'disabled') {
                $error = 'هذا الكارت معطل حالياً من قبل المسؤول';
            } elseif ($card['total_mb'] > 0 && $card['used_mb'] >= $card['total_mb']) {
                $error = 'انتهت باقة البيانات (الداتا) الخاصة بهذا الكارت';
            } elseif ($card['total_minutes'] > 0 && $card['used_minutes'] >= $card['total_minutes']) {
                $error = 'انتهى رصيد الوقت المسموح به لهذا الكارت';
            } elseif ($card['expire_date'] && strtotime($card['expire_date']) < time()) {
                $error = 'انتهت صلاحية هذا الكارت ولم يعد صالحاً للاستخدام';
            } else {
                $error = 'هذا الكارت غير صالح للاستخدام حالياً';
            }
        } else {
            // فحص واستئناف الجلسات النشطة
            $db = getDB();
            $online_sessions = $db->prepare('SELECT * FROM online_users WHERE card_code = ?');
            $online_sessions->execute([$code]);
            $online_sessions = $online_sessions->fetchAll();
            $online_count = count($online_sessions);

            $same_device_online = false;
            foreach ($online_sessions as $session) {
                if ($client_mac !== 'unknown' && strtoupper($session['mac_address']) === strtoupper($client_mac)) {
                    // نفس الجهاز يعيد الاتصال بآي بي جديد: نحذف جلسته القديمة من الجدار الناري وجدول النشطين
                    blockIP($session['ip_address']);
                    removeOnlineUser($session['ip_address']);
                    $same_device_online = true;
                }
            }

            if ($same_device_online) {
                // إعادة حساب عدد المتصلين الفعلي بعد حذف الجلسة القديمة
                $online_count = $db->prepare('SELECT COUNT(*) FROM online_users WHERE card_code = ?');
                $online_count->execute([$code]);
                $online_count = $online_count->fetchColumn();
            }

            if ($online_count >= $card['max_devices']) {
                $error = 'عذراً، تم الوصول للحد الأقصى من الأجهزة المتصلة بالكارت (' . $card['max_devices'] . ')';
            } else {
                // فحص ربط الماك مع الأجهزة المتعددة
                if ($card['bind_mac']) {
                    $devices = getDevicesByCard($code);
                    if ($devices && $client_mac !== 'unknown') {
                        $known_macs = array_map('strtoupper', array_column($devices, 'mac_address'));
                        if (!in_array(strtoupper($client_mac), $known_macs)) {
                            // إذا كان عدد الماكات المسجلة يساوي أو أكبر من الحد الأقصى، نمنع الجهاز الجديد
                            if (count($known_macs) >= $card['max_devices']) {
                                $error = 'عذراً، هذا الكارت مرتبط بأجهزة أخرى ولا يمكن استخدامه على هذا الجهاز';
                            }
                        }
                    }
                }

                if (!$error) {
                    // تسجيل تاريخ أول دخول
                    setCardFirstLogin($code);

                    // إضافة لقائمة المتصلين
                    addOnlineUser($code, $client_ip, $client_mac, $device_name);

                    // تسجيل الجهاز بالبطاقة
                    addDevice($code, $client_mac, $device_name);

                    // تفعيل العبور في جدار الحماية والسرعة
                    allowIP($client_ip);

                    // تدوين الحدث
                    addLog($code, "تسجيل دخول ناجح. IP: $client_ip, MAC: $client_mac, الجهاز: $device_name");

                    // تصفير محاولات التخمين الفاشلة بعد الدخول الناجح
                    clearFailedAttempts($client_ip);

                    header('Location: ' . BASE_URL . '/status.php');
                    exit;
                }
            }
        }
    }
  }
}

// معالجة الدخول التجريبي المجاني (Free Trial)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['free_trial'])) {
    if (empty($settings['trial_enabled'])) {
        $error = 'عذراً، ميزة التجربة المجانية معطلة حالياً.';
    } elseif ($client_mac === 'unknown') {
        $error = 'تعذر تحديد عنوان الماك لجهازك. يرجى إعادة تحميل الصفحة والمحاولة مجدداً.';
    } else {
        $db = getDB();
        // فحص هل استخدم التجربة المجانية سابقاً
        $chk_trial = $db->prepare('SELECT COUNT(*) FROM devices WHERE card_code = "TRIAL" AND mac_address = ?');
        $chk_trial->execute([$client_mac]);
        $has_used = $chk_trial->fetchColumn();
        
        if ($has_used > 0) {
            $error = 'عذراً، لقد قمت باستخدام التجربة المجانية المتاحة لجهازك مسبقاً.';
        } else {
            // التأكد من وجود كارت التجربة المجانية أو إنشائه
            $trial_card = getCard('TRIAL');
            $trial_mb = intval($settings['trial_mb'] ?? 50);
            $trial_min = intval($settings['trial_min'] ?? 10);
            
            if (!$trial_card) {
                // إنشاء كارت تجريبي بالقيم الديناميكية من الإعدادات
                $stmt = $db->prepare('
                    INSERT INTO cards (card_code, total_mb, total_minutes, download_speed, upload_speed, max_devices, bind_mac, status)
                    VALUES ("TRIAL", ?, ?, 2048, 1024, 9999, 1, "active")
                ');
                $stmt->execute([$trial_mb, $trial_min]);
            } else {
                // تحديث كارت التجربة بالقيم الحالية لضمان تطابق الإعدادات
                $stmt = $db->prepare('
                    UPDATE cards 
                    SET total_mb = ?, total_minutes = ?
                    WHERE card_code = "TRIAL"
                ');
                $stmt->execute([$trial_mb, $trial_min]);
            }
            
            // تدوين الجلسة والعبور
            addOnlineUser('TRIAL', $client_ip, $client_mac, $device_name);
            addDevice('TRIAL', $client_mac, $device_name);
            allowIP($client_ip);
            addLog('TRIAL', "دخول تجريبي مجاني. IP: $client_ip, MAC: $client_mac");
            
            header('Location: ' . BASE_URL . '/status.php');
            exit;
        }
    }
}

// دالة جلب MAC من IP - تفحص ARP أولاً ثم DHCP leases كبديل
function getMacFromIP($ip) {
    // 1. فحص جدول ARP أولاً
    $arp = @file_get_contents('/proc/net/arp');
    if ($arp) {
        foreach (explode("\n", $arp) as $line) {
            $parts = preg_split('/\s+/', trim($line));
            if (isset($parts[0]) && $parts[0] === $ip && isset($parts[3])) {
                $mac = strtoupper($parts[3]);
                if ($mac !== '00:00:00:00:00:00' && strlen($mac) >= 11) {
                    return normalizeMac($mac);
                }
            }
        }
    }
    // 2. بديل: فحص ملف DHCP leases (في حال لم يُنشأ سجل ARP بعد)
    $leases = @file_get_contents('/tmp/dhcp.leases');
    if ($leases) {
        foreach (explode("\n", $leases) as $line) {
            $parts = explode(' ', trim($line));
            // تنسيق السطر: expiry mac ip hostname clientid
            if (count($parts) >= 3 && $parts[2] === $ip && isset($parts[1])) {
                $mac = strtoupper($parts[1]);
                if ($mac !== '00:00:00:00:00:00') return normalizeMac($mac);
            }
        }
    }
    return null;
}

// دالة جلب اسم الجهاز
function getDeviceName($ip) {
    $leases = @file_get_contents('/tmp/dhcp.leases');
    if ($leases) {
        foreach (explode("\n", $leases) as $line) {
            $parts = explode(' ', trim($line));
            if (isset($parts[2]) && $parts[2] === $ip && isset($parts[3])) {
                return ($parts[3] !== '*') ? $parts[3] : 'Unknown Device';
            }
        }
    }
    return 'Unknown Device';
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($settings['login_title'] ?? 'بوابة تسجيل الدخول للإنترنت') ?></title>
<!-- استخدام الخطوط المحلية لتفادي تعطل تحميل الصفحة بدون إنترنت -->
<style>
:root {
  --primary: <?= $settings['primary_color'] ?? '#00d4ff' ?>;
  --secondary: <?= $settings['secondary_color'] ?? '#7c3aed' ?>;
  --success: #10b981;
  --danger: #ef4444;
  --bg-dark: #030712;
  --card-bg: rgba(17, 24, 39, 0.65);
  --border: rgba(255, 255, 255, 0.08);
  --text: #f3f4f6;
  --text-muted: #9ca3af;
}

* { margin:0; padding:0; box-sizing:border-box; }
body {
  min-height: 100vh;
  background: radial-gradient(circle at 10% 20%, rgba(99, 102, 241, 0.12) 0%, transparent 40%),
              radial-gradient(circle at 90% 80%, rgba(0, 240, 255, 0.12) 0%, transparent 40%),
              var(--bg-dark);
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  color: var(--text);
  display: flex; align-items: center; justify-content: center;
  flex-direction: column;
  padding: 20px;
  overflow-x: hidden;
}

.container {
  width: 100%; max-width: 430px; position: relative;
}

.card {
  background: var(--card-bg);
  backdrop-filter: blur(25px);
  -webkit-backdrop-filter: blur(25px);
  border: 1px solid var(--border);
  border-radius: 28px;
  padding: 40px 30px;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.75);
  position: relative;
  overflow: hidden;
}

.card::before {
  content: '';
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 4px;
  background: linear-gradient(90deg, var(--primary), var(--secondary));
}

.logo { text-align: center; margin-bottom: 30px; }
.logo-icon {
  width: 75px; height: 75px; margin: 0 auto 18px;
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  border-radius: 24px;
  display: flex; align-items: center; justify-content: center;
  font-size: 2.2rem;
  box-shadow: 0 10px 30px rgba(0, 240, 255, 0.25);
  animation: float 4s ease-in-out infinite;
}
@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-8px); }
}

.logo h1 {
  font-size: 1.8rem; font-weight: 800;
  background: linear-gradient(90deg, #fff, var(--primary));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.logo p { color: var(--text-muted); font-size: 0.88rem; margin-top: 6px; font-weight: 500; }

.form-group { margin-bottom: 22px; }
label { display: block; color: var(--text-muted); font-size: 0.85rem; margin-bottom: 10px; font-weight: 600; text-align: right; }

.input-wrap { position: relative; }
.input-wrap input {
  width: 100%; padding: 16px 20px;
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid var(--border);
  border-radius: 16px; color: #fff;
  font-size: 1.25rem; letter-spacing: 2px;
  font-family: monospace; text-align: center;
  text-transform: uppercase; outline: none;
  transition: all 0.3s ease;
}
.input-wrap input:focus {
  border-color: var(--primary);
  background: rgba(255, 255, 255, 0.06);
  box-shadow: 0 0 20px rgba(0, 240, 255, 0.2);
}
.input-wrap input::placeholder { letter-spacing: 0; color: #4b5563; font-size: 0.9rem; font-family: inherit; }

.btn {
  width: 100%; padding: 16px;
  border: none; border-radius: 16px; color: #fff;
  font-size: 0.95rem; font-weight: 700;
  cursor: pointer; transition: all 0.3s ease;
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.btn-connect {
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  box-shadow: 0 8px 25px rgba(0, 240, 255, 0.25);
  margin-bottom: 14px;
}
.btn-connect:hover {
  transform: translateY(-2px);
  box-shadow: 0 12px 35px rgba(0, 240, 255, 0.45);
}
.btn-trial {
  background: rgba(16, 185, 129, 0.08);
  border: 1px solid rgba(16, 185, 129, 0.2);
  color: var(--success);
  margin-bottom: 10px;
}
.btn-trial:hover {
  background: var(--success);
  color: #fff;
  box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
}

.error {
  padding: 14px 18px; border-radius: 16px;
  margin-bottom: 24px; font-size: 0.85rem; text-align: right;
  background: rgba(239, 68, 68, 0.08);
  border: 1px solid rgba(239, 68, 68, 0.2);
  color: #fca5a5;
  line-height: 1.5;
}

/* قسم الكروت المستخدمة مؤخراً */
.history-section {
  margin-top: 25px;
  padding-top: 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  text-align: right;
}
.history-title {
  font-size: 0.8rem;
  color: var(--text-muted);
  margin-bottom: 12px;
  font-weight: 700;
}
.history-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.history-item {
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 10px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  transition: all 0.25s ease;
}
.history-item:hover {
  background: rgba(255, 255, 255, 0.04);
  border-color: rgba(0, 240, 255, 0.25);
  transform: translateX(-2px);
}
.history-code {
  font-family: monospace;
  font-weight: 700;
  color: var(--primary);
  font-size: 1.05rem;
}
.history-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}
.quick-login-btn {
  background: rgba(0, 240, 255, 0.12);
  color: var(--primary);
  border: none;
  padding: 6px 14px;
  border-radius: 10px;
  font-size: 0.78rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s;
  font-family: inherit;
}
.quick-login-btn:hover {
  background: var(--primary);
  color: #030712;
}
.remove-card {
  color: var(--danger);
  font-size: 1.3rem;
  cursor: pointer;
  line-height: 1;
  padding: 4px;
  opacity: 0.6;
  transition: opacity 0.2s;
}
.remove-card:hover { opacity: 1; }

.info-bar {
  display: flex; justify-content: space-between;
  margin-top: 25px; padding-top: 20px;
  border-top: 1px solid rgba(255, 255, 255, 0.05);
  font-size: 0.78rem; color: var(--text-muted);
}
.info-bar span { display: flex; align-items: center; gap: 4px; }

/* عرض الباقات للعملاء (مميزة إضافية) */
.packages-toggle {
  text-align: center; margin-top: 15px;
}
.packages-btn {
  background: none; border: none; color: var(--primary);
  font-size: 0.82rem; font-weight: 700; cursor: pointer;
  text-decoration: underline; font-family: inherit;
}
.packages-modal {
  display: none;
  position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  background: rgba(3, 7, 18, 0.85);
  backdrop-filter: blur(10px);
  z-index: 1000;
  align-items: center; justify-content: center;
  padding: 20px;
}
.packages-content {
  background: #0d111f;
  border: 1px solid var(--border);
  border-radius: 24px;
  width: 100%; max-width: 400px;
  padding: 30px; text-align: right;
  box-shadow: 0 20px 50px rgba(0,0,0,0.5);
  position: relative;
}
.packages-content h3 {
  font-size: 1.15rem; font-weight: 800; margin-bottom: 20px;
  background: linear-gradient(90deg, #fff, var(--primary));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.pack-row {
  display: flex; justify-content: space-between; align-items: center;
  padding: 12px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}
.pack-row:last-child { border: none; }
.pack-name { font-weight: 700; color: #fff; font-size: 0.9rem; }
.pack-price { font-weight: 800; color: var(--primary); font-size: 0.95rem; }
.close-modal {
  position: absolute; top: 20px; left: 20px;
  background: rgba(255,255,255,0.05); border: none;
  width: 30px; height: 30px; border-radius: 50%;
  color: #fff; font-size: 1.1rem; cursor: pointer;
  display: flex; align-items: center; justify-content: center;
}
.close-modal:hover { background: rgba(255,255,255,0.1); }

.footer {
  text-align: center; margin-top: 25px;
  font-size: 0.78rem; color: var(--text-muted);
}
</style>

</head>
<body>

<div class="container">
  <div class="card">
    <?php if (!empty($active_ads)): ?>
      <div class="ad-slider" style="width: 100%; height: 160px; overflow: hidden; border-radius: 14px; margin-bottom: 25px; position: relative; border: 1px solid rgba(255, 255, 255, 0.05); box-shadow: 0 4px 15px rgba(0,0,0,0.3);">
        <?php foreach ($active_ads as $index => $ad): ?>
          <a href="<?= $ad['link_url'] ? htmlspecialchars($ad['link_url']) : '#' ?>" 
             <?= $ad['link_url'] ? 'target="_blank"' : 'onclick="return false;"' ?>
             class="ad-slide <?= $index === 0 ? 'active' : '' ?>" 
             style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: <?= $index === 0 ? '1' : '0' ?>; transition: opacity 0.8s ease-in-out; background-image: url('<?= BASE_URL ?>/<?= htmlspecialchars($ad['image_path']) ?>'); background-size: cover; background-position: center; display: block; text-decoration: none;">
             <?php if ($ad['title']): ?>
               <div class="ad-title" style="position: absolute; bottom: 0; right: 0; width: 100%; background: linear-gradient(transparent, rgba(0,0,0,0.85)); color: #fff; padding: 12px 15px; font-size: 0.8rem; font-weight: 700; text-align: right; border-bottom-left-radius: 14px; border-bottom-right-radius: 14px;">
                 <?= htmlspecialchars($ad['title']) ?>
               </div>
             <?php endif; ?>
          </a>
        <?php endforeach; ?>
        
        <?php if (count($active_ads) > 1): ?>
          <div class="ad-dots" style="position: absolute; bottom: 10px; left: 10px; display: flex; gap: 6px; z-index: 10;">
            <?php foreach ($active_ads as $index => $ad): ?>
              <span class="ad-dot <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>" style="width: 8px; height: 8px; border-radius: 50%; background: rgba(255, 255, 255, 0.4); cursor: pointer; transition: all 0.2s;"></span>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    <?php endif; ?>
    <div class="logo">
      <div class="logo-icon">📶</div>
      <h1><?= htmlspecialchars($settings['portal_title'] ?? 'بوابة تسجيل الدخول للإنترنت') ?></h1>
      <p><?= htmlspecialchars($settings['portal_welcome'] ?? 'أدخل كود الكارت للدخول') ?></p>
    </div>

    <?php if ($error): ?>
      <div class="error">⚠️ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- نموذج تسجيل الدخول بالكارت -->
    <form method="POST" action="http://192.168.77.1/elmajiku/index.php" id="login_form" autocomplete="off">
      <input type="hidden" name="login" value="1">
      <div class="form-group">
        <label>أدخل كود الكارت</label>
        <div class="input-wrap">
          <input type="text" name="card_code" id="card_code"
                 placeholder="مثال: ABC12345"
                 maxlength="20" required autofocus
                 value="<?= htmlspecialchars($_POST['card_code'] ?? '') ?>">
        </div>
      </div>

      <div style="display: flex; gap: 10px; margin-bottom: 10px;">
        <button type="submit" class="btn btn-connect" style="flex: 2; margin-bottom: 0;">🔗 اتصال بالإنترنت</button>
        <button type="button" id="scan-qr-btn" class="btn" onclick="openQrScanner()" style="flex: 1; background: rgba(0, 212, 255, 0.12); border: 1px solid var(--primary); color: var(--primary); font-size: 0.8rem; font-weight: 700; padding: 12px 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 3px; margin-bottom: 0; line-height: 1.2;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="3" height="3" rx="0.5"/><rect x="18" y="14" width="3" height="3" rx="0.5"/><rect x="14" y="18" width="3" height="3" rx="0.5"/><rect x="18" y="18" width="3" height="3" rx="0.5"/></svg>
          <span>مسح QR</span>
        </button>
      </div>
      <div id="qr-hint" style="text-align:center; font-size:0.72rem; color:var(--text-muted); margin-bottom:12px; line-height:1.5; display:none;">
        📸 سيفتح موقع المسح — صوّر رمز QR الموجود على كارتك
      </div>
    </form>

    <?php if (!empty($settings['trial_enabled'])): ?>
    <!-- نموذج التجربة المجانية -->
    <form method="POST" action="http://192.168.77.1/elmajiku/index.php">
      <button type="submit" name="free_trial" class="btn btn-trial">⚡ تجربة مجانية (<?= htmlspecialchars($settings['trial_min'] ?? 10) ?> دقائق)</button>
    </form>
    <?php endif; ?>

    <!-- زر عرض أسعار الباقات المتاحة -->
    <div class="packages-toggle">
      <button type="button" class="packages-btn" onclick="toggleModal(true)">📋 عرض أسعار وباقات الكروت المتاحة</button>
    </div>

    <!-- زر عرض عروض وإعلانات الشبكة -->
    <div style="text-align: center; margin-top: 12px; margin-bottom: 5px;">
      <a href="<?= BASE_URL ?>/offers.php" style="color: var(--primary); font-size: 0.82rem; font-weight: 700; text-decoration: underline; font-family: inherit;">📢 مشاهدة عروض وإعلانات الشبكة المتاحة</a>
    </div>

    <!-- تاريخ الكروت المستخدمة مؤخراً للدخول السريع -->
    <div class="history-section" id="history_section" style="display: none;">
      <div class="history-title">كروت تم استخدامها مؤخراً للدخول السريع:</div>
      <div class="history-list" id="history_list"></div>
    </div>

    <div class="info-bar">
      <span>🖥️ <?= htmlspecialchars($client_ip) ?></span>
      <span>🔒 اتصال آمن</span>
    </div>
  </div>

  <div class="footer">
    <?= htmlspecialchars(!empty($settings['brand_name']) ? $settings['brand_name'] : $settings['site_name']) ?> &copy; <?= date('Y') ?>
  </div>
</div>

<!-- مودال أسعار الباقات -->
<div class="packages-modal" id="packages_modal">
  <div class="packages-content">
    <button class="close-modal" onclick="toggleModal(false)">&times;</button>
    <h3>📋 باقات الإنترنت المتوفرة بالشبكة</h3>
    
    <?php if (!empty($packages)): ?>
      <?php foreach ($packages as $p): 
          $data_lbl = $p['total_mb'] ? ($p['total_mb'] >= 1024 ? ($p['total_mb']/1024).' جيجا' : $p['total_mb'].' ميجا') : 'مفتوح';
          $time_lbl = '';
          if ($p['total_minutes'] > 0) {
              if ($p['total_minutes'] % 1440 === 0) {
                  $time_lbl = ($p['total_minutes']/1440).' يوم';
              } elseif ($p['total_minutes'] % 60 === 0) {
                  $time_lbl = ($p['total_minutes']/60).' ساعة';
              } else {
                  $time_lbl = $p['total_minutes'].' دقيقة';
              }
          }
          $validity = $p['expire_days'] ? 'صلاحية ' . $p['expire_days'] . ' يوم' : ($time_lbl ? 'صلاحية ' . $time_lbl : 'صلاحية مفتوحة');
          $desc = "🎫 " . htmlspecialchars($p['name']) . " (" . $data_lbl . " - " . $validity . ")";
      ?>
        <div class="pack-row">
          <span class="pack-name"><?= $desc ?></span>
          <span class="pack-price"><?= number_format($p['price'], 1) ?> جنيه</span>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div style="text-align:center; color:#64748b; padding:20px;">لا توجد باقات معروضة حالياً</div>
    <?php endif; ?>
  </div>
</div>

<script>
// ============================================================
// استقبال الكود من قارئ QR الخارجي (عبر URL parameter ?code=)
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
  const params = new URLSearchParams(window.location.search);
  const scannedCode = params.get('code');
  if (scannedCode && scannedCode.trim().length > 0) {
    const inp = document.getElementById('card_code');
    if (inp) {
      inp.value = scannedCode.trim().toUpperCase();
      saveToHistory(inp.value);
      setTimeout(function() {
        document.getElementById('login_form').submit();
      }, 400);
    }
  }
});

// فتح موقع مسح QR الخارجي (laksa19.github.io/myqr)
// الموقع يقرأ الـ QR الموجود على الكارت ويفتح رابط تسجيل الدخول مباشرة
function openQrScanner() {
  const hint = document.getElementById('qr-hint');
  const btn  = document.getElementById('scan-qr-btn');
  if (hint) hint.style.display = 'block';
  if (btn)  btn.style.opacity  = '0.6';
  setTimeout(function() {
    window.location.href = 'https://laksa19.github.io/myqr/';
  }, 800);
}

// تحويل الحروف لكبيرة تلقائياً
const input = document.getElementById('card_code');
if (input) {
  input.addEventListener('input', function() {
    this.value = this.value.toUpperCase();
  });
}

// إظهار وإخفاء مودال الباقات
function toggleModal(show) {
  const modal = document.getElementById('packages_modal');
  if (modal) modal.style.display = show ? 'flex' : 'none';
}

// حفظ كود في سجل الكروت
function saveToHistory(code) {
  if (!code) return;
  let history = JSON.parse(localStorage.getItem('hotspot_cards_history') || '[]');
  history = history.filter(c => c !== code);
  history.unshift(code);
  if (history.length > 5) history = history.slice(0, 5);
  localStorage.setItem('hotspot_cards_history', JSON.stringify(history));
}

// عرض وإدارة سجل الكروت للدخول السريع
document.addEventListener('DOMContentLoaded', function() {
  const historySection = document.getElementById('history_section');
  const historyList = document.getElementById('history_list');
  const form = document.getElementById('login_form');
  
  let history = JSON.parse(localStorage.getItem('hotspot_cards_history') || '[]');
  
  if (history.length > 0 && historyList && historySection) {
    historySection.style.display = 'block';
    
    history.forEach(code => {
      const item = document.createElement('div');
      item.className = 'history-item';
      item.innerHTML = `
        <span class="history-code">${code}</span>
        <div class="history-actions">
          <button type="button" class="quick-login-btn">دخول سريع</button>
          <span class="remove-card">&times;</span>
        </div>
      `;
      
      item.querySelector('.quick-login-btn').addEventListener('click', function() {
        input.value = code;
        form.submit();
      });
      
      item.querySelector('.remove-card').addEventListener('click', function(e) {
        e.stopPropagation();
        history = history.filter(c => c !== code);
        localStorage.setItem('hotspot_cards_history', JSON.stringify(history));
        item.remove();
        if (history.length === 0) {
          historySection.style.display = 'none';
        }
      });
      
      historyList.appendChild(item);
    });
  }

  // حفظ الكود في السجل عند إرسال الفورم
  if (form && input) {
    form.addEventListener('submit', function() {
      if (input.value.trim()) saveToHistory(input.value.trim().toUpperCase());
    });
  }

  // السلايدر التلقائي للإعلانات
  const slides = document.querySelectorAll('.ad-slide');
  const dots = document.querySelectorAll('.ad-dot');
  if (slides.length > 1) {
    let currentSlide = 0;
    const slideInterval = 4000; // 4 ثوانٍ
    
    function goToSlide(n) {
      slides[currentSlide].style.opacity = '0';
      slides[currentSlide].classList.remove('active');
      if (dots[currentSlide]) {
        dots[currentSlide].classList.remove('active');
        dots[currentSlide].style.background = 'rgba(255, 255, 255, 0.4)';
      }
      
      currentSlide = (n + slides.length) % slides.length;
      
      slides[currentSlide].style.opacity = '1';
      slides[currentSlide].classList.add('active');
      if (dots[currentSlide]) {
        dots[currentSlide].classList.add('active');
        dots[currentSlide].style.background = 'var(--primary)';
      }
    }
    
    function nextSlide() {
      goToSlide(currentSlide + 1);
    }
    
    let timer = setInterval(nextSlide, slideInterval);
    
    dots.forEach((dot, idx) => {
      dot.addEventListener('click', function() {
        clearInterval(timer);
        goToSlide(idx);
        timer = setInterval(nextSlide, slideInterval);
      });
      if (idx === 0) {
        dot.style.background = 'var(--primary)';
      }
    });
  }
});
</script>
</body>
</html>
