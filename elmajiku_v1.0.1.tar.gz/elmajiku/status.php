<?php
// منع التخزين المؤقت (الكاش) لضمان تطبيق الإعدادات والألوان فوراً على الهواتف والأجهزة المتصلة بالشبكة
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");

require_once __DIR__ . '/admin/includes/config.php';
require_once __DIR__ . '/admin/includes/db.php';
require_once __DIR__ . '/admin/includes/iptables.php';

session_start();

$settings  = getSettings();
$client_ip = $_SERVER['REMOTE_ADDR'];

// جلب الماك لتأكيد الربط
$arp = shell_exec("cat /proc/net/arp 2>/dev/null");
$client_mac = 'unknown';
if ($arp) {
    foreach (explode("\n", $arp) as $line) {
        $parts = preg_split('/\s+/', trim($line));
        if (isset($parts[0]) && $parts[0] === $client_ip && isset($parts[3])) {
            $mac = $parts[3];
            if ($mac !== '00:00:00:00:00:00') {
                $client_mac = strtoupper($mac);
                break;
            }
        }
    }
}

// التحقق من حالة الاتصال
$online = getOnlineUser($client_ip);
if (!$online) {
    header('Location: ' . BASE_URL . '/');
    exit;
}

// قطع الاتصال عند الضغط على زر الخروج
if (isset($_POST['disconnect'])) {
    blockIP($client_ip);
    removeOnlineUser($client_ip);
    addLog($online['card_code'], "تسجيل خروج يدوي من الجهاز $client_ip ($client_mac)");
    header('Location: ' . BASE_URL . '/');
    exit;
}

$card = getCard($online['card_code']);

// حساب البيانات والوقت المتبقي بدقة
$remaining_mb  = $card['total_mb']      ? max(0, $card['total_mb']      - $card['used_mb'])      : null;
$remaining_min = $card['total_minutes'] ? max(0, $card['total_minutes'] - $card['used_minutes']) : null;
$remaining_sec = $card['total_minutes'] ? max(0, intval(($card['total_minutes'] - $card['used_minutes']) * 60)) : null;

$login_time    = $online['login_time'] ? (new DateTime($online['login_time']))->getTimestamp() : time();
$duration_min  = round((time() - $login_time) / 60);

// فحص التحذير من انخفاض الرصيد (أقل من 10% داتا)
$low_data_warning = false;
if ($remaining_mb !== null && $card['total_mb'] > 0) {
    if (($remaining_mb / $card['total_mb']) < 0.1) {
        $low_data_warning = true;
    }
}

// نسب الاستهلاك
$mb_pct  = ($card['total_mb']      && $card['total_mb']      > 0) ? min(100, round($card['used_mb']      / $card['total_mb']      * 100)) : 0;
$min_pct = ($card['total_minutes'] && $card['total_minutes'] > 0) ? min(100, round($card['used_minutes'] / $card['total_minutes'] * 100)) : 0;

// حساب الوقت المتبقي لانتهاء صلاحية الكارت الكلية
$time_left_str = null;
if (!empty($card['expire_date'])) {
    $expire_ts = strtotime($card['expire_date']);
    $diff = $expire_ts - time();
    if ($diff <= 0) {
        $time_left_str = 'منتهي الصلاحية';
    } else {
        $days = floor($diff / 86400);
        $hours = floor(($diff % 86400) / 3600);
        $mins = floor(($diff % 3600) / 60);
        if ($days > 0) {
            $time_left_str = "$days يوم و $hours ساعة";
        } elseif ($hours > 0) {
            $time_left_str = "$hours ساعة و $mins دقيقة";
        } else {
            $time_left_str = "$mins دقيقة";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>حالة الاتصال - <?= htmlspecialchars($settings['site_name']) ?></title>
<meta http-equiv="refresh" content="15">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
<style>
:root {
  --primary: <?= $settings['primary_color'] ?? '#00f0ff' ?>;
  --secondary: <?= $settings['secondary_color'] ?? '#a855f7' ?>;
  --success: #10b981;
  --danger: #ef4444;
  --bg: #030712;
  --card-bg: rgba(17, 24, 39, 0.7);
  --border: rgba(255, 255, 255, 0.08);
  --text: #f3f4f6;
  --text-muted: #9ca3af;
}

* { margin:0; padding:0; box-sizing:border-box; }
body {
  min-height: 100vh;
  background: radial-gradient(circle at 50% 50%, rgba(17, 24, 39, 1) 0%, rgba(3, 7, 18, 1) 100%);
  font-family: 'Tajawal', sans-serif;
  color: var(--text);
  display: flex; align-items: center; justify-content: center;
  padding: 20px;
}

/* خلفية الجزيئات المضيئة */
.bg-glow {
  position: absolute; width: 350px; height: 350px;
  background: radial-gradient(circle, rgba(0, 240, 255, 0.1) 0%, transparent 70%);
  top: 15%; left: 15%; pointer-events: none; z-index: 0;
}
.bg-glow-2 {
  position: absolute; width: 350px; height: 350px;
  background: radial-gradient(circle, rgba(168, 85, 247, 0.1) 0%, transparent 70%);
  bottom: 15%; right: 15%; pointer-events: none; z-index: 0;
}

.container {
  width: 100%; max-width: 440px; position: relative; z-index: 10;
}

.card {
  background: var(--card-bg);
  backdrop-filter: blur(25px);
  -webkit-backdrop-filter: blur(25px);
  border: 1px solid var(--border);
  border-radius: 28px;
  padding: 35px 30px;
  box-shadow: 0 30px 70px rgba(0, 0, 0, 0.7);
  text-align: center;
  position: relative;
  overflow: hidden;
}

.card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0; height: 3px;
  background: linear-gradient(90deg, var(--primary), var(--secondary));
}

/* شارة الحالة */
.status-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(16, 185, 129, 0.08);
  border: 1px solid rgba(16, 185, 129, 0.2);
  padding: 8px 18px;
  border-radius: 30px;
  color: var(--success);
  font-weight: 700;
  font-size: 0.88rem;
  margin-bottom: 25px;
  box-shadow: 0 4px 15px rgba(16, 185, 129, 0.05);
}
.status-dot {
  width: 8px; height: 8px; border-radius: 50%;
  background-color: var(--success);
  animation: pulse-dot 1.8s infinite;
}
@keyframes pulse-dot {
  0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
  70% { box-shadow: 0 0 0 8px rgba(16, 185, 129, 0); }
  100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
}

/* عداد الاستهلاك الدائري المزدوج */
.gauge-area {
  position: relative;
  width: 190px; height: 190px;
  margin: 0 auto 30px;
}
.gauge-svg {
  transform: rotate(-90deg);
  filter: drop-shadow(0 0 10px rgba(0, 240, 255, 0.15));
}
.gauge-svg circle {
  fill: none;
  stroke-linecap: round;
}
.gauge-svg circle.bg-track {
  stroke: rgba(255, 255, 255, 0.03);
  stroke-width: 8px;
}
.gauge-svg circle.progress {
  stroke-width: 8px;
  transition: stroke-dashoffset 1s cubic-bezier(0.4, 0, 0.2, 1);
}
.gauge-svg circle.outer-circle {
  stroke-dasharray: 502.6; /* 2 * PI * r (r=80) */
  stroke-dashoffset: calc(502.6 - (502.6 * var(--pct)) / 100);
}
.gauge-svg circle.inner-circle {
  stroke-dasharray: 395.8; /* 2 * PI * r (r=63) */
  stroke-dashoffset: calc(395.8 - (395.8 * var(--pct)) / 100);
  stroke-width: 6px;
}
.gauge-svg circle.inner-track {
  stroke: rgba(255, 255, 255, 0.03);
  stroke-width: 6px;
}

.gauge-text {
  position: absolute;
  top: 0; left: 0; width: 100%; height: 100%;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  pointer-events: none;
}
.gauge-text .pct {
  font-size: 2.1rem; font-weight: 800; color: #fff;
  background: linear-gradient(135deg, #fff, #a855f7);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  line-height: 1;
}
.gauge-text .label {
  font-size: 0.75rem; color: var(--text-muted);
  font-weight: 600; margin-top: 6px; letter-spacing: 0.5px;
}

/* شبكة تفاصيل الاستهلاك */
.detail-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 12px;
  margin-bottom: 25px;
}
.detail-item {
  background: rgba(255, 255, 255, 0.02);
  border: 1px solid rgba(255, 255, 255, 0.04);
  border-radius: 16px; padding: 14px;
  transition: all 0.3s ease;
}
.detail-item:hover {
  background: rgba(255, 255, 255, 0.04);
  border-color: rgba(0, 240, 255, 0.15);
}
.detail-item .val {
  font-size: 1.25rem; font-weight: 700; color: var(--text);
  font-family: monospace;
}
.detail-item .lbl {
  font-size: 0.75rem; color: var(--text-muted);
  margin-top: 4px; font-weight: 500;
}

/* شريط تفاصيل الباقة */
.pack-info-row {
  background: rgba(255, 255, 255, 0.01);
  border: 1px solid rgba(255, 255, 255, 0.03);
  border-radius: 16px; padding: 16px 20px;
  margin-bottom: 25px; text-align: right;
}
.pack-title {
  font-size: 0.85rem; font-weight: 700; margin-bottom: 12px;
  display: flex; align-items: center; gap: 6px;
  color: var(--primary);
}
.pack-stat {
  display: flex; justify-content: space-between;
  font-size: 0.8rem; color: var(--text-muted);
  margin-bottom: 6px;
}
.pack-stat:last-child { margin-bottom: 0; }
.pack-stat span.value { color: var(--text); font-weight: 600; }

/* زر قطع الاتصال */
.btn-logout {
  width: 100%; padding: 16px; border: none;
  background: linear-gradient(135deg, rgba(239, 68, 68, 0.1), rgba(239, 68, 68, 0.05));
  border: 1px solid rgba(239, 68, 68, 0.25);
  border-radius: 16px; color: var(--danger);
  font-size: 0.95rem; font-weight: 700;
  cursor: pointer; transition: all 0.25s ease;
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.btn-logout:hover {
  background: var(--danger);
  border-color: var(--danger);
  color: #fff;
  box-shadow: 0 8px 25px rgba(239, 68, 68, 0.25);
  transform: translateY(-1px);
}

.divider {
  height: 1px; background: rgba(255, 255, 255, 0.05);
  margin: 24px 0;
}

/* الفوتر */
.footer-bar {
  display: flex; justify-content: space-between;
  font-size: 0.76rem; color: var(--text-muted);
  padding: 0 4px;
}
.footer-bar span {
  display: flex; align-items: center; gap: 4px;
}

</style>
</head>
<body>

<div class="bg-glow"></div>
<div class="bg-glow-2"></div>

<div class="container">
  <div class="card">
    
    <!-- حاوية التنبيه بقرب انتهاء الباقة -->
    <div id="expiry-warning" style="display:none; background: rgba(245, 158, 11, 0.12); border: 1px solid rgba(245, 158, 11, 0.3); color: #fbbf24; padding: 12px 15px; border-radius: 16px; margin-bottom: 20px; font-size: 0.8rem; font-weight: 700; text-align: right; line-height: 1.5;">
      ⚠️ تنبيه: رصيد الباقة أوشك على الانتهاء! يرجى شراء كارت جديد لضمان عدم انقطاع الخدمة.
    </div>

    <!-- شارة متصل -->
    <div class="status-badge">
      <span class="status-dot"></span>
      <span>متصل بالإنترنت</span>
    </div>

    <!-- عداد الاستهلاك الاحترافي المزدوج -->
    <div class="gauge-area">
      <svg class="gauge-svg" width="190" height="190" viewBox="0 0 190 190">
        <defs>
          <linearGradient id="primaryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#00f0ff" />
            <stop offset="100%" stop-color="#3b82f6" />
          </linearGradient>
          <linearGradient id="secondaryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#a855f7" />
            <stop offset="100%" stop-color="#ec4899" />
          </linearGradient>
        </defs>
        
        <!-- حلقة الداتا الخارجية (r=80) -->
        <circle cx="95" cy="95" r="80" class="bg-track" />
        <circle cx="95" cy="95" r="80" class="progress outer-circle" 
                style="--pct: <?= $card['total_mb'] > 0 ? $mb_pct : 0 ?>; stroke: url(#primaryGrad);" />
        
        <!-- حلقة الوقت الداخلية (r=63) -->
        <circle cx="95" cy="95" r="63" class="inner-track" />
        <circle cx="95" cy="95" r="63" class="progress inner-circle" id="time-gauge-circle"
                style="--pct: <?= $card['total_minutes'] > 0 ? $min_pct : 0 ?>; stroke: url(#secondaryGrad);" />
      </svg>
      
      <div class="gauge-text">
        <?php
          if ($card['total_mb'] > 0 && $card['total_minutes'] > 0) {
              $avg_pct = round(($mb_pct + $min_pct) / 2);
              echo '<div class="pct">' . $avg_pct . '%</div>';
              echo '<div class="label">إجمالي الاستهلاك</div>';
          } elseif ($card['total_mb'] > 0) {
              echo '<div class="pct">' . $mb_pct . '%</div>';
              echo '<div class="label">استهلاك البيانات</div>';
          } elseif ($card['total_minutes'] > 0) {
              echo '<div class="pct">' . $min_pct . '%</div>';
              echo '<div class="label">استهلاك الوقت</div>';
          } else {
              echo '<div class="pct" style="font-size:2.8rem; color:var(--primary)">∞</div>';
              echo '<div class="label">اتصال غير محدود</div>';
          }
        ?>
      </div>
    </div>

    <!-- شبكة التفاصيل السريعة -->
    <div class="detail-grid">
      <div class="detail-item">
        <div class="val" style="color:var(--primary)">
          <?= $remaining_mb !== null ? round($remaining_mb, 1) . ' MB' : '∞' ?>
        </div>
        <div class="lbl">الداتا المتبقية</div>
      </div>
      <div class="detail-item">
        <div class="val" id="time-remaining-val" style="color:var(--secondary)">
          <?= $remaining_min !== null ? round($remaining_min) . ' دقيقة' : '∞' ?>
        </div>
        <div class="lbl">الوقت المتبقي</div>
      </div>
      <div class="detail-item">
        <div class="val"><?= htmlspecialchars($online['card_code']) ?></div>
        <div class="lbl">كود الكارت</div>
      </div>
      <div class="detail-item">
        <div class="val"><?= $duration_min ?> دقيقة</div>
        <div class="lbl">مدة الجلسة</div>
      </div>
    </div>

    <!-- تفاصيل الحزمة -->
    <div class="pack-info-row">
      <div class="pack-title">📦 تفاصيل الباقة الحالية:</div>
      
      <?php if ($card['total_mb'] > 0): ?>
      <div class="pack-stat">
        <span>حجم الداتا المستهلك:</span>
        <span class="value"><?= round($card['used_mb'], 2) ?> / <?= $card['total_mb'] ?> MB</span>
      </div>
      <?php endif; ?>

      <?php if ($card['total_minutes'] > 0): ?>
      <div class="pack-stat">
        <span>رصيد الوقت المستهلك:</span>
        <span class="value"><?= round($card['used_minutes']) ?> / <?= $card['total_minutes'] ?> دقيقة</span>
      </div>
      <?php endif; ?>

      <?php if ($time_left_str): ?>
      <div class="pack-stat">
        <span>صلاحية الكارت الكلية تنتهي في:</span>
        <span class="value" style="color:#f59e0b;"><?= $time_left_str ?></span>
      </div>
      <?php endif; ?>
    </div>

    <form method="POST">
      <button type="submit" name="disconnect" 
              onclick="return confirm('هل أنت متأكد من قطع الاتصال بالإنترنت؟')" 
              class="btn-logout">
        <span>🔌 قطع اتصال جهازك</span>
      </button>
    </form>

    <div class="divider"></div>

    <!-- فوتر خفيف -->
    <div class="footer-bar">
      <span>🖥️ <?= htmlspecialchars($client_ip) ?></span>
      <span>🔄 تحديث تلقائي كل 15 ث</span>
    </div>

  </div>
</div>

<script>
  // تحديث سجل الدخول في localStorage
  const cardCode = "<?= htmlspecialchars($online['card_code']) ?>";
  if (cardCode) {
    let history = JSON.parse(localStorage.getItem('hotspot_cards_history') || '[]');
    if (!history.includes(cardCode)) {
      history.push(cardCode);
      if (history.length > 4) {
        history.shift(); // الاحتفاظ بآخر 4 كروت
      }
      localStorage.setItem('hotspot_cards_history', JSON.stringify(history));
    }
  }

  // ==========================================
  // العداد التنازلي المباشر وتحديث المؤشرات والتحذيرات
  // ==========================================
  document.addEventListener('DOMContentLoaded', function() {
    let remainingSeconds = <?= json_encode($remaining_sec) ?>;
    const initialTotalSeconds = <?= json_encode($card['total_minutes'] ? intval($card['total_minutes'] * 60) : null) ?>;
    const lowData = <?= json_encode($low_data_warning) ?>;
    const timeValEl = document.getElementById('time-remaining-val');
    const warningEl = document.getElementById('expiry-warning');
    const timeCircle = document.getElementById('time-gauge-circle');

    function formatTime(sec) {
      if (sec === null) return '∞';
      if (sec <= 0) return 'انتهى الوقت';
      
      let h = Math.floor(sec / 3600);
      let m = Math.floor((sec % 3600) / 60);
      let s = sec % 60;
      
      let hStr = h > 0 ? (h < 10 ? '0' + h : h) + ':' : '';
      let mStr = (m < 10 ? '0' + m : m) + ':';
      let sStr = s < 10 ? '0' + s : s;
      
      return hStr + mStr + sStr;
    }

    function checkWarnings() {
      // إظهار التنبيه إذا كانت الداتا منخفضة أو الوقت أقل من 5 دقائق (300 ثانية)
      if (lowData || (remainingSeconds !== null && remainingSeconds < 300)) {
        if (warningEl) warningEl.style.display = 'block';
      } else {
        if (warningEl) warningEl.style.display = 'none';
      }
    }

    if (remainingSeconds !== null) {
      checkWarnings();
      
      const timer = setInterval(function() {
        remainingSeconds--;
        if (remainingSeconds <= 0) {
          remainingSeconds = 0;
          clearInterval(timer);
          if (timeValEl) timeValEl.innerText = 'انتهى الوقت';
          checkWarnings();
          setTimeout(function() {
            window.location.reload();
          }, 1500);
          return;
        }

        // تحديث النص المعروض
        if (timeValEl) {
          timeValEl.innerText = formatTime(remainingSeconds);
        }

        // تحديث شكل حلقة العداد الدائرية
        if (timeCircle && initialTotalSeconds > 0) {
          let usedPct = ((initialTotalSeconds - remainingSeconds) / initialTotalSeconds) * 100;
          timeCircle.style.setProperty('--pct', Math.min(100, Math.max(0, usedPct)));
        }

        checkWarnings();
      }, 1000);
    } else {
      // اتصال غير محدود بالوقت
      checkWarnings();
    }
  });
</script>
</body>
</html>
